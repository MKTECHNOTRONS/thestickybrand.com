var xSiteUrl = window.location.href;
if (xSiteUrl.indexOf('saveritemedicalshop.com') > 0) {
    window.location.href = 'https://www.saveritemedical.com/';
}
async function removeNavidium() {
    fetch('/cart.js')
        .then((n) => n.json())
        .then((n) => {
            let {
                items: e
            } = n
            e.forEach(async (n) => {
                if (n.handle.includes('navidium')) {
                    let e = {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json;',
                            Accept: 'application/json'
                        },
                        body: JSON.stringify({
                            id: String(n.variant_id),
                            quantity: 0
                        })
                    }
                    fetch('/cart/change.js', e)
                        .then((n) => n.json())
                        .then((n) => location.reload())
                }
            })
        })
}
removeNavidium()