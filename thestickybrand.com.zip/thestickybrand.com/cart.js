{
    "token": "7796c50a954a39697d6e19463dd50273",
    "note": null,
    "attributes": {},
    "original_total_price": 0,
    "total_price": 0,
    "total_discount": 0,
    "total_weight": 0.0,
    "item_count": 0,
    "items": [],
    "requires_shipping": false,
    "currency": "USD",
    "items_subtotal_price": 0,
    "cart_level_discount_applications": []
}