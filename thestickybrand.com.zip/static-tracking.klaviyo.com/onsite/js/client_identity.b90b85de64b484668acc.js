(self.webpackChunk_klaviyo_onsite_modules = self.webpackChunk_klaviyo_onsite_modules || []).push([
    [9179], {
        18892: function(e, t, n) {
            "use strict";
            var r = n(45933),
                o = n(7628),
                i = n(32681);
            n(92461), n(70818), n(83362);
            n(60873);
            const s = e => {
                    const t = document.cookie,
                        n = t.split(";").map((e => e.split("="))).reduce(((e, t) => (t[0] && t[1] && (e[decodeURIComponent(t[0].trim())] = decodeURIComponent(t[1].trim())), e)), {});
                    return e.map((e => e.key)).filter((e => void 0 !== n[e])).map((e => ({
                        [e]: n[e]
                    })))
                },
                a = "extendedIdIdentifiers",
                c = e => e.map((e => e.key)).filter((e => void 0 !== localStorage[e])).map((e => ({
                    [e]: String(localStorage[e])
                }))),
                u = e => {
                    var t, n;
                    t = a, n = JSON.stringify(e), localStorage.setItem(t, n)
                },
                l = e => {
                    const t = localStorage.getItem(a);
                    e(t ? JSON.parse(t) : {})
                };
            n(26650), n(60624), n(75479);
            const d = e => {
                const t = new URLSearchParams(window.location.search);
                return e.map((e => e.key)).filter((e => t.has(e))).map((e => ({
                    [e]: t.get(e) || void 0
                })))
            };
            n(61099);
            const f = ({
                    _kx: e,
                    companyId: t,
                    clientIdentifiers: n,
                    extendedIdIdentifiers: r
                }) => {
                    fetch(`https://a.klaviyo.com/client/sessions/?company_id=${t}`, {
                        method: "POST",
                        body: JSON.stringify({
                            data: {
                                type: "session",
                                attributes: {
                                    identifiers: Object.assign({}, n, {
                                        _kx: e
                                    })
                                }
                            }
                        }),
                        headers: {
                            "X-Klaviyo-Onsite": "1",
                            revision: "2024-07-15.pre",
                            "Content-Type": "application/json",
                            accept: "application/json"
                        }
                    }).then((e => e.json())).then((e => {
                        const {
                            id: t,
                            attributes: {
                                kx: n,
                                identifiers: s
                            }
                        } = e.data, a = Object.keys(s), c = {};
                        var l;
                        r.filter((e => a.some((t => t === e.key)) && !1 === e.is_warming && !0 === e.enabled && !0 === e.valid)).reduce(((e, t) => (e[t.key] = s[t.key], e)), c), (0, i.pN)() ? (0, o.B2)("Identifier and _kx pairs set in backend. Not identifying onsite, already identified.") : Object.keys(c).length > 0 ? ((0, o.B2)(`Setting klSessionId: ${t}`), l = t, (0, i.p2)(l), (0, o.B2)(`Identified: ${JSON.stringify(c)}`), (0, i.ro)({
                            fields: {
                                $exchange_id: n,
                                klSessionId: t
                            }
                        }), u(c)) : (0, o.B2)("Could not identify via extended ID based on available identifiers")
                    })).catch((e => {
                        (0, o.B2)("Failed to create client identity", e)
                    }))
                },
                C = () => {
                    if (void 0 === window.klaviyoModulesObject) return void(0, o.B2)("klaviyoModulesObject is not defined");
                    if ((0, i.W6)() && (0, i.pN)()) return void(0, o.B2)("Client session already exists and user is identified, should not set a new session");
                    const {
                        companyId: e,
                        extendedIdIdentifiers: t
                    } = window.klaviyoModulesObject, {
                        $exchange_id: n
                    } = (0, i.zy)(), r = (e => {
                        let t = [];
                        const n = e.filter((e => 1 === e.identifier_type)),
                            r = e.filter((e => 2 === e.identifier_type)),
                            o = e.filter((e => 0 === e.identifier_type));
                        return n.length > 0 && (t = [...t, ...s(n)]), r.length > 0 && (t = [...t, ...c(r)]), o.length > 0 && (t = [...t, ...d(o)]), t.reduce(((e, t) => {
                            const n = Object.keys(t)[0];
                            return void 0 === n || void 0 === t[n] || (e[n] = t[n]), e
                        }), {})
                    })(t);
                    null !== r && 0 !== Object.keys(r).length ? f({
                        companyId: e,
                        _kx: n,
                        clientIdentifiers: r,
                        extendedIdIdentifiers: t
                    }) : (0, o.B2)("No identifiers found")
                };
            (0, r.e)("createClientSession", C), (0, r.e)("getClientIdentifiers", l)
        },
        82231: function(e, t, n) {
            var r = n(6283);
            t.formatArgs = function(t) {
                if (t[0] = (this.useColors ? "%c" : "") + this.namespace + (this.useColors ? " %c" : " ") + t[0] + (this.useColors ? "%c " : " ") + "+" + e.exports.humanize(this.diff), !this.useColors) return;
                const n = "color: " + this.color;
                t.splice(1, 0, n, "color: inherit");
                let r = 0,
                    o = 0;
                t[0].replace(/%[a-zA-Z%]/g, (e => {
                    "%%" !== e && (r++, "%c" === e && (o = r))
                })), t.splice(o, 0, n)
            }, t.save = function(e) {
                try {
                    e ? t.storage.setItem("debug", e) : t.storage.removeItem("debug")
                } catch (e) {}
            }, t.load = function() {
                let e;
                try {
                    e = t.storage.getItem("debug")
                } catch (e) {}!e && void 0 !== r && "env" in r && (e = r.env.DEBUG);
                return e
            }, t.useColors = function() {
                if ("undefined" != typeof window && window.process && ("renderer" === window.process.type || window.process.__nwjs)) return !0;
                if ("undefined" != typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().match(/(edge|trident)\/(\d+)/)) return !1;
                return "undefined" != typeof document && document.documentElement && document.documentElement.style && document.documentElement.style.WebkitAppearance || "undefined" != typeof window && window.console && (window.console.firebug || window.console.exception && window.console.table) || "undefined" != typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/) && parseInt(RegExp.$1, 10) >= 31 || "undefined" != typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/)
            }, t.storage = function() {
                try {
                    return localStorage
                } catch (e) {}
            }(), t.destroy = (() => {
                let e = !1;
                return () => {
                    e || (e = !0, console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`."))
                }
            })(), t.colors = ["#0000CC", "#0000FF", "#0033CC", "#0033FF", "#0066CC", "#0066FF", "#0099CC", "#0099FF", "#00CC00", "#00CC33", "#00CC66", "#00CC99", "#00CCCC", "#00CCFF", "#3300CC", "#3300FF", "#3333CC", "#3333FF", "#3366CC", "#3366FF", "#3399CC", "#3399FF", "#33CC00", "#33CC33", "#33CC66", "#33CC99", "#33CCCC", "#33CCFF", "#6600CC", "#6600FF", "#6633CC", "#6633FF", "#66CC00", "#66CC33", "#9900CC", "#9900FF", "#9933CC", "#9933FF", "#99CC00", "#99CC33", "#CC0000", "#CC0033", "#CC0066", "#CC0099", "#CC00CC", "#CC00FF", "#CC3300", "#CC3333", "#CC3366", "#CC3399", "#CC33CC", "#CC33FF", "#CC6600", "#CC6633", "#CC9900", "#CC9933", "#CCCC00", "#CCCC33", "#FF0000", "#FF0033", "#FF0066", "#FF0099", "#FF00CC", "#FF00FF", "#FF3300", "#FF3333", "#FF3366", "#FF3399", "#FF33CC", "#FF33FF", "#FF6600", "#FF6633", "#FF9900", "#FF9933", "#FFCC00", "#FFCC33"], t.log = console.debug || console.log || (() => {}), e.exports = n(71199)(t);
            const {
                formatters: o
            } = e.exports;
            o.j = function(e) {
                try {
                    return JSON.stringify(e)
                } catch (e) {
                    return "[UnexpectedJSONParseError]: " + e.message
                }
            }
        },
        71199: function(e, t, n) {
            e.exports = function(e) {
                function t(e) {
                    let n, o, i, s = null;

                    function a(...e) {
                        if (!a.enabled) return;
                        const r = a,
                            o = Number(new Date),
                            i = o - (n || o);
                        r.diff = i, r.prev = n, r.curr = o, n = o, e[0] = t.coerce(e[0]), "string" != typeof e[0] && e.unshift("%O");
                        let s = 0;
                        e[0] = e[0].replace(/%([a-zA-Z%])/g, ((n, o) => {
                            if ("%%" === n) return "%";
                            s++;
                            const i = t.formatters[o];
                            if ("function" == typeof i) {
                                const t = e[s];
                                n = i.call(r, t), e.splice(s, 1), s--
                            }
                            return n
                        })), t.formatArgs.call(r, e);
                        (r.log || t.log).apply(r, e)
                    }
                    return a.namespace = e, a.useColors = t.useColors(), a.color = t.selectColor(e), a.extend = r, a.destroy = t.destroy, Object.defineProperty(a, "enabled", {
                        enumerable: !0,
                        configurable: !1,
                        get: () => null !== s ? s : (o !== t.namespaces && (o = t.namespaces, i = t.enabled(e)), i),
                        set: e => {
                            s = e
                        }
                    }), "function" == typeof t.init && t.init(a), a
                }

                function r(e, n) {
                    const r = t(this.namespace + (void 0 === n ? ":" : n) + e);
                    return r.log = this.log, r
                }

                function o(e) {
                    return e.toString().substring(2, e.toString().length - 2).replace(/\.\*\?$/, "*")
                }
                return t.debug = t, t.default = t, t.coerce = function(e) {
                    if (e instanceof Error) return e.stack || e.message;
                    return e
                }, t.disable = function() {
                    const e = [...t.names.map(o), ...t.skips.map(o).map((e => "-" + e))].join(",");
                    return t.enable(""), e
                }, t.enable = function(e) {
                    let n;
                    t.save(e), t.namespaces = e, t.names = [], t.skips = [];
                    const r = ("string" == typeof e ? e : "").split(/[\s,]+/),
                        o = r.length;
                    for (n = 0; n < o; n++) r[n] && ("-" === (e = r[n].replace(/\*/g, ".*?"))[0] ? t.skips.push(new RegExp("^" + e.slice(1) + "$")) : t.names.push(new RegExp("^" + e + "$")))
                }, t.enabled = function(e) {
                    if ("*" === e[e.length - 1]) return !0;
                    let n, r;
                    for (n = 0, r = t.skips.length; n < r; n++)
                        if (t.skips[n].test(e)) return !1;
                    for (n = 0, r = t.names.length; n < r; n++)
                        if (t.names[n].test(e)) return !0;
                    return !1
                }, t.humanize = n(20770), t.destroy = function() {
                    console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.")
                }, Object.keys(e).forEach((n => {
                    t[n] = e[n]
                })), t.names = [], t.skips = [], t.formatters = {}, t.selectColor = function(e) {
                    let n = 0;
                    for (let t = 0; t < e.length; t++) n = (n << 5) - n + e.charCodeAt(t), n |= 0;
                    return t.colors[Math.abs(n) % t.colors.length]
                }, t.enable(t.load()), t
            }
        },
        20770: function(e) {
            var t = 1e3,
                n = 60 * t,
                r = 60 * n,
                o = 24 * r,
                i = 7 * o,
                s = 365.25 * o;

            function a(e, t, n, r) {
                var o = t >= 1.5 * n;
                return Math.round(e / n) + " " + r + (o ? "s" : "")
            }
            e.exports = function(e, c) {
                c = c || {};
                var u = typeof e;
                if ("string" === u && e.length > 0) return function(e) {
                    if ((e = String(e)).length > 100) return;
                    var a = /^(-?(?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)?$/i.exec(e);
                    if (!a) return;
                    var c = parseFloat(a[1]);
                    switch ((a[2] || "ms").toLowerCase()) {
                        case "years":
                        case "year":
                        case "yrs":
                        case "yr":
                        case "y":
                            return c * s;
                        case "weeks":
                        case "week":
                        case "w":
                            return c * i;
                        case "days":
                        case "day":
                        case "d":
                            return c * o;
                        case "hours":
                        case "hour":
                        case "hrs":
                        case "hr":
                        case "h":
                            return c * r;
                        case "minutes":
                        case "minute":
                        case "mins":
                        case "min":
                        case "m":
                            return c * n;
                        case "seconds":
                        case "second":
                        case "secs":
                        case "sec":
                        case "s":
                            return c * t;
                        case "milliseconds":
                        case "millisecond":
                        case "msecs":
                        case "msec":
                        case "ms":
                            return c;
                        default:
                            return
                    }
                }(e);
                if ("number" === u && isFinite(e)) return c.long ? function(e) {
                    var i = Math.abs(e);
                    if (i >= o) return a(e, i, o, "day");
                    if (i >= r) return a(e, i, r, "hour");
                    if (i >= n) return a(e, i, n, "minute");
                    if (i >= t) return a(e, i, t, "second");
                    return e + " ms"
                }(e) : function(e) {
                    var i = Math.abs(e);
                    if (i >= o) return Math.round(e / o) + "d";
                    if (i >= r) return Math.round(e / r) + "h";
                    if (i >= n) return Math.round(e / n) + "m";
                    if (i >= t) return Math.round(e / t) + "s";
                    return e + "ms"
                }(e);
                throw new Error("val is not a non-empty string or a valid number. val=" + JSON.stringify(e))
            }
        },
        6283: function(e) {
            var t, n, r = e.exports = {};

            function o() {
                throw new Error("setTimeout has not been defined")
            }

            function i() {
                throw new Error("clearTimeout has not been defined")
            }

            function s(e) {
                if (t === setTimeout) return setTimeout(e, 0);
                if ((t === o || !t) && setTimeout) return t = setTimeout, setTimeout(e, 0);
                try {
                    return t(e, 0)
                } catch (n) {
                    try {
                        return t.call(null, e, 0)
                    } catch (n) {
                        return t.call(this, e, 0)
                    }
                }
            }! function() {
                try {
                    t = "function" == typeof setTimeout ? setTimeout : o
                } catch (e) {
                    t = o
                }
                try {
                    n = "function" == typeof clearTimeout ? clearTimeout : i
                } catch (e) {
                    n = i
                }
            }();
            var a, c = [],
                u = !1,
                l = -1;

            function d() {
                u && a && (u = !1, a.length ? c = a.concat(c) : l = -1, c.length && f())
            }

            function f() {
                if (!u) {
                    var e = s(d);
                    u = !0;
                    for (var t = c.length; t;) {
                        for (a = c, c = []; ++l < t;) a && a[l].run();
                        l = -1, t = c.length
                    }
                    a = null, u = !1,
                        function(e) {
                            if (n === clearTimeout) return clearTimeout(e);
                            if ((n === i || !n) && clearTimeout) return n = clearTimeout, clearTimeout(e);
                            try {
                                n(e)
                            } catch (t) {
                                try {
                                    return n.call(null, e)
                                } catch (t) {
                                    return n.call(this, e)
                                }
                            }
                        }(e)
                }
            }

            function C(e, t) {
                this.fun = e, this.array = t
            }

            function p() {}
            r.nextTick = function(e) {
                var t = new Array(arguments.length - 1);
                if (arguments.length > 1)
                    for (var n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];
                c.push(new C(e, t)), 1 !== c.length || u || s(f)
            }, C.prototype.run = function() {
                this.fun.apply(null, this.array)
            }, r.title = "browser", r.browser = !0, r.env = {}, r.argv = [], r.version = "", r.versions = {}, r.on = p, r.addListener = p, r.once = p, r.off = p, r.removeListener = p, r.removeAllListeners = p, r.emit = p, r.prependListener = p, r.prependOnceListener = p, r.listeners = function(e) {
                return []
            }, r.binding = function(e) {
                throw new Error("process.binding is not supported")
            }, r.cwd = function() {
                return "/"
            }, r.chdir = function(e) {
                throw new Error("process.chdir is not supported")
            }, r.umask = function() {
                return 0
            }
        },
        87789: function(e) {
            e.exports = function(e, t) {
                if (null == e) return {};
                var n = {};
                for (var r in e)
                    if ({}.hasOwnProperty.call(e, r)) {
                        if (t.includes(r)) continue;
                        n[r] = e[r]
                    }
                return n
            }, e.exports.__esModule = !0, e.exports.default = e.exports
        }
    },
    function(e) {
        e.O(0, [2462], (function() {
            return t = 18892, e(e.s = t);
            var t
        }));
        e.O()
    }
]);