if (void 0 === ECF_BASE_URL) { /*var ECF_BASE_URL = "https://ecfv2.cirkleinc.com"; */
    var ECF_BASE_URL = "https://ecf.cirkleinc.com";

    function appendRecaptchaUrl() {
        let e = document.createElement("script");
        e.src = "https://www.google.com/recaptcha/api.js", e.type = "text/javascript", document.getElementsByTagName("head")[0].appendChild(e)
    }
    window.csLoadScript = function(e, t) {
        var o = document.createElement("script");
        o.type = "text/javascript", o.src = e, document.getElementsByTagName("head")[0].appendChild(o), o.readyState ? o.onreadystatechange = function() {
            "loaded" != o.readyState && "complete" != o.readyState || (o.onreadystatechange = null, t())
        } : o.onload = function() {
            t()
        }
    }, window.jQuery ? (ecfJq = window.jQuery, allLoadedAts(ecfJq)) : csLoadScript(`${ECF_BASE_URL}/public/frontend/js/jquery-3.4.1.min.js`, (function() {
        ecfJq = window.jQuery, allLoadedAts(ecfJq)
    }));
    var csLoadingCss = "\n\t\t<style>\n\t\t.cs-form-loading:after {\n\t\t\tposition: absolute;\n\t\t\tcontent: '';\n\t\t\tleft: 0;\n\t\t\ttop: 0;\n\t\t\theight: 100%;\n\t\t\twidth: 100%;\n\t\t\tbackground: rgba(255,255,255,0.3);\n\t\t\tcursor: wait;\n\t\t}\n\t\t.cs-form-loading {\n\t\t\tposition: relative;\n\t\t}\n\t\t</style>\n\t\t";
    async function allLoadedAts(ecfJq) {
        ecfJq(document).on("submit", ".cs-custom-form form, .csCustomFormDesign form", (async function(t) {
            if (t.preventDefault(), 0 === ecfJq(this).closest(".form-drag-wrap").length) {
                let t = ecfJq(this);
                var o = !0;
                if ("function" == typeof beforeSubmit && (o = beforeSubmit(t)), o) {
                    let o = ecfJq(this).attr("id");
                    await ecfJq.formAjax({
                        type: "POST",
                        url: t.attr("action"),
                        this: t,
                        file: !0,
                        container: `form#${o}`,
                        formReset: !0,
                        data: {
                            form_id: o
                        }
                    })
                }
            }
        })), ecfJq(document).on("click", ".cs-form-list-wrap .load-more-warp", (function() {
            var t = ecfJq(this).find("#load-more").data("pageUrl"),
                o = ecfJq(this);
            ecfJq.get(`${t}`, (function(e) {
                null != e.html && e.html.toString().length > 0 && (o.closest(".cs-form-list-wrap").append(e.html), o.remove())
            }))
        }))
    }

    function loadFormScript() {
        function e(t) {
            t.is("select") && t.val(t.find("option:first").val()), (t.is('[type="radio"]') || t.is('[type="checkbox"]')) && t.prop("checked", !1), t.is('[type="text"],[type="email"],[type="tel"],[type="url"],[type="number"],textarea') && t.val(""), ecfJq(`[data-condition='${t.attr("name")}']`).find("input,select,textarea").each((function() {
                e(ecfJq(this))
            }))
        }! function(t) {
            t.fn.conditionalFields = function(o) {
                var i = t(this);

                function n(o, i, n) {
                    -1 !== t.inArray(i, n) ? "none" === o.css("display") && o.slideDown(200) : "none" !== o.css("display") && (o.find("input,select,textarea").each((function() {
                        e(t(this))
                    })), o.slideUp(200))
                }

                function a() {
                    var e, o, a, r, s, c = i.closest("form").find("[data-condition][data-condition-value]");
                    t.each(c, (function() {
                        if (e = t(this), o = e.attr("data-condition"), a = e.attr("data-condition-value").toString().split("|"), (r = t('[name="' + o + '"]')).is('[type="radio"]') && (r = t('[name="' + o + '"]:checked')), 0 == r.length && (r = t('[name="' + o + '[]"]')), r.length)
                            if (1 === r.length) s = r.val().toString(), r.is('[type="checkbox"]') ? (s = r.prop("checked") ? "1" : "0", n(e, s, ["1"])) : n(e, s, a);
                            else {
                                var i = "0",
                                    c = "1",
                                    l = [];
                                $.each(r, (function(e, o) {
                                    s = t(o).val().toString(), t(this).prop("checked") && l.push(t(this).val()), r.is('[type="checkbox"]') && (s = r.prop("checked") ? "1" : "0"), -1 !== $.inArray(s, a) ? i = "1" : c = "0"
                                })), r.is('[type="checkbox"]') ? n(e, a[0], l) : (s = e.hasClass("condition-logical-or") ? i : c, n(e, s, ["1"]))
                            }
                        else "none" !== e.css("display") && e.slideUp(500)
                    }))
                }
                "init" === o && (i.on("change", ".condition-trigger", (function() {
                    a()
                })), i.on("click", ".condition-trigger-delayed", (function() {
                    var e = t(this).attr("data-delay");
                    setTimeout((function() {
                        a()
                    }), e)
                })), a()), "update" === o && a()
            }
        }(jQuery),
        function(e) {
            e.formAjax = function(t) {
                var o = {
                        type: "GET",
                        container: "body",
                        blockUI: !0,
                        disableButton: !1,
                        buttonSelector: "[type='submit']",
                        dataType: "json",
                        messagePosition: "toastr",
                        errorPosition: "field",
                        hideElements: !1,
                        redirect: !0,
                        data: {},
                        file: !1,
                        formReset: !1
                    },
                    i = o;

                function n(e, t, o) {
                    var n = i.this.find("p#msg");
                    i.this.find("div.alert").remove(), 0 == n.length ? i.this.find(".form-submit-btn-wrap").after('<div style="color: ' + ("success" == t ? "green" : "red") + '" class="alert alert-' + t + '">' + e + "</div>") : n.html('<div style="color: ' + ("success" == t ? "green" : "red") + '" class="alert alert-' + t + '">' + e + "</div>")
                }
                if (t && (i = e.extend(o, t)), "function" != typeof i.beforeSend && (i.beforeSend = function(t, o) {
                        "undefined" != typeof STORE_DOMAIN && t.setRequestHeader("store", STORE_DOMAIN), i.this.find(".has-error").each((function() {
                            ecfJq(this).find(".help-block").text(""), ecfJq(this).removeClass("has-error")
                        })), i.this.find("#alert").html(""), i.this.find("#msg").html(""), i.blockUI && e.easyBlockUI(i.this), i.disableButton && function(e) {
                            var t = i.this.find(e),
                                o = "Submitting...";
                            t.width() < 20 && (o = "...");
                            t.is("input") ? (t.attr("data-prev-text", t.val()), t.val(o), t.prop("disabled", !0)) : (t.attr("data-prev-text", t.html()), t.text(o), t.prop("disabled", !0))
                        }(i.buttonSelector)
                    }), "function" != typeof i.complete && (i.complete = function(t, o) {
                        i.blockUI && e.easyUnblockUI(i.this), i.disableButton && l(i.buttonSelector)
                    }), "function" != typeof i.error && (i.error = function(e, t, o) {
                        try {
                            i.this.find(".g-recaptcha").length > 0 && i.this.find(".g-recaptcha").attr("data-sitekey").length > 0 && void 0 !== grecaptcha && grecaptcha.reset();
                            var a = JSON.parse(e.responseText);
                            if ("object" == typeof a) c(a);
                            else {
                                var r = "A server side error occurred. Please try again after sometime.";
                                "timeout" == t && (r = "Connection timed out! Please check your internet connection"), n(r, "error")
                            }
                        } catch (e) {}
                    }), 1 == i.file) {
                    for (var a = new FormData(i.this[0]), r = Object.keys(i.data), s = 0; s < r.length; s++) a.append(r[s], i.data[r[s]]);
                    i.data = a
                }

                function c(t) {
                    if (i.blockUI && e.easyUnblockUI(i.this), i.disableButton && l(i.buttonSelector), void 0 !== t.message && n(t.message, "error"), void 0 !== t.errors) {
                        var o = Object.keys(t.errors);
                        i.this.find(".has-error").find(".help-block").remove(), i.this.find(".has-error").removeClass("has-error");
                        var a = ecfJq(i.this).hasClass("contact-form");
                        if ("field" == i.errorPosition && 0 == a) {
                            for (var r = 0; r < o.length; r++) {
                                o[r].replace(".", "\\.");
                                var s = o[r];
                                if (s.indexOf(".") > 0) {
                                    var c = s.split(".");
                                    t.errors[o[r]] = t.errors[o[r]], c[0] + "[]"
                                }
                                var d = o[r].split(".");
                                if (d.length > 4) var f = d[0] + "[" + d[1] + "][" + d[2] + "][" + d[3] + "][" + d[4] + "]",
                                    u = i.this.find("[name='" + f + "']");
                                else if (d.length > 2) {
                                    f = d[0] + "[" + d[1] + "][" + d[2] + "]";
                                    if (0 == (u = i.this.find("[name='" + f + "']")).length) u = i.this.find("[name^='" + f + "']")
                                } else u = i.this.find(" [name='" + o[r] + "']");
                                0 == u.length && (u = i.this.find("[name='" + o[r] + "[]']"));
                                var p = u.closest(".element-group");
                                ecfJq(p).find(".help-block").remove();
                                var h = ecfJq(p).find("div:first");
                                ecfJq(u).is(":radio, :checkbox") && (h = ecfJq(p).find("div:eq(2)").closest(".element-group")), 0 == h.length && (h = ecfJq(p)), h.append('<div class="help-block">' + t.errors[o[r]][0] + "</div>"), ecfJq(p).addClass("has-error")
                            }
                            if (o.length > 0) {
                                var m = i.this.find("[name='" + o[0] + "']");
                                m.length > 0 && ecfJq("html, body").animate({
                                    scrollTop: m.offset().top - 150
                                }, 200)
                            }
                        } else {
                            var v = "<ul style='list-style:none;'>";
                            for (r = 0; r < o.length; r++) v += "<li style='color:red;'>" + t.errors[o[r]] + "</li>";
                            v += "</ul>";
                            var g = i.this.find("#msg"),
                                b = '<div class="alert alert-danger">' + v + "</div>";
                            0 == g.length ? i.this.find(".form-group:first").before('<div id="alert">' + b + "</div>") : g.html(b)
                        }
                    }
                    var y = i.this.find(".recaptcha_wrap");
                    "undefined" != typeof grecaptcha && y.length && grecaptcha.reset()
                }

                function l(e) {
                    var t = i.this.find(e);
                    t.is("input") ? (t.val(t.attr("data-prev-text")), t.prop("disabled", !1)) : (t.html(t.attr("data-prev-text")), t.prop("disabled", !1))
                }
                e.ajax({
                    type: i.type,
                    url: i.url,
                    dataType: i.dataType,
                    data: i.data,
                    beforeSend: i.beforeSend,
                    contentType: !i.file && "application/x-www-form-urlencoded; charset=UTF-8",
                    processData: !i.file,
                    error: i.error,
                    complete: i.complete,
                    success: function(e) {
                        if ("success" == e.status) {
                            if (i.this.find(".recaptcha_wrap").length && grecaptcha.reset(), "function" == typeof afterSubmit && afterSubmit(i.this), "redirect" == e.action) {
                                if (i.redirect) {
                                    var t = "";
                                    void 0 !== e.message && (t += e.message), n(t += " Redirecting...", "success"), void 0 !== e.new_tab && 1 == e.new_tab ? window.open(e.url) : window.top.location.href = e.url
                                }
                            } else void 0 !== e.message && n(e.message, "success");
                            1 == i.removeElements && i.this.find(".form-group, button, input").remove(), 1 == i.formReset && (i.this[0].reset(), i.this.find("input.cs-rating").removeAttr("value"), initializeCurrentFormRating(i.this))
                        }
                        "fail" == e.status && c(e), "function" == typeof i.success && i.success(e)
                    }
                })
            }, e.easyBlockUI = function(t, o) {
                null == o && (o = "Loading...");
                var i = '<div class="loading-message"><div class="block-spinner-bar"><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div></div>';
                if (null != t) {
                    var n = ecfJq(t),
                        a = !1;
                    n.height() <= ecfJq(window).height() && (a = !0), n.block({
                        message: i,
                        baseZ: 999999,
                        centerY: a,
                        css: {
                            top: "10%",
                            border: "0",
                            padding: "0",
                            backgroundColor: "none"
                        },
                        overlayCSS: {
                            backgroundColor: "transparent",
                            opacity: .05,
                            cursor: "wait"
                        }
                    })
                } else e.blockUI({
                    message: i,
                    baseZ: 999999,
                    css: {
                        border: "0",
                        padding: "0",
                        backgroundColor: "none"
                    },
                    overlayCSS: {
                        backgroundColor: "#555",
                        opacity: .05,
                        cursor: "wait"
                    }
                })
            }, e.easyUnblockUI = function(t) {
                null == t ? e.unblockUI() : ecfJq(t).unblock({
                    onUnblock: function() {
                        ecfJq(t).css("position", ""), ecfJq(t).css("zoom", "")
                    }
                })
            }, e.showErrors = function(e) {
                var t = Object.keys(e);
                ecfJq(".has-error").find(".help-block").remove(), ecfJq(".has-error").removeClass("has-error");
                for (var o = 0; o < t.length; o++) {
                    var i = ecfJq("[name='" + t[o] + "']");
                    0 == i.length && (i = ecfJq("#" + t[o]));
                    var n = i.closest(".form-group");
                    ecfJq(n).find(".help-block").remove();
                    var a = ecfJq(n).find("div:first");
                    0 == a.length && (a = ecfJq(n)), a.append('<div class="help-block">' + e[t[o]] + "</div>"), ecfJq(n).addClass("has-error")
                }
            }, e.showErrorsMul = function(e) {
                if (void 0 !== typeof e.errors) {
                    var t = e.errors,
                        o = Object.keys(t);
                    ecfJq(".has-error").find(".help-block").remove(), ecfJq(".has-error").removeClass("has-error");
                    for (var i = 0; i < o.length; i++) {
                        var n = o[i].split(".");
                        if (n.length > 2) var a = n[0] + "[" + n[1] + "][" + n[2] + "]",
                            r = ecfJq("[name='" + a + "']");
                        else r = ecfJq("[name='" + o[i] + "']");
                        0 == r.length && (r = ecfJq("#" + o[i]));
                        var s = r.closest(".form-group");
                        ecfJq(s).find(".help-block").remove();
                        var c = ecfJq(s).find("div:first");
                        0 == c.length && (c = ecfJq(s)), c.append('<div class="help-block">' + t[o[i]] + "</div>"), ecfJq(s).addClass("has-error")
                    }
                }
            }
        }(jQuery),
        function() {
            function e(e) {
                function t(t, i) {
                    var a, h, m = t == window,
                        v = i && void 0 !== i.message ? i.message : void 0;
                    if (!(i = e.extend({}, e.blockUI.defaults, i || {})).ignoreIfBlocked || !e(t).data("blockUI.isBlocked")) {
                        if (i.overlayCSS = e.extend({}, e.blockUI.defaults.overlayCSS, i.overlayCSS || {}), a = e.extend({}, e.blockUI.defaults.css, i.css || {}), i.onOverlayClick && (i.overlayCSS.cursor = "pointer"), h = e.extend({}, e.blockUI.defaults.themedCSS, i.themedCSS || {}), v = void 0 === v ? i.message : v, m && u && o(window, {
                                fadeOut: 0
                            }), v && "string" != typeof v && (v.parentNode || v.jquery)) {
                            var g = v.jquery ? v[0] : v,
                                b = {};
                            e(t).data("blockUI.history", b), b.el = g, b.parent = g.parentNode, b.display = g.style.display, b.position = g.style.position, b.parent && b.parent.removeChild(g)
                        }
                        e(t).data("blockUI.onUnblock", i.onUnblock);
                        var y, k, w, S, q = i.baseZ;
                        y = e(l || i.forceIframe ? '<iframe class="blockUI" style="z-index:' + q++ + ';display:none;border:none;margin:0;padding:0;position:absolute;width:100%;height:100%;top:0;left:0" src="' + i.iframeSrc + '"></iframe>' : '<div class="blockUI" style="display:none"></div>'), k = e(i.theme ? '<div class="blockUI blockOverlay ui-widget-overlay" style="z-index:' + q++ + ';display:none"></div>' : '<div class="blockUI blockOverlay" style="z-index:' + q++ + ';display:none;border:none;margin:0;padding:0;width:100%;height:100%;top:0;left:0"></div>'), i.theme && m ? (S = '<div class="blockUI ' + i.blockMsgClass + ' blockPage ui-dialog ui-widget ui-corner-all" style="z-index:' + (q + 10) + ';display:none;position:fixed">', i.title && (S += '<div class="ui-widget-header ui-dialog-titlebar ui-corner-all blockTitle">' + (i.title || "&nbsp;") + "</div>"), S += '<div class="ui-widget-content ui-dialog-content"></div>', S += "</div>") : i.theme ? (S = '<div class="blockUI ' + i.blockMsgClass + ' blockElement ui-dialog ui-widget ui-corner-all" style="z-index:' + (q + 10) + ';display:none;position:absolute">', i.title && (S += '<div class="ui-widget-header ui-dialog-titlebar ui-corner-all blockTitle">' + (i.title || "&nbsp;") + "</div>"), S += '<div class="ui-widget-content ui-dialog-content"></div>', S += "</div>") : S = m ? '<div class="blockUI ' + i.blockMsgClass + ' blockPage" style="z-index:' + (q + 10) + ';display:none;position:fixed"></div>' : '<div class="blockUI ' + i.blockMsgClass + ' blockElement" style="z-index:' + (q + 10) + ';display:none;position:absolute"></div>', w = e(S), v && (i.theme ? (w.css(h), w.addClass("ui-widget-content")) : w.css(a)), i.theme || k.css(i.overlayCSS), k.css("position", m ? "fixed" : "absolute"), (l || i.forceIframe) && y.css("opacity", 0);
                        var I = [y, k, w],
                            J = e(m ? "body" : t);
                        e.each(I, (function() {
                            this.appendTo(J)
                        })), i.theme && i.draggable && e.fn.draggable && w.draggable({
                            handle: ".ui-dialog-titlebar",
                            cancel: "li"
                        });
                        var U = f && (!e.support.boxModel || e("object,embed", m ? null : t).length > 0);
                        if (d || U) {
                            if (m && i.allowBodyStretch && e.support.boxModel && e("html,body").css("height", "100%"), (d || !e.support.boxModel) && !m) var x = s(t, "borderTopWidth"),
                                C = s(t, "borderLeftWidth"),
                                E = x ? "(0 - " + x + ")" : 0,
                                T = C ? "(0 - " + C + ")" : 0;
                            e.each(I, (function(e, t) {
                                var o = t[0].style;
                                if (o.position = "absolute", 2 > e) m ? o.setExpression("height", "Math.max(document.body.scrollHeight, document.body.offsetHeight) - (jQuery.support.boxModel?0:" + i.quirksmodeOffsetHack + ') + "px"') : o.setExpression("height", 'this.parentNode.offsetHeight + "px"'), m ? o.setExpression("width", 'jQuery.support.boxModel && document.documentElement.clientWidth || document.body.clientWidth + "px"') : o.setExpression("width", 'this.parentNode.offsetWidth + "px"'), T && o.setExpression("left", T), E && o.setExpression("top", E);
                                else if (i.centerY) m && o.setExpression("top", '(document.documentElement.clientHeight || document.body.clientHeight) / 2 - (this.offsetHeight / 2) + (blah = document.documentElement.scrollTop ? document.documentElement.scrollTop : document.body.scrollTop) + "px"'), o.marginTop = 0;
                                else if (!i.centerY && m) {
                                    var n = "((document.documentElement.scrollTop ? document.documentElement.scrollTop : document.body.scrollTop) + " + (i.css && i.css.top ? parseInt(i.css.top, 10) : 0) + ') + "px"';
                                    o.setExpression("top", n)
                                }
                            }))
                        }
                        if (v && (i.theme ? w.find(".ui-widget-content").append(v) : w.append(v), (v.jquery || v.nodeType) && e(v).show()), (l || i.forceIframe) && i.showOverlay && y.show(), i.fadeIn) {
                            var O = i.onBlock ? i.onBlock : c,
                                _ = i.showOverlay && !v ? O : c,
                                j = v ? O : c;
                            i.showOverlay && k._fadeIn(i.fadeIn, _), v && w._fadeIn(i.fadeIn, j)
                        } else i.showOverlay && k.show(), v && w.show(), i.onBlock && i.onBlock.bind(w)();
                        if (n(1, t, i), m ? (u = w[0], p = e(i.focusableElements, u), i.focusInput && setTimeout(r, 20)) : function(e, t, o) {
                                var i = e.parentNode,
                                    n = e.style,
                                    a = (i.offsetWidth - e.offsetWidth) / 2 - s(i, "borderLeftWidth"),
                                    r = (i.offsetHeight - e.offsetHeight) / 2 - s(i, "borderTopWidth");
                                t && (n.left = a > 0 ? a + "px" : "0"), o && (n.top = r > 0 ? r + "px" : "0")
                            }(w[0], i.centerX, i.centerY), i.timeout) {
                            var B = setTimeout((function() {
                                m ? e.unblockUI(i) : e(t).unblock(i)
                            }), i.timeout);
                            e(t).data("blockUI.timeout", B)
                        }
                    }
                }

                function o(t, o) {
                    var a, r, s = t == window,
                        c = e(t),
                        l = c.data("blockUI.history"),
                        d = c.data("blockUI.timeout");
                    d && (clearTimeout(d), c.removeData("blockUI.timeout")), o = e.extend({}, e.blockUI.defaults, o || {}), n(0, t, o), null === o.onUnblock && (o.onUnblock = c.data("blockUI.onUnblock"), c.removeData("blockUI.onUnblock")), r = s ? e("body").children().filter(".blockUI").add("body > .blockUI") : c.find(">.blockUI"), o.cursorReset && (r.length > 1 && (r[1].style.cursor = o.cursorReset), r.length > 2 && (r[2].style.cursor = o.cursorReset)), s && (u = p = null), o.fadeOut ? (a = r.length, r.stop().fadeOut(o.fadeOut, (function() {
                        0 == --a && i(r, l, o, t)
                    }))) : i(r, l, o, t)
                }

                function i(t, o, i, n) {
                    var a = e(n);
                    if (!a.data("blockUI.isBlocked")) {
                        t.each((function() {
                            this.parentNode && this.parentNode.removeChild(this)
                        })), o && o.el && (o.el.style.display = o.display, o.el.style.position = o.position, o.el.style.cursor = "default", o.parent && o.parent.appendChild(o.el), a.removeData("blockUI.history")), a.data("blockUI.static") && a.css("position", "static"), "function" == typeof i.onUnblock && i.onUnblock(n, i);
                        var r = e(document.body),
                            s = r.width(),
                            c = r[0].style.width;
                        r.width(s - 1).width(s), r[0].style.width = c
                    }
                }

                function n(t, o, i) {
                    var n = o == window,
                        r = e(o);
                    if ((t || (!n || u) && (n || r.data("blockUI.isBlocked"))) && (r.data("blockUI.isBlocked", t), n && i.bindEvents && (!t || i.showOverlay))) {
                        var s = "mousedown mouseup keydown keypress keyup touchstart touchend touchmove";
                        t ? e(document).bind(s, i, a) : e(document).unbind(s, a)
                    }
                }

                function a(t) {
                    if ("keydown" === t.type && t.keyCode && 9 == t.keyCode && u && t.data.constrainTabKey) {
                        var o = p,
                            i = !t.shiftKey && t.target === o[o.length - 1],
                            n = t.shiftKey && t.target === o[0];
                        if (i || n) return setTimeout((function() {
                            r(n)
                        }), 10), !1
                    }
                    var a = t.data,
                        s = e(t.target);
                    return s.hasClass("blockOverlay") && a.onOverlayClick && a.onOverlayClick(t), s.parents("div." + a.blockMsgClass).length > 0 || 0 === s.parents().children().filter("div.blockUI").length
                }

                function r(e) {
                    if (p) {
                        var t = p[!0 === e ? p.length - 1 : 0];
                        t && t.focus()
                    }
                }

                function s(t, o) {
                    return parseInt(e.css(t, o), 10) || 0
                }
                e.fn._fadeIn = e.fn.fadeIn;
                var c = e.noop || function() {},
                    l = /MSIE/.test(navigator.userAgent),
                    d = /MSIE 6.0/.test(navigator.userAgent) && !/MSIE 8.0/.test(navigator.userAgent),
                    f = (document.documentMode, e.isFunction(document.createElement("div").style.setExpression));
                e.blockUI = function(e) {
                    t(window, e)
                }, e.unblockUI = function(e) {
                    o(window, e)
                }, e.growlUI = function(t, o, i, n) {
                    var a = e('<div class="growlUI"></div>');
                    t && a.append("<h1>" + t + "</h1>"), o && a.append("<h2>" + o + "</h2>"), void 0 === i && (i = 3e3);
                    var r = function(t) {
                        t = t || {}, e.blockUI({
                            message: a,
                            fadeIn: void 0 !== t.fadeIn ? t.fadeIn : 700,
                            fadeOut: void 0 !== t.fadeOut ? t.fadeOut : 1e3,
                            timeout: void 0 !== t.timeout ? t.timeout : i,
                            centerY: !1,
                            showOverlay: !1,
                            onUnblock: n,
                            css: e.blockUI.defaults.growlCSS
                        })
                    };
                    r(), a.css("opacity"), a.mouseover((function() {
                        r({
                            fadeIn: 0,
                            timeout: 3e4
                        });
                        var t = e(".blockMsg");
                        t.stop(), t.fadeTo(300, 1)
                    })).mouseout((function() {
                        e(".blockMsg").fadeOut(1e3)
                    }))
                }, e.fn.block = function(o) {
                    if (this[0] === window) return e.blockUI(o), this;
                    var i = e.extend({}, e.blockUI.defaults, o || {});
                    return this.each((function() {
                        var t = e(this);
                        i.ignoreIfBlocked && t.data("blockUI.isBlocked") || t.unblock({
                            fadeOut: 0
                        })
                    })), this.each((function() {
                        "static" == e.css(this, "position") && (this.style.position = "relative", e(this).data("blockUI.static", !0)), this.style.zoom = 1, t(this, o)
                    }))
                }, e.fn.unblock = function(t) {
                    return this[0] === window ? (e.unblockUI(t), this) : this.each((function() {
                        o(this, t)
                    }))
                }, e.blockUI.version = 2.7, e.blockUI.defaults = {
                    message: "<h1>Please wait...</h1>",
                    title: null,
                    draggable: !0,
                    theme: !1,
                    css: {
                        padding: 0,
                        margin: 0,
                        width: "30%",
                        top: "40%",
                        left: "35%",
                        textAlign: "center",
                        color: "#000",
                        border: "3px solid #aaa",
                        backgroundColor: "#fff",
                        cursor: "wait"
                    },
                    themedCSS: {
                        width: "30%",
                        top: "40%",
                        left: "35%"
                    },
                    overlayCSS: {
                        backgroundColor: "#000",
                        opacity: .6,
                        cursor: "wait"
                    },
                    cursorReset: "default",
                    growlCSS: {
                        width: "350px",
                        top: "10px",
                        left: "",
                        right: "10px",
                        border: "none",
                        padding: "5px",
                        opacity: .6,
                        cursor: "default",
                        color: "#fff",
                        backgroundColor: "#000",
                        "-webkit-border-radius": "10px",
                        "-moz-border-radius": "10px",
                        "border-radius": "10px"
                    },
                    iframeSrc: /^https/i.test(window.location.href || "") ? "javascript:false" : "about:blank",
                    forceIframe: !1,
                    baseZ: 1e3,
                    centerX: !0,
                    centerY: !0,
                    allowBodyStretch: !0,
                    bindEvents: !0,
                    constrainTabKey: !0,
                    fadeIn: 200,
                    fadeOut: 400,
                    timeout: 0,
                    showOverlay: !0,
                    focusInput: !0,
                    focusableElements: ":input:enabled:visible",
                    onBlock: null,
                    onUnblock: null,
                    onOverlayClick: null,
                    quirksmodeOffsetHack: 4,
                    blockMsgClass: "blockMsg",
                    ignoreIfBlocked: !1
                };
                var u = null,
                    p = []
            }
            "function" == typeof define && define.amd && define.amd.jQuery ? define(["jquery"], e) : e(jQuery)
        }(), ecfJq(".cs-form-list-wrap").each((function(e, t) {
            let o = ecfJq(this);
            null != o.data("key") && ecfJq(this).load(`${ECF_BASE_URL}/get-display-html/${o.data("key")}`, {}, (function(e, t, o) {
                var i = $.parseJSON(e);
                if (ecfJq(this).html(i.html), "success" != t) {
                    e = JSON.parse(e);
                    console.log(`%c ${e.message}`, "background: #615c5a; color: #ed5628; font-size: 20px;")
                }
            }))
        }))
    }

    function initializePickers() {
        void 0 !== $.fn.datetimepicker && (ecfJq(".cs-datepicker").each((function(e) {
            var t = ecfJq(this).attr("data-format"),
                o = ecfJq(this).attr("data-previous-date"),
                i = ecfJq(this).attr("data-prevent-days");
            let n = [];
            "" != i && void 0 !== i && i.split(",").forEach((e => {
                n.push(parseInt(e))
            }));
            var a = ecfJq(this).attr("data-disable-date-list");
            if ("" != a && null != a) var r = a.split(",");
            ecfJq(this).datetimepicker({
                onSelectTime: function(e, t) {
                    var o = moment(e).format("YYYY/MM/DD"),
                        i = moment().day();
                    n.includes(i) && t.val().includes(o) && t.val(""), void 0 !== r && r.includes(o) && t.val("")
                },
                format: null != t && "" != t ? t : "Y/m/d",
                validateOnBlur: !1,
                timepicker: !1,
                datepicker: !0,
                autoclose: !0,
                todayHighlight: !1,
                minDate: "true" == o && o,
                disabledDates: r,
                disabledWeekDays: n,
                scrollMonth: !1,
                scrollInput: !1,
                todayButton: !1
            })
        })), ecfJq(".cs-time-picker").each((function(e) {
            var t = ecfJq(this).attr("data-format");
            let o = {
                format: null != t && "" != t ? t : "H:i",
                formatTime: null != t && "" != t ? t : "H:i",
                validateOnBlur: !1,
                timepicker: !0,
                datepicker: !1,
                autoclose: !0,
                scrollMonth: !1,
                scrollInput: !1
            };
            ecfJq(this).datetimepicker(o)
        })), ecfJq(".cs-datetimepicker").each((function(e) {
            var t = ecfJq(this).attr("data-format"),
                o = ecfJq(this).attr("data-previous-date"),
                i = ecfJq(this).attr("data-prevent-days");
            let n = [];
            "" != i && void 0 !== i && i.split(",").forEach((e => {
                var t = parseInt(e);
                n.push(t)
            }));
            var a = ecfJq(this).attr("data-disable-date-list");
            if ("" != a && null != a) var r = a.split(",");
            if (void 0 !== t) var s = -1 != t.indexOf("h") ? t.substring(t.indexOf("h")) : "H:i";
            var c = {
                onSelectTime: function(e, t) {
                    var i = moment(e).format("YYYY/MM/DD"),
                        a = moment().format("YYYY/MM/DD"),
                        s = moment(e).day();
                    n.includes(s) && t.val().includes(i) && t.val(""), void 0 !== r && r.includes(i) && t.val(""), "true" == o && moment(i).isBefore(a) && t.val("")
                },
                onSelectDate: function(e, t) {
                    moment(e).format("H:i")
                },
                format: null != t && "" != t ? t : "Y/m/d H:i",
                formatTime: s,
                validateOnBlur: !1,
                timepicker: !0,
                datepicker: !0,
                autoclose: !0,
                todayHighlight: !0,
                minDate: "true" == o && o,
                disabledDates: r,
                disabledWeekDays: n,
                scrollMonth: !1,
                scrollInput: !1,
                defaultSelect: !1,
                todayButton: !1
            };
            ecfJq(this).datetimepicker(c)
        })))
    }

    function loadRatingScript() {
        if (void 0 === $.fn.CSRating) {
            var e = document.createElement("script");
            e.src = `${ECF_BASE_URL}/public/frontend/js/cs-rating.js`, e.type = "text/javascript", e.addEventListener("load", initializeRating), document.getElementsByTagName("head")[0].appendChild(e)
        }
        void 0 !== $.fn.CSRating && initializeRating()
    }

    function initializeRating() {
        setTimeout((() => {
            ecfJq("input.cs-rating").each((function(e) {
                ecfJq(this).next(".simple-rating.star-rating").remove(), ecfJq(this).CSRating({
                    fontSize: ecfJq(this).attr("data-size"),
                    color: ecfJq(this).attr("data-color")
                })
            }))
        }), 100)
    }

    function initializeCurrentFormRating(e) {
        setTimeout((() => {
            e.find("input.cs-rating").next(".simple-rating.star-rating").remove(), e.find("input.cs-rating").CSRating({
                fontSize: ecfJq(this).attr("data-size"),
                color: ecfJq(this).attr("data-color")
            })
        }), 100)
    }

    function initCondition() {
        ecfJq(".cs-custom-form form").each((function() {
            0 === ecfJq(this).closest(".form-drag-wrap").length && ecfJq(this).conditionalFields("init")
        }))
    }

    function loadPickerScript(e, t) {
        var o = !1;
        if (e.find("input").each((function(e) {
                ecfJq(this).is(".cs-datepicker, .cs-time-picker, .cs-datetimepicker") && (o = !0)
            })), void 0 === $.fn.datetimepicker && o) {
            var i = document.createElement("script");
            i.src = `${ECF_BASE_URL}/public/frontend/js/jquery.datetimepicker.full.min.js`, i.type = "text/javascript", i.addEventListener("load", initializePickers), document.getElementsByTagName("head")[0].appendChild(i), ecfJq("<link/>", {
                rel: "stylesheet",
                type: "text/css",
                href: `${ECF_BASE_URL}/public/frontend/css/jquery.datetimepicker.min.css`
            }).appendTo("head")
        }
        if ("undefined" == typeof moment && o) {
            var n = document.createElement("script");
            n.src = `${ECF_BASE_URL}/public/frontend/js/moment.js`, n.type = "text/javascript", n.addEventListener("load", initializePickers), document.getElementsByTagName("head")[0].appendChild(n)
        }
        initializePickers(), "undefined" != typeof csFormShotcodeLoded && "function" == typeof csFormShotcodeLoded && void 0 !== t && csFormShotcodeLoded(t)
    }

    function renderReCaptcha() {
        void 0 === window.__google_recaptcha_client && appendRecaptchaUrl(), ecfJq(".cs-custom-form form, .csCustomFormDesign form").each((function(e, t) {
            var o = ecfJq(this);
            if (loadFormScript(), loadPickerScript(o), loadRatingScript(), (a = ecfJq(this).find(".recaptcha_wrap")).length) {
                var i = ecfJq(this).attr("id"),
                    n = a.attr("id");
                $.ajax({
                    type: "GET",
                    url: `${ECF_BASE_URL}/get-g-site-key/${i}`,
                    success: function(e) {
                        void 0 !== e.site_key && "" != e.site_key && setTimeout((function() {
                            grecaptcha.render(n, {
                                sitekey: e.site_key
                            })
                        }), 1200)
                    }
                })
            } else {
                var a;
                (a = ecfJq(this).find("#g-recaptcha")).length && grecaptcha.render("g-recaptcha", {
                    sitekey: a.data("sitekey")
                })
            }
        }))
    }
    async function formAppend() {
        "undefined" != typeof jQuery ? ecfJq(document).ready((function() {
            ecfJq(".cs-form-parent-warp").each((function(e, t) {
                let o = ecfJq(this),
                    i = o.data("key");
                null != i && ecfJq(this).load(`${ECF_BASE_URL}/get-form-html/${o.data("key")}`, {}, (function(e, t, n) {
                    var a = $.parseJSON(e);
                    if (ecfJq(this).html(a.html), setTimeout((() => {
                            "function" == typeof afterRenderHtml && afterRenderHtml(ecfJq(`form#${o.data("key")}`))
                        }), 100), loadFormScript(), loadPickerScript(o, i), loadRatingScript(), ecfJq(this).find("form.cs-form-wrap").conditionalFields("init"), null != a.google_recaptcha_site_key) {
                        var r = ecfJq(this).find(".recaptcha_wrap");
                        if (r.length) {
                            var s = r.attr("id");
                            setTimeout((function() {
                                grecaptcha.render(s, {
                                    sitekey: a.google_recaptcha_site_key
                                })
                            }), 1200)
                        }
                    }
                    if ("success" != t) {
                        e = JSON.parse(e);
                        console.log(`%c ${e.message}`, "background: #615c5a; color: #ed5628; font-size: 20px;")
                    }
                }))
            })), loadFormScript(), initCondition(), renderReCaptcha()
        })) : setTimeout((() => {
            formAppend()
        }), 500)
    }
    formAppend()
}