{
    "token": "bc9b7b15ea8c0ec797a347b6eeac76e3",
    "note": null,
    "attributes": {},
    "original_total_price": 0,
    "total_price": 0,
    "total_discount": 0,
    "total_weight": 0.0,
    "item_count": 0,
    "items": [],
    "requires_shipping": false,
    "currency": "USD",
    "items_subtotal_price": 0,
    "cart_level_discount_applications": []
}