"use strict";
(self.webpackChunk_klaviyo_onsite_modules = self.webpackChunk_klaviyo_onsite_modules || []).push([
    [135], {
        32820: function(e, t, n) {
            const o = {
                ref: () => {},
                attributes: {},
                listeners: {},
                collected: {},
                className: ""
            };
            t.Z = ({
                children: e
            }) => e(o)
        },
        51301: function(e, t, n) {
            n.d(t, {
                c: function() {
                    return zt
                }
            });
            var o = n(78542),
                i = n(95775),
                r = n.n(i),
                s = n(76223),
                l = n.n(s),
                a = n(39263),
                d = n(87789),
                c = n.n(d),
                m = n(87974),
                u = n(62839),
                f = n(75186);
            const p = ["children", "actionId", "formVersionCId"];
            var h = e => {
                let {
                    children: t,
                    actionId: n,
                    formVersionCId: o
                } = e, i = c()(e, p);
                const [r, l] = (0, s.useState)(!1), a = (0, f.Z)((e => {
                    var t;
                    return e.formsState.actions && n ? null == (t = e.formsState.actions[n]) ? void 0 : t.actionType : void 0
                })), d = (0, f.Z)((e => {
                    var t;
                    return e.formsState.actions && n ? null == (t = e.formsState.actions[n]) || null == (t = t.data) ? void 0 : t.newWindow : void 0
                })), h = (0, f.Z)((e => {
                    var t;
                    return e.formsState.actions && n ? null == (t = e.formsState.actions[n]) || null == (t = t.data) ? void 0 : t.redirectUrl : void 0
                })), v = (0, s.useMemo)((() => n && a ? (0, u.l9)(a, {
                    newWindow: d,
                    redirectUrl: h
                }) : {}), [n, a, d, h]);
                if (!n) return t(Object.assign({
                    onClick: void 0,
                    handlingFormAction: r,
                    ariaProps: v
                }, i));
                const y = (0, m.j)({
                    actionId: n,
                    formVersionCId: o
                });
                if (!y) return t(Object.assign({
                    onClick: void 0,
                    handlingFormAction: r,
                    ariaProps: v
                }, i));
                const g = new y({
                    actionId: n,
                    formVersionCId: o
                });
                return t(Object.assign({
                    onClick: n ? () => {
                        y.formActionType && u.NB.has(y.formActionType) && l(!0), g.runAction().catch((() => {
                            l(!1);
                            const e = document.querySelector(`.klaviyo-form-version-cid_${o} [aria-invalid="true"]`);
                            e && e.focus()
                        }))
                    } : void 0,
                    handlingFormAction: r,
                    ariaProps: v
                }, i))
            };
            const v = () => null;
            var y = ({
                    formVersionCId: e,
                    componentId: t,
                    a11yIdentifierBlock: n
                }) => {
                    const o = (0, f.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                        i = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.styling
                        })),
                        s = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.image
                        })),
                        d = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.altText
                        })),
                        c = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) ? void 0 : n.actionId
                        })),
                        m = c ? a.aG : a.Ei,
                        u = (null == i ? void 0 : i.width) || 100;
                    return l().createElement(a.ZC, {
                        style: {
                            display: "flex",
                            alignItems: "center",
                            width: "100%",
                            height: "auto"
                        },
                        a11yIdentifier: n
                    }, o && !s ? l().createElement(v, null) : s && l().createElement(h, {
                        actionId: c,
                        formVersionCId: e
                    }, (({
                        onClick: e,
                        handlingFormAction: t,
                        ariaProps: i
                    }) => l().createElement(a.ZC, {
                        className: t ? "klaviyo-spinner" : "",
                        style: {
                            position: "relative",
                            display: "flex",
                            alignItems: "center",
                            width: "100%",
                            height: "auto"
                        },
                        onClick: e,
                        a11yIdentifier: n
                    }, l().createElement(m, r()({
                        a11yIdentifier: n,
                        style: {
                            maxWidth: "100%",
                            width: u,
                            height: "auto",
                            cursor: e ? "pointer" : "initial"
                        },
                        src: s.url,
                        tabIndex: o || !c ? -1 : 0
                    }, d && d.length > 0 ? {
                        alt: d
                    } : {}, i))))))
                },
                g = (n(26650), n(92461), n(39265), n(80101)),
                I = n(94926),
                b = n(23034),
                S = n(32681),
                w = n(31274),
                x = n(70554),
                C = n(3689),
                E = n(98889),
                k = n(89709),
                $ = n(19931),
                T = n(71002),
                V = n(95223),
                Z = n(52266),
                _ = n(23759);
            let O, F = e => e;
            var M = ({
                    formVersionCId: e,
                    componentId: t,
                    theme: n,
                    a11yIdentifierStyles: i
                }) => {
                    var r;
                    const d = (0, f.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                        c = (0, f.Z)((n => {
                            var o;
                            const i = null == (o = n.onsiteState.openFormVersions[e]) ? void 0 : o.components[t];
                            return !!n.onsiteState.client.isDesignWorkflow || !i || i.valid || void 0 === i.valid
                        })),
                        m = (0, f.Z)((n => {
                            var o;
                            return null == (o = n.onsiteState.openFormVersions[e]) || null == (o = o.components[t]) ? void 0 : o.metadata
                        }), b.X),
                        u = (0, f.Z)((n => {
                            var o;
                            return null == (o = n.onsiteState.openFormVersions[e]) || null == (o = o.components[t]) ? void 0 : o.validationErrorType
                        })),
                        p = (0, f.Z)((n => (0, Z.HN)(n, e, t))),
                        h = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.required
                        })),
                        v = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.label
                        })),
                        y = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.showLabel
                        })),
                        M = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.placeholder
                        })),
                        A = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) ? void 0 : n.componentType
                        })),
                        D = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.fieldId
                        })),
                        N = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.format
                        })),
                        B = (0, f.Z)((e => {
                            var n;
                            return (null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.delimiter) || ""
                        })),
                        R = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.prefill
                        })),
                        j = (0, f.Z)((t => {
                            var n;
                            return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.formId
                        })),
                        z = (0, f.Z)((t => {
                            var n;
                            return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.formVersionId
                        })),
                        W = (0, f.Z)((e => e.onsiteState.client.klaviyoCompanyId)),
                        P = (0, f.Z)((t => (0, Z.wf)(t, e))),
                        L = (0, f.Z)((e => {
                            const n = e.formsState.components[t];
                            return void 0 !== n && (0, _.En)(n)
                        })),
                        H = (0, s.useMemo)((() => A === o.ZW || A === o.Ys), [A]),
                        q = (0, s.useMemo)((() => `${null==D?void 0:D.replace(/ /g,"_").replace(/\$/g,"")}_${t}`), [D, t]),
                        U = (0, s.useMemo)((() => A === o.eC ? "one-time-code" : D && o.no[D] ? o.no[D] : void 0), [D, A]),
                        {
                            current: K
                        } = (0, s.useRef)((0, g.Z)("klaviyo_ariaid_")),
                        [G, Y] = (0, s.useState)(!1),
                        [X, J] = (0, s.useState)(),
                        Q = ({
                            value: n,
                            validate: i,
                            hasChangedSinceLastValidation: r
                        }) => {
                            var s;
                            const l = void 0 !== n ? n : "";
                            J(l), Y(!!r), (0, E.hX)({
                                formVersionCId: e,
                                componentId: t,
                                value: H ? null == (s = o.Tb.find((({
                                    value: e
                                }) => JSON.stringify(e) === JSON.stringify(N)))) ? void 0 : s.convertValue(l, B) : l,
                                validate: i
                            })
                        };
                    (0, s.useEffect)((() => {
                        const e = (0, S.FU)();
                        if (R && e && A === o.xC && !d) {
                            const {
                                [o.HD]: t
                            } = e;
                            Q({
                                value: t,
                                validate: !1
                            })
                        }
                    }), []), (0, s.useEffect)((() => {
                        L && !d && j && e && P && ((0, T.WN)(j), W && (0, k.M)({
                            metric: V.mC,
                            formVersionCId: e,
                            formId: j,
                            companyId: W
                        }))
                    }), [L, d, j, W, e, P, z]);
                    const ee = (0, s.useMemo)((() => `label-${q}`), [q]),
                        te = (0, s.useMemo)((() => v ? void 0 : M), [v, M]),
                        ne = G || c,
                        oe = H && !M ? null == (r = o.Tb.find((({
                            value: e
                        }) => JSON.stringify(e) === JSON.stringify(N)))) ? void 0 : r.label.replace(/ /g, B) : M,
                        ie = H ? w.n : a.II;
                    return l().createElement(a.ZC, {
                        style: {
                            display: "flex",
                            flexGrow: 1,
                            flexDirection: "column",
                            alignSelf: "flex-end"
                        },
                        a11yIdentifier: i
                    }, l().createElement(x.Z, {
                        id: ee,
                        a11yIdentifier: i,
                        theme: n,
                        htmlFor: q,
                        showLabel: !(void 0 !== y || !v) || y
                    }, v), l().createElement(ie, {
                        id: q,
                        className: (0, I.iv)(O || (O = F `
          &&& {
            &::placeholder {
              color: ${0};
              font-family: ${0};
              font-size: ${0};
              font-weight: ${0};
              letter-spacing: ${0}px;
            }
            &::-moz-placeholder {
              line-height: ${0}px;
            }
            &:hover {
              border-color: ${0} !important;
            }
            &:focus-visible {
              outline-width: 2px;
              outline-style: auto;
              outline-color: ${0};
              outline-offset: 0;
            }
          }
        `), n.inputStyles.textStyles.placeholderColor, n.inputStyles.textStyles.fontFamily, n.inputStyles.textStyles.fontSize, n.inputStyles.textStyles.fontWeight, n.inputStyles.textStyles.letterSpacing, n.inputStyles.textStyles.height, n.inputStyles.border.activeColor, ne ? n.inputStyles.border.activeColor || n.focusColor : n.inputStyles.border.errorColor),
                        style: {
                            boxSizing: "border-box",
                            borderRadius: n.inputStyles.borderRadius,
                            paddingLeft: 16,
                            paddingRight: 0,
                            paddingTop: 0,
                            paddingBottom: 0,
                            height: n.inputStyles.textStyles.height,
                            textAlign: "left",
                            color: n.inputStyles.textStyles.formInputTextColor,
                            fontFamily: n.inputStyles.textStyles.fontFamily,
                            fontSize: n.inputStyles.textStyles.fontSize,
                            fontWeight: n.inputStyles.textStyles.fontWeight,
                            letterSpacing: n.inputStyles.textStyles.letterSpacing,
                            backgroundColor: n.inputStyles.inputBackgroundColor,
                            border: "1px solid",
                            borderColor: n.inputStyles.border[ne ? "defaultColor" : "errorColor"]
                        },
                        type: (e => {
                            switch (e) {
                                case o.xC:
                                    return "email";
                                case o.J8:
                                    return "tel";
                                default:
                                    return "text"
                            }
                        })(A),
                        autoComplete: U,
                        name: A === o.xC ? "email" : void 0,
                        tabIndex: d ? -1 : 0,
                        placeholder: oe,
                        "aria-label": te,
                        "aria-required": h || void 0,
                        "aria-invalid": !ne,
                        "aria-describedby": ne ? void 0 : K,
                        onInit: () => {
                            d || (0, E.DK)({
                                formVersionCId: e,
                                componentId: t
                            })
                        },
                        onBlur: e => Q({
                            value: e.target.value,
                            validate: !1,
                            hasChangedSinceLastValidation: !1
                        }),
                        onChange: e => {
                            (0, $.l)(), Q({
                                value: e.target.value,
                                validate: !1,
                                hasChangedSinceLastValidation: !0
                            })
                        },
                        options: H ? {
                            date: !0,
                            datePattern: N,
                            delimiter: B
                        } : {
                            delimiter: ""
                        },
                        value: X || "",
                        a11yIdentifier: i
                    }), !d && !G && l().createElement(C.Z, {
                        theme: n,
                        formVersionCId: e,
                        componentAriaID: K,
                        metadata: m,
                        validationErrorType: u,
                        validationErrorMessage: p,
                        a11yIdentifier: i
                    }))
                },
                A = n(26537);
            let D, N = e => e;
            const {
                THEME_KEY: B
            } = A.default;
            var R = ({
                    componentId: e,
                    formVersionCId: t,
                    theme: n,
                    a11yIdentifierBlock: o
                }) => {
                    const i = (0, f.Z)((t => {
                            var n;
                            return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.content
                        })),
                        r = (0, f.Z)((t => {
                            var n;
                            return null == (n = t.formsState.components[e]) ? void 0 : n.actionId
                        })),
                        s = (0, f.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                        d = (0, I.iv)(D || (D = N `
    &&& {
      ${0}
      &:focus-visible {
        outline-width: 2px;
        outline-style: auto;
        outline-color: ${0};
        outline-offset: 0;
      }
    }
  `), !1 !== n[B].specifyHoverBackgroundColor ? `\n            &:hover {\n              background-color: ${n[B].hoverBackgroundColor} !important;\n              ${n[B].hoverTextColor||n[B].textColor?`color: ${n[B].hoverTextColor||n[B].textColor} !important;`:""}\n            }` : "", n.inputStyles.border.activeColor || n.focusColor);
                    return l().createElement(h, {
                        formVersionCId: t,
                        actionId: r
                    }, (({
                        onClick: e,
                        handlingFormAction: t
                    }) => l().createElement(a.zx, {
                        a11yIdentifier: o,
                        className: t ? `klaviyo-spinner ${d}` : d,
                        style: Object.assign({
                            background: n[B].backgroundColor,
                            borderRadius: n[B].borderRadius,
                            borderStyle: n[B].borderStyle,
                            borderColor: n[B].borderColor,
                            borderWidth: n[B].borderWidth,
                            color: n[B].textStyles.color,
                            fontFamily: n[B].textStyles.fontFamily,
                            fontSize: n[B].textStyles.fontSize,
                            fontWeight: n[B].textStyles.fontWeight,
                            letterSpacing: n[B].textStyles.letterSpacing,
                            lineHeight: 1,
                            fontStyle: n[B].textStyles.fontStyle,
                            textDecoration: n[B].textStyles.textDecoration,
                            whiteSpace: "normal",
                            paddingTop: n[B].paddingTop,
                            paddingBottom: n[B].paddingBottom,
                            textAlign: "center",
                            wordBreak: "break-word",
                            alignSelf: "flex-end",
                            cursor: "pointer",
                            pointerEvents: t ? "none" : "auto",
                            height: n[B].height
                        }, n[B].fullWidth ? {
                            width: "100%"
                        } : {
                            paddingLeft: 10,
                            paddingRight: 10
                        }),
                        type: "button",
                        disabled: t,
                        onClick: e,
                        tabIndex: s ? -1 : 0
                    }, i)))
                },
                j = n(50947);
            const z = `\n  color: #000000;\n  line-height: normal;\n\n  p {\n    margin: 0px;\n  }\n  span {\n    display: inline;\n  }\n  ol,\n  ul {\n    padding: 0 0 0 48px;\n    margin: 0;\n  }\n  ul {\n    list-style-type: disc;\n  }\n  li {\n    line-height: 18px;\n  }\n  a {\n    color: ${n(13901).Z.blue};\n    text-decoration: underline;\n    border-bottom: none;\n  }\n`,
                W = (0, I.iv)(z),
                P = ["html"],
                L = e => {
                    let {
                        html: t
                    } = e, n = c()(e, P);
                    return l().createElement("div", r()({}, t ? {
                        dangerouslySetInnerHTML: {
                            __html: t
                        }
                    } : {}, {
                        style: {
                            width: "100%"
                        },
                        className: `${o.Tc} ${W}`
                    }, n))
                },
                {
                    A11yWrapper: H = (() => null),
                    useRecursivelySetA11yAttribute: q = (() => "")
                } = {},
                U = ({
                    a11yIdentifierBlock: e,
                    id: t,
                    html: n
                }) => {
                    const o = q({
                        a11yIdentifier: e || "",
                        html: n
                    });
                    return e ? l().createElement(H, {
                        identifier: e
                    }, l().createElement(L, {
                        id: t,
                        html: o
                    })) : l().createElement(L, {
                        id: t,
                        html: n
                    })
                };
            var K = ({
                itemId: e,
                parentType: t = j.A,
                a11yIdentifierBlock: n
            }) => {
                const o = (0, f.Z)((n => {
                        var o, i;
                        return t === j.p && n.formsState.teasers ? null == (o = n.formsState.teasers[e]) || null == (o = o.data) || null == (o = o.content) ? void 0 : o.html : null == (i = n.formsState.components[e]) || null == (i = i.data) || null == (i = i.content) ? void 0 : i.html
                    })),
                    i = (0, s.useMemo)((() => `rich-text-${e}`), [e]);
                return l().createElement(U, {
                    a11yIdentifierBlock: n,
                    id: i,
                    html: o
                })
            };
            n(70818), n(60873), n(83362);
            const G = ["selectorType", "fillColor", "formVersionCId", "id"],
                Y = ({
                    fillColor: e,
                    id: t
                }) => l().createElement("g", {
                    id: t,
                    stroke: "none",
                    strokeWidth: "1",
                    fill: "none",
                    fillRule: "evenodd"
                }, l().createElement("g", {
                    id: `checkbox-on-${t}`,
                    transform: "translate(3.000000, 4.000000)",
                    fill: "#303B43"
                }, l().createElement("polygon", {
                    id: `shape-${t}`,
                    fill: e,
                    points: "4.45454545 9.20149254 1.11363636 5.75373134 0 6.90298507 4.45454545 11.5 14 1.64925373 12.8863636 0.5"
                }))),
                X = ({
                    fillColor: e,
                    id: t
                }) => l().createElement("g", {
                    id: t,
                    stroke: "none",
                    strokeWidth: "1",
                    fill: "none",
                    fillRule: "evenodd"
                }, l().createElement("g", {
                    id: `shape-${t}`,
                    transform: "translate(4.000000, 4.000000)",
                    fill: "#303B43"
                }, l().createElement("circle", {
                    fill: e,
                    id: `oval-${t}`,
                    cx: "6",
                    cy: "6",
                    r: "5.55555556"
                })));
            var J = e => {
                let {
                    selectorType: t,
                    fillColor: n,
                    id: o
                } = e, i = c()(e, G);
                return l().createElement("svg", r()({
                    style: {
                        cursor: "pointer",
                        display: "none",
                        position: "absolute",
                        margin: 0
                    },
                    width: "20px",
                    height: "20px",
                    viewBox: "0 0 20 20",
                    version: "1.1",
                    xmlns: "http://www.w3.org/2000/svg",
                    "aria-hidden": "true"
                }, i), l().createElement("defs", null), "radio" === t ? l().createElement(X, {
                    id: `radio_inner_${o}`,
                    fillColor: n
                }) : l().createElement(Y, {
                    id: `checkbox_inner_${o}`,
                    fillColor: n
                }))
            };
            const Q = ["selectorType", "valid", "theme", "formVersionCId"],
                ee = ({
                    backgroundColor: e
                }) => l().createElement("g", null, l().createElement("g", null, l().createElement("rect", {
                    strokeWidth: "1",
                    x: "0.5",
                    y: "0.5",
                    width: "19",
                    height: "19",
                    rx: "2.22222222",
                    fill: e
                }))),
                te = ({
                    backgroundColor: e
                }) => l().createElement("g", null, l().createElement("g", null, l().createElement("circle", {
                    strokeWidth: "1",
                    cx: "10",
                    cy: "10",
                    r: "9.5",
                    fill: e
                })));
            var ne = e => {
                let {
                    selectorType: t,
                    valid: n,
                    theme: o
                } = e, i = c()(e, Q);
                return l().createElement("svg", r()({
                    style: {
                        stroke: n ? o.inputStyles.border.defaultColor : o.inputStyles.border.errorColor,
                        marginRight: 8,
                        minWidth: 20,
                        width: "auto",
                        height: "auto",
                        borderRadius: "radio" === t ? "50%" : void 0
                    },
                    width: "20px",
                    height: "20px",
                    viewBox: "0 0 20 20",
                    version: "1.1",
                    xmlns: "http://www.w3.org/2000/svg",
                    "aria-hidden": "true"
                }, i), "radio" === t ? l().createElement(te, {
                    backgroundColor: o.inputStyles.inputBackgroundColor
                }) : l().createElement(ee, {
                    backgroundColor: o.inputStyles.inputBackgroundColor
                }))
            };
            let oe, ie = e => e;
            var re = ({
                name: e,
                label: t,
                isValid: n,
                componentAriaID: i,
                componentType: r,
                onChange: d,
                tabIndex: c,
                theme: m,
                formVersionCId: u,
                a11yIdentifierStyles: f,
                a11yIdentifierBlock: p,
                alignCheckbox: h,
                ariaRequired: v
            }) => {
                const {
                    current: y
                } = (0, s.useRef)((0, g.Z)(`${e}__`)), b = r === o.hD ? "radio" : "checkbox";
                return l().createElement(l().Fragment, null, l().createElement(a.II, {
                    className: "klaviyo-sr-only",
                    tabIndex: c,
                    type: b,
                    id: y,
                    name: e,
                    onChange: d,
                    "aria-invalid": !n,
                    "aria-label": t,
                    "aria-describedby": n ? void 0 : i,
                    "aria-required": v,
                    a11yIdentifier: p
                }), l().createElement(a.__, {
                    className: (0, I.iv)(oe || (oe = ie `
          &&&& {
            &:hover {
              svg {
                stroke: ${0} !important;
              }
            }
          }
        `), m.inputStyles.border.activeColor),
                    style: {
                        display: "flex",
                        alignItems: null != h ? h : "center",
                        flex: m.inputStyles.arrangement === o.ZC ? " 1 0 100%" : " 0 0 auto",
                        paddingBottom: 8,
                        wordBreak: "break-word",
                        maxWidth: "100%",
                        cursor: "pointer"
                    },
                    htmlFor: y,
                    a11yIdentifier: f
                }, l().createElement(ne, {
                    valid: n,
                    selectorType: b,
                    "aria-hidden": "true",
                    theme: m,
                    formVersionCId: u
                }), l().createElement(J, {
                    selectorType: b,
                    "aria-hidden": "true",
                    formVersionCId: u,
                    fillColor: m.inputStyles.textStyles.formInputTextColor,
                    id: y
                }), l().createElement(a.ZC, {
                    style: {
                        cursor: "pointer",
                        color: m.inputStyles.textStyles.color,
                        fontFamily: m.inputStyles.textStyles.fontFamily,
                        fontSize: m.inputStyles.textStyles.fontSize,
                        fontWeight: m.inputStyles.textStyles.fontWeight,
                        letterSpacing: m.inputStyles.textStyles.letterSpacing,
                        marginRight: 24,
                        display: "flex",
                        position: "relative",
                        top: 1
                    },
                    a11yIdentifier: f
                }, t)))
            };
            let se, le = e => e;
            const ae = ["selected", "id", "label"],
                de = {
                    right: "flex-end",
                    left: "flex-start",
                    center: "center"
                },
                ce = ({
                    options: e,
                    componentType: t,
                    toggledOptionIndex: n
                }) => e.reduce(((e, i, r) => {
                    let {
                        selected: s,
                        id: l,
                        label: a
                    } = i, d = c()(i, ae), m = t !== o.hD && s;
                    return n === r && (m = !m), e.push(Object.assign({
                        selected: m,
                        label: a,
                        id: l || (0, g.Z)(`${a}__`)
                    }, d)), e
                }), []);
            var me = ({
                    formVersionCId: e,
                    componentId: t,
                    theme: n,
                    a11yIdentifierStyles: i,
                    a11yIdentifierBlock: r
                }) => {
                    const d = (0, f.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                        c = (0, f.Z)((n => {
                            var o;
                            const i = null == (o = n.onsiteState.openFormVersions[e]) ? void 0 : o.components[t];
                            return !!n.onsiteState.client.isDesignWorkflow || !i || i.valid || void 0 === i.valid
                        })),
                        m = (0, f.Z)((n => {
                            var o;
                            return null == (o = n.onsiteState.openFormVersions[e]) || null == (o = o.components[t]) ? void 0 : o.metadata
                        }), b.X),
                        u = (0, f.Z)((n => {
                            var o;
                            return null == (o = n.onsiteState.openFormVersions[e]) || null == (o = o.components[t]) ? void 0 : o.validationErrorType
                        })),
                        p = (0, f.Z)((n => (0, Z.HN)(n, e, t))),
                        h = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) ? void 0 : n.componentType
                        })),
                        v = (0, f.Z)((e => {
                            var n;
                            return (null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.options) || []
                        }), b.X),
                        y = (0, f.Z)((e => {
                            var n;
                            return (null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.fieldId) || ""
                        })),
                        S = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.required
                        })),
                        w = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.label
                        })),
                        k = (0, f.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.showLabel
                        })),
                        T = (0, f.Z)((e => {
                            var n;
                            const o = null == (n = e.formsState.components[t]) || null == (n = n.data) || null == (n = n.styling) ? void 0 : n.innerAlignment;
                            return o ? de[o] : "flex-start"
                        })),
                        [V, _] = (0, s.useState)([]);
                    (0, s.useEffect)((() => {
                        _(ce({
                            options: v,
                            componentType: h
                        }))
                    }), [v]);
                    const {
                        inputName: O,
                        labelId: F
                    } = (0, s.useMemo)((() => {
                        const e = (0, g.Z)(`${encodeURIComponent(y)}__`);
                        return {
                            inputName: e,
                            labelId: `kl_${e}_label`
                        }
                    }), []), M = 1 === V.length;
                    return l().createElement(a.ZC, {
                        style: {
                            width: "100%",
                            justifyContent: T,
                            display: "flex"
                        }
                    }, l().createElement(a.C3, {
                        className: (0, I.iv)(se || (se = le `
          &&& {
            input:focus-visible + label > svg {
              outline-width: 2px;
              outline-style: auto;
              outline-color: ${0};
              outline-offset: 0;
            }
          }
        `), n.inputStyles.border.activeColor || n.focusColor),
                        style: Object.assign({
                            alignSelf: "flex-end"
                        }, n.inputStyles.arrangement === o.ZC ? {
                            display: "block"
                        } : {
                            flexDirection: "column",
                            flexWrap: "wrap"
                        }),
                        a11yIdentifier: i,
                        "aria-required": !M && S || void 0
                    }, l().createElement(x.Z, {
                        a11yIdentifier: i,
                        id: F,
                        theme: n,
                        style: {
                            marginRight: 8,
                            marginBottom: 8
                        },
                        showLabel: !(void 0 !== k || !w) || k,
                        asLegend: !0
                    }, w), l().createElement(a.ZC, {
                        style: Object.assign({}, n.inputStyles.arrangement === o.ZC ? {
                            display: "block"
                        } : {
                            display: "inline-flex",
                            justifyContent: "flex-start",
                            flexWrap: "wrap"
                        }),
                        role: h === o.hD ? "radiogroup" : "group",
                        a11yIdentifier: i
                    }, V.map((({
                        label: s,
                        id: a
                    }, m) => l().createElement(re, {
                        key: a,
                        formVersionCId: e,
                        theme: n,
                        name: O,
                        label: s,
                        isValid: c,
                        componentType: h,
                        componentAriaID: F,
                        onChange: () => (n => {
                            (0, $.l)();
                            const i = ce({
                                options: V,
                                componentType: h,
                                toggledOptionIndex: n
                            });
                            _(i);
                            const r = (e => e.filter((({
                                selected: e
                            }) => e)).map((e => e.value || e.label)))(i);
                            (0, E.hX)({
                                formVersionCId: e,
                                componentId: t,
                                value: h === o.hD ? r.toString() : r
                            })
                        })(m),
                        tabIndex: d ? -1 : 0,
                        a11yIdentifierStyles: i,
                        a11yIdentifierBlock: r,
                        ariaRequired: M && S || void 0
                    })))), !d && l().createElement(C.Z, {
                        theme: n,
                        formVersionCId: e,
                        componentAriaID: F,
                        validationErrorType: u,
                        validationErrorMessage: p,
                        metadata: m,
                        a11yIdentifier: i
                    })))
                },
                ue = n(49889),
                fe = n.n(ue),
                pe = n(28917),
                he = n(82883);
            let ve, ye = e => e;
            const ge = "rgb(96, 106, 114)",
                Ie = "white",
                be = "copy",
                Se = "applied",
                we = {
                    [be]: {
                        message: "Copied!",
                        couponTooltipRectangleWidth: 80
                    },
                    [Se]: {
                        message: "Coupon applied to checkout!",
                        couponTooltipRectangleWidth: 196
                    }
                };
            var xe, Ce, Ee = ({
                show: e,
                theme: t,
                type: n,
                a11yIdentifier: o,
                successMessage: i
            }) => {
                const r = i || we[n].message,
                    s = we[n].couponTooltipRectangleWidth;
                return l().createElement(a.ZC, {
                    style: {
                        width: "100%",
                        position: "relative"
                    },
                    a11yIdentifier: o
                }, e && l().createElement(a.ZC, {
                    a11yIdentifier: o,
                    style: {
                        backgroundColor: "transparent",
                        position: "absolute",
                        zIndex: 1,
                        height: "37px",
                        minWidth: `${s}px`,
                        left: "50%",
                        transform: "translate(-50%, 0)",
                        bottom: "-21px",
                        borderRadius: 4,
                        animationName: "klaviyo-fadein, klaviyo-fadeout",
                        animationDuration: "0.4s, 0.4s",
                        animationDelay: "0s, 1.6s"
                    }
                }, l().createElement(a.ZC, {
                    a11yIdentifier: o,
                    className: (0, I.iv)(ve || (ve = ye `
              &&& {
                &::after {
                  content: '';
                  display: block;
                  position: absolute;
                  width: 0;
                  height: 0;
                  bottom: ${0}px;
                  left: calc(50% - ${0}px);
                  border-style: solid;
                  border-width: ${0}px;
                  border-top-color: ${0};
                  border-right-color: transparent;
                  border-bottom-color: transparent;
                  border-left-color: transparent;
                }
                &::before {
                  content: '';
                  display: block;
                  position: absolute;
                  width: 0;
                  height: 0;
                  bottom: ${0}px;
                  left: calc(50% - ${0}px);
                  border-style: solid;
                  border-width: ${0}px;
                  border-top-color: ${0};
                  border-right-color: transparent;
                  border-bottom-color: transparent;
                  border-left-color: transparent;
                }
              }
            `), -6, 6, 6, ge, -8, 7, 7, Ie),
                    style: {
                        borderRadius: 4,
                        boxShadow: "1px 1px 4px 0 rgba(0, 0, 0, 0.26)",
                        border: "1px solid white",
                        backgroundColor: ge
                    }
                }, l().createElement(a.Dr, {
                    a11yIdentifier: o,
                    style: {
                        fontSize: 14,
                        fontFamily: t.inputStyles.textStyles.fontFamily,
                        textAlign: "center",
                        color: Ie,
                        padding: 8,
                        height: "30px",
                        boxSizing: "border-box",
                        whiteSpace: "nowrap"
                    },
                    role: "alert"
                }, r))))
            };

            function ke() {
                return ke = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var o in n)({}).hasOwnProperty.call(n, o) && (e[o] = n[o])
                    }
                    return e
                }, ke.apply(null, arguments)
            }
            var $e, Te, Ve = function(e) {
                return s.createElement("svg", ke({
                    width: 32,
                    height: 33,
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), xe || (xe = s.createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M3.602 1.1a3 3 0 0 0-3 3v18.4a3 3 0 0 0 3 3H8v-2H3.602a1 1 0 0 1-1-1V4.1a1 1 0 0 1 1-1h15.2a1 1 0 0 1 1 1v1.2h2V4.1a3 3 0 0 0-3-3h-15.2Z",
                    fill: "currentColor"
                })), Ce || (Ce = s.createElement("rect", {
                    x: 11.199,
                    y: 8.5,
                    width: 19.2,
                    height: 22.4,
                    rx: 2,
                    stroke: "currentColor",
                    strokeWidth: 2
                })))
            };

            function Ze() {
                return Ze = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var o in n)({}).hasOwnProperty.call(n, o) && (e[o] = n[o])
                    }
                    return e
                }, Ze.apply(null, arguments)
            }
            var _e = function(e) {
                return s.createElement("svg", Ze({
                    width: 32,
                    height: 33,
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), $e || ($e = s.createElement("g", {
                    clipPath: "url(#check_svg__a)"
                }, s.createElement("path", {
                    d: "m11.16 18.992-4.493-4.494a1.73 1.73 0 0 0-2.45 2.443l5.512 6.144c.79.844 2.133.834 2.912-.021l13.321-14.13a1.678 1.678 0 0 0-2.446-2.299L11.16 18.992Z",
                    fill: "#2CB46F",
                    stroke: "#fff"
                }))), Te || (Te = s.createElement("defs", null, s.createElement("clipPath", {
                    id: "check_svg__a"
                }, s.createElement("path", {
                    fill: "#fff",
                    transform: "translate(0 .5)",
                    d: "M0 0h32v32H0z"
                })))))
            };
            var Oe = ({
                copied: e,
                color: t,
                a11yIdentifier: n
            }) => e ? l().createElement(a.ny, {
                style: {
                    height: 32,
                    width: 32,
                    paddingLeft: "16px",
                    cursor: "pointer",
                    flexShrink: 0
                },
                a11yIdentifier: n
            }, l().createElement(_e, null)) : l().createElement(a.ny, {
                style: {
                    color: t,
                    height: 32,
                    width: 32,
                    paddingLeft: "16px",
                    cursor: "pointer",
                    flexShrink: 0
                },
                a11yIdentifier: n
            }, l().createElement(Ve, null));
            let Fe, Me = e => e;
            const {
                THEME_KEY: Ae
            } = pe.default;
            var De = ({
                    theme: e,
                    a11yIdentifier: t
                }) => {
                    const n = (0, I.iv)(Fe || (Fe = Me `
    &&& .klaviyo-spinner {
      &.overlay {
        &:before {
          background-color: ${0};
        }
      }
      &:after {
        top: auto;
        bottom: 0;
        width: 30px;
        height: 30px;
        margin-top: -15px;
        margin-left: -15px;
        border-top-color: ${0};
        border-left-color: ${0};
      }
    }
  `), e[Ae].backgroundColor, e[Ae].textStyles.color, e[Ae].textStyles.color);
                    return l().createElement(a.ZC, {
                        a11yIdentifier: t,
                        className: n,
                        style: {
                            height: 32,
                            width: "100%",
                            paddingTop: "16px",
                            position: "relative"
                        }
                    }, l().createElement(a.ZC, {
                        a11yIdentifier: t,
                        className: "klaviyo-spinner"
                    }))
                },
                Ne = n(16254),
                Be = n(53896),
                Re = n(61594);
            let je, ze = e => e;
            const {
                THEME_KEY: We
            } = pe.default, Pe = () => null;
            var Le = ({
                formVersionCId: e,
                componentId: t,
                theme: n,
                a11yIdentifierBlock: o,
                a11yIdentifierStyles: i
            }) => {
                const r = (0, f.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                    d = (0, f.Z)((e => {
                        var n;
                        return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.couponType
                    })),
                    c = (0, f.Z)((e => {
                        var n;
                        return null == (n = e.formsState.components[t]) || null == (n = n.data) || null == (n = n.couponData) ? void 0 : n.text
                    })),
                    m = (0, f.Z)((e => {
                        var n;
                        return null == (n = e.formsState.components[t]) || null == (n = n.data) || null == (n = n.couponData) ? void 0 : n.successMessage
                    })),
                    u = (0, f.Z)((e => {
                        var n;
                        return null == (n = e.formsState.components[t]) || null == (n = n.data) || null == (n = n.couponData) ? void 0 : n.name
                    })),
                    p = (0, f.Z)((e => {
                        var n;
                        return null == (n = e.formsState.components[t]) || null == (n = n.data) || null == (n = n.couponData) ? void 0 : n.fallback
                    })),
                    h = (0, f.Z)((e => e.onsiteState.couponCodes[t])),
                    v = (0, f.Z)((e => e.onsiteState.datadomeCaptchaUrls[t])),
                    y = (0, f.Z)((e => e.onsiteState.client.showingShopLogin)),
                    [g, b] = (0, s.useState)(!1),
                    [S, w] = (0, s.useState)(!1),
                    [x, C] = (0, s.useState)(!1),
                    [k, $] = (0, s.useState)(be),
                    T = (0, s.useMemo)((() => d === Ne.$i.STATIC ? c || Ne.I4 : d === Ne.$i.UNIQUE && r ? u ? (0, Ne.xB)(u) : void 0 : h || p), [d, h, p, u, r, c]),
                    V = v && !x;
                return (0, s.useEffect)((() => {
                    r || d !== Ne.$i.UNIQUE || h || (w(!0), (0, E.zS)({
                        formVersionCId: e
                    }))
                }), [x, d, h, e, r]), (0, s.useEffect)((() => {
                    const t = () => {
                            C(!0)
                        },
                        n = () => {
                            (0, E.Cm)({
                                id: e,
                                changes: {
                                    errorViewMessage: Be.w5
                                }
                            })
                        };
                    return window.addEventListener(Re.H, t, !1), window.addEventListener(Re.vT, n, !1), () => {
                        window.removeEventListener(Re.H, t, !1), window.removeEventListener(Re.vT, n, !1)
                    }
                }), []), (0, s.useEffect)((() => {
                    (V || T) && S && w(!1)
                }), [V, T, S]), (0, s.useEffect)((() => {
                    window.Shopify && !S && T && k !== Se && ($(Se), fetch(`/discount/${T}`))
                }), [k, T, S]), l().createElement(a.ZC, {
                    a11yIdentifier: o,
                    style: {
                        alignItems: "center",
                        justifyContent: "center",
                        width: "100%",
                        height: "auto"
                    }
                }, r && !T ? l().createElement(Pe, null) : l().createElement(l().Fragment, null, !!T && !S && l().createElement(Ee, {
                    a11yIdentifier: o,
                    show: g,
                    theme: n,
                    type: k,
                    successMessage: m
                }), V ? l().createElement("iframe", {
                    title: "Recaptcha",
                    src: v,
                    frameBorder: "0",
                    width: "100%",
                    height: "600px"
                }) : l().createElement(a.zx, {
                    role: "button",
                    "aria-label": "Copy coupon code",
                    a11yIdentifier: o,
                    onClick: e => {
                        e.preventDefault(), T && fe()(T), b(!0);
                        const t = setTimeout((() => {
                            b(!1)
                        }), 2e3);
                        return () => clearTimeout(t)
                    },
                    className: (0, I.iv)(je || (je = ze `
                &&& {
                  &:focus-visible {
                    outline-width: 2px;
                    outline-style: auto;
                    outline-color: ${0};
                    outline-offset: 0;
                  }
                }
              `), n.inputStyles.border.activeColor || n.focusColor),
                    style: {
                        position: "relative",
                        display: "flex",
                        flexDirection: "row",
                        flex: "1 1",
                        alignItems: "center",
                        justifyContent: "center",
                        background: n[We].backgroundColor,
                        borderRadius: n[We].borderRadius,
                        borderStyle: n[We].borderStyle,
                        borderColor: n[We].borderColor,
                        borderWidth: n[We].borderWidth,
                        color: n[We].textStyles.color,
                        lineHeight: 1,
                        whiteSpace: "normal",
                        paddingTop: n[We].paddingTop,
                        paddingBottom: n[We].paddingBottom,
                        paddingLeft: n[We].paddingLeft,
                        paddingRight: n[We].paddingRight,
                        textAlign: "center",
                        wordBreak: "break-word",
                        alignSelf: "flex-end",
                        cursor: S ? "auto" : "pointer",
                        boxSizing: "border-box",
                        width: "100%"
                    }
                }, S || y === he.K.SHOWING ? l().createElement(a.ZC, {
                    a11yIdentifier: o
                }, l().createElement(a.ZC, {
                    a11yIdentifier: i,
                    style: {
                        flex: "1 1",
                        fontFamily: n.inputStyles.textStyles.fontFamily,
                        fontSize: 18,
                        fontWeight: n.inputStyles.textStyles.fontWeight,
                        letterSpacing: n.inputStyles.textStyles.letterSpacing
                    }
                }, "Loading Coupon"), l().createElement(De, {
                    a11yIdentifier: o,
                    theme: n
                })) : l().createElement(l().Fragment, null, l().createElement(a.ZC, {
                    a11yIdentifier: o,
                    style: {
                        flex: "1 1",
                        fontFamily: n[We].textStyles.fontFamily,
                        fontSize: n[We].textStyles.fontSize,
                        fontWeight: n[We].textStyles.fontWeight,
                        letterSpacing: n[We].textStyles.letterSpacing
                    }
                }, T), l().createElement(Oe, {
                    copied: g,
                    color: n[We].textStyles.color,
                    a11yIdentifier: o
                })))))
            };
            let He, qe = e => e;
            const Ue = ["html", "textStyles"];
            var Ke = e => {
                let {
                    html: t,
                    textStyles: n
                } = e, i = c()(e, Ue);
                return n ? l().createElement("div", r()({}, t ? {
                    dangerouslySetInnerHTML: {
                        __html: t
                    }
                } : {}, {
                    style: {
                        width: "100%"
                    },
                    className: (0, I.iv)(He || (He = qe `
        &&& {
          :not(a) {
            color: ${0};
            font-family: ${0};
            font-size: ${0}px;
          }
          a {
            color: ${0};
            font-family: ${0};
            font-size: ${0}px;
          }
        }
        ${0}
        ${0}
      `), n.text.color, n.text.fontFamily, n.text.fontSize, n.link.color, n.link.fontFamily, n.link.fontSize, o.Tc, W)
                }, i)) : null
            };
            const {
                A11yWrapper: Ge = (() => null),
                useRecursivelySetA11yAttribute: Ye = (() => "")
            } = {};
            var Xe = ({
                    componentId: e,
                    formVersionCId: t,
                    a11yIdentifierBlock: n
                }) => {
                    const o = (0, f.Z)((t => {
                            var n;
                            return null == (n = t.formsState.components[e]) || null == (n = n.data) || null == (n = n.content) ? void 0 : n.html
                        })),
                        i = (0, f.Z)((n => {
                            var o;
                            const i = null == (o = n.onsiteState.openFormVersions[t]) ? void 0 : o.currentViewId;
                            if (!i) return;
                            const {
                                formSMSDisclosure: r
                            } = (0, _.su)(n, e, i);
                            return null == r ? void 0 : r.textStyles
                        }), b.X),
                        r = Ye({
                            html: o,
                            a11yIdentifier: n || ""
                        });
                    return n ? l().createElement(Ge, {
                        identifier: n
                    }, l().createElement(Ke, {
                        html: r,
                        textStyles: i
                    })) : l().createElement(Ke, {
                        html: o,
                        textStyles: i
                    })
                },
                Je = n(74010);
            n(78991), n(24570);
            const Qe = e => {
                    const t = new Intl.DateTimeFormat("en-GB", {
                            hour: "2-digit",
                            minute: "2-digit",
                            second: "2-digit",
                            hour12: !1
                        }).formatToParts(e),
                        n = `${t[0].value}:${t[2].value}:${t[4].value}`;
                    if (!(e => /[0-9]{2}:[0-9]{2}:[0-9]{2}/.test(e))(n)) throw new Error("The provided Date was not able to be converted to a valid ISO Time string.");
                    return n
                },
                et = e => Qe(e);
            var tt = n(20301);
            const nt = ["text", "theme", "a11yIdentifierBlock"],
                {
                    THEME_KEY: ot
                } = tt.default;
            var it = e => {
                let {
                    text: t,
                    theme: n,
                    a11yIdentifierBlock: o
                } = e, i = c()(e, nt);
                return l().createElement(a.ZC, r()({
                    a11yIdentifier: o
                }, i), l().createElement(a.Dr, {
                    className: "klaviyo-sr-only"
                }, t.startsWith("0") ? t.substring(1) : t), l().createElement(a.Dr, {
                    "aria-hidden": "true",
                    style: {
                        color: n[ot].textStyles.color,
                        fontFamily: n[ot].textStyles.fontFamily,
                        fontSize: n[ot].textStyles.fontSize,
                        fontWeight: n[ot].textStyles.fontWeight
                    }
                }, t))
            };
            let rt, st, lt, at, dt, ct = e => e;
            const {
                THEME_KEY: mt
            } = tt.default, ut = "0.72em", ft = "0.15em";
            var pt = ({
                text: e,
                prevText: t = "00",
                animate: n = !1,
                theme: o,
                a11yIdentifierBlock: i
            }) => {
                const r = (0, s.useMemo)((() => ({
                    card: (0, I.iv)(rt || (rt = ct `
        &&& {
          & {
            text-align: center;
            display: inline-block;
            margin: 0 5px;
            display: block;
            position: relative;
            font-size: ${0};
          }

          *,
          *:before,
          *:after {
            box-sizing: border-box;
          }
        }
      `), o[mt].textStyles.fontSize),
                    card_top: (0, I.iv)(st || (st = ct `
        &&& {
          & {
            display: block;
            height: ${0};
            border-radius: ${0} ${0} 0 0;
            backface-visibility: hidden;
            aspect-ratio: 2/1;
            overflow: hidden;

            background: ${0};
            color: ${0};
            font-family: ${0};
            font-size: ${0};
            font-weight: ${0};
          }

          &::after {
            display: block;
            content: '${0}';
            height: 100%;
            width: 100%;
            text-align: center;
            line-height: 150%;

            color: ${0};
            font-family: ${0};
            font-size: ${0};
            font-weight: ${0};
          }
        }
      `), ut, ft, ft, o[mt].cardColor, o[mt].textStyles.color, o[mt].textStyles.fontFamily, o[mt].textStyles.fontSize, o[mt].textStyles.fontWeight, e, o[mt].textStyles.color, o[mt].textStyles.fontFamily, o[mt].textStyles.fontSize, o[mt].textStyles.fontWeight),
                    card_bottom: (0, I.iv)(lt || (lt = ct `
        &&& {
          & {
            border-top: solid 1px #fff;
            border-radius: 0 0 ${0} ${0};

            display: block;
            height: ${0};
            backface-visibility: hidden;
            aspect-ratio: 2/1;
            overflow: hidden;

            background: ${0};
            color: ${0};
            font-family: ${0};
            font-size: ${0};
            font-weight: ${0};
          }

          &::after {
            display: block;
            margin-top: -${0};
            content: '${0}';
            height: 100%;
            width: 100%;
            text-align: center;
            line-height: 150%;

            color: ${0};
            font-family: ${0};
            font-size: ${0};
            font-weight: ${0};
          }
        }
      `), ft, ft, ut, o[mt].cardColor, o[mt].textStyles.color, o[mt].textStyles.fontFamily, o[mt].textStyles.fontSize, o[mt].textStyles.fontWeight, ut, n ? t : e, o[mt].textStyles.color, o[mt].textStyles.fontFamily, o[mt].textStyles.fontSize, o[mt].textStyles.fontWeight),
                    card_animate: (0, I.iv)(at || (at = ct `
        &&& {
          & {
            position: absolute;
            top: 0;
            height: 100%;
            left: 0%;
            pointer-events: none;

            z-index: 2;
          }

          &::before {
            content: '${0}';
            z-index: -1;
            height: 100%;
            width: 100%;
            text-align: center;
            line-height: 150%;

            animation: klaviyo-flipTop 0.3s cubic-bezier(0.37, 0.01, 0.94, 0.35)
              1;
            animation-fill-mode: both;
            transform-origin: center bottom;

            display: block;
            height: ${0};
            border-radius: ${0} ${0} 0 0;
            backface-visibility: hidden;
            aspect-ratio: 2/1;
            overflow: hidden;

            background: ${0};
            color: ${0};
            font-family: ${0};
            font-size: ${0};
            font-weight: ${0};
          }
        }
      `), t, ut, ft, ft, o[mt].cardColor, o[mt].textStyles.color, o[mt].textStyles.fontFamily, o[mt].textStyles.fontSize, o[mt].textStyles.fontWeight),
                    card_animate_bottom: (0, I.iv)(dt || (dt = ct `
        &&& {
          & {
            border-top: solid 1px #fff;
            border-radius: 0 0 ${0} ${0};

            display: block;
            height: ${0};
            backface-visibility: hidden;
            aspect-ratio: 2/1;
            overflow: hidden;

            background: ${0};
            color: ${0};
            font-family: ${0};
            font-size: ${0};
            font-weight: ${0};
          }

          &::after {
            display: block;
            margin-top: -${0};
            content: '${0}';
            height: 100%;
            width: 100%;
            text-align: center;
            line-height: 150%;

            color: ${0};
            font-family: ${0};
            font-size: ${0};
            font-weight: ${0};
          }
        }
      `), ft, ft, ut, o[mt].cardColor, o[mt].textStyles.color, o[mt].textStyles.fontFamily, o[mt].textStyles.fontSize, o[mt].textStyles.fontWeight, ut, e, o[mt].textStyles.color, o[mt].textStyles.fontFamily, o[mt].textStyles.fontSize, o[mt].textStyles.fontWeight)
                })), [o, e, t, n]);
                return l().createElement(a.ZC, {
                    a11yIdentifier: i,
                    className: r.card
                }, l().createElement(a.ZC, {
                    a11yIdentifier: i,
                    className: r.card_top
                }), l().createElement(a.ZC, {
                    a11yIdentifier: i,
                    className: r.card_bottom
                }), n && l().createElement(a.ZC, {
                    a11yIdentifier: i,
                    className: r.card_animate,
                    key: e
                }, l().createElement(a.ZC, {
                    a11yIdentifier: i,
                    className: r.card_animate_bottom,
                    style: {
                        transformOrigin: "center top",
                        animationFillMode: "both",
                        animation: "klaviyo-flipBottom 0.6s cubic-bezier(.15,.45,.28,1) 1"
                    }
                })))
            };
            const {
                THEME_KEY: ht
            } = tt.default;
            var vt = ({
                text: e,
                clockFace: t = "simple",
                theme: n,
                a11yIdentifierBlock: o
            }) => {
                const i = (0, s.useMemo)((() => "flip" === t ? n[ht].cardColor : n[ht].textStyles.color), [t, n]);
                return l().createElement(a.ZC, {
                    a11yIdentifier: o,
                    style: {
                        color: i,
                        fontFamily: n[ht].textStyles.fontFamily,
                        fontSize: n[ht].textStyles.labelFontSize,
                        fontWeight: n[ht].textStyles.labelFontWeight,
                        justifyContent: "center",
                        justifySelf: "center"
                    }
                }, e)
            };
            const yt = {
                    name: "none",
                    duration: 0
                },
                gt = {
                    name: "flash",
                    duration: 1
                },
                It = {
                    name: "heartbeat",
                    duration: 1.3
                },
                bt = {
                    name: "pulse",
                    duration: 1
                },
                St = "fixed",
                wt = "variable",
                xt = "full",
                Ct = "shortened",
                Et = "single_char",
                kt = "double_char";
            var $t = ({
                componentId: e,
                formVersionCId: t,
                theme: n,
                a11yIdentifierBlock: o
            }) => {
                const i = (0, f.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                    r = (0, f.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.dateType
                    })),
                    d = (0, f.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) || null == (n = n.date) ? void 0 : n.variable
                    })),
                    c = (0, f.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) || null == (n = n.date) ? void 0 : n.fixed
                    })),
                    m = (0, f.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.clockFace
                    })),
                    u = (0, f.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.timerAnimation
                    })),
                    p = (0, f.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.labelFormat
                    })),
                    h = (0, f.Z)((e => {
                        var n;
                        return null == (n = e.onsiteState.openFormVersions[t]) ? void 0 : n.opened
                    })),
                    {
                        dateInUserTimezoneISOString: v
                    } = (0, s.useMemo)((() => function(e, t) {
                        if (!e) return {
                            dateInUserTimezoneISOString: null,
                            timeInUserTimezone: null,
                            timezone: null != t ? t : "US/Eastern"
                        };
                        const n = (0, Je.utcToZonedTime)(new Date(e), null != t ? t : "US/Eastern");
                        return {
                            dateInUserTimezoneISOString: n.toISOString(),
                            timeInUserTimezone: et(n),
                            timezone: null != t ? t : "US/Eastern"
                        }
                    }(null == c ? void 0 : c.utcIsoString, Intl.DateTimeFormat().resolvedOptions().timeZone)), [c]),
                    y = (0, s.useMemo)((() => {
                        if (r === wt) return {
                            days: d.days > 0 ? `${d.days.toString().padStart(2,"0")}` : void 0,
                            hours: d.days > 0 || d.hours > 0 ? `${d.hours.toString().padStart(2,"0")}` : void 0,
                            minutes: `${d.minutes.toString().padStart(2,"0")}`,
                            seconds: "00"
                        };
                        if (r === St) {
                            if (!v) return {
                                minutes: "00",
                                seconds: "00"
                            };
                            const e = new Date(v),
                                t = new Date,
                                n = e.getTime() - t.getTime();
                            if (n <= 0) return {
                                minutes: "00",
                                seconds: "00"
                            };
                            const o = Math.floor(n / 864e5),
                                r = Math.floor(n % 864e5 / 36e5),
                                s = Math.floor(n % 36e5 / 6e4),
                                l = Math.floor(n % 6e4 / 1e3);
                            return i ? {
                                days: o > 0 ? "00" : void 0,
                                hours: o > 0 || r > 0 ? "00" : void 0,
                                minutes: "00",
                                seconds: "00"
                            } : {
                                days: o > 0 ? `${o.toString().padStart(2,"0")}` : void 0,
                                hours: o > 0 || r > 0 ? `${r.toString().padStart(2,"0")}` : void 0,
                                minutes: `${s.toString().padStart(2,"0")}`,
                                seconds: `${l.toString().padStart(2,"0")}`
                            }
                        }
                        return {
                            minutes: "00",
                            seconds: "00"
                        }
                    }), [r, d, v, i]),
                    [g, I] = (0, s.useState)(y),
                    [b, S] = (0, s.useState)(g),
                    [w, x] = (0, s.useState)(!1),
                    [C, E] = (0, s.useState)(0);
                (0, s.useEffect)((() => {
                    if (i) return S(g), I(y), () => {};
                    if (r === wt && h && !w) {
                        const e = new Date;
                        e.setDate(e.getDate() + d.days), e.setHours(e.getHours() + d.hours), e.setMinutes(e.getMinutes() + d.minutes), E(e.getTime()), x(!0)
                    }
                    if (r === St && !w && v) {
                        const e = new Date(v);
                        E(e.getTime()), x(!0)
                    }
                    const e = setInterval((() => {
                        if (w && (Number(g.seconds) > 0 || Number(g.minutes) > 0 || Number(g.hours) > 0 || Number(g.days) > 0)) {
                            const e = new Date,
                                t = C - e.getTime();
                            if (t < 0) return S(g), void I({
                                minutes: "00",
                                seconds: "00"
                            });
                            S(g), I((e => {
                                const t = Math.floor(e / 864e5),
                                    n = Math.floor(e % 864e5 / 36e5),
                                    o = Math.floor(e % 36e5 / 6e4),
                                    i = Math.floor(e % 6e4 / 1e3);
                                return {
                                    days: t > 0 ? `${t.toString().padStart(2,"0")}` : void 0,
                                    hours: t > 0 || n > 0 ? `${n.toString().padStart(2,"0")}` : void 0,
                                    minutes: `${o.toString().padStart(2,"0")}`,
                                    seconds: `${i.toString().padStart(2,"0")}`
                                }
                            })(t))
                        }
                    }), 1e3);
                    return () => {
                        clearInterval(e)
                    }
                }), [i, r, h, w, y, d, v, C, g]);
                const k = (0, s.useRef)(u),
                    [$, T] = (0, s.useState)(!1);
                (0, s.useEffect)((() => {
                    T(k.current !== u), k.current = u
                }), [u]);
                const V = (0, s.useMemo)((() => {
                        if (i && !$) return "";
                        if (!i && (Number(g.seconds) > 0 || Number(g.minutes) > 0 || Number(g.hours) > 0 || Number(g.days) > 0) || u === yt.name) return "";
                        let e = "";
                        return u === gt.name ? e = `klaviyo-${gt.name} ${gt.duration}s` : u === It.name ? e = `klaviyo-${It.name} ${It.duration}s` : u === bt.name && (e = `klaviyo-${bt.name} ${bt.duration}s`), i ? `${e} 1` : `${e} 1s infinite`
                    }), [u, i, g, $]),
                    Z = (0, s.useMemo)((() => {
                        switch (p) {
                            case xt:
                                return {
                                    days: "days",
                                    hours: "hours",
                                    minutes: "minutes",
                                    seconds: "seconds"
                                };
                            case Ct:
                                return {
                                    days: "days",
                                    hours: "hrs",
                                    minutes: "mins",
                                    seconds: "secs"
                                };
                            case kt:
                                return {
                                    days: "DD",
                                    hours: "HH",
                                    minutes: "MM",
                                    seconds: "SS"
                                };
                            case Et:
                                return {
                                    days: "D",
                                    hours: "H",
                                    minutes: "M",
                                    seconds: "S"
                                };
                            default:
                                return {
                                    days: "days",
                                    hours: "hours",
                                    minutes: "minutes",
                                    seconds: "seconds"
                                }
                        }
                    }), [p]);
                return "simple" === m ? l().createElement(a.ZC, {
                    className: "klaviyo-countdown",
                    a11yIdentifier: o,
                    "data-testid": "klaviyo-countdown",
                    role: "timer",
                    "aria-live": "polite",
                    "aria-atomic": "true",
                    style: {
                        width: "100%",
                        justifyContent: "center",
                        justifySelf: "center",
                        display: "flex",
                        animation: `${V}`,
                        fontVariantNumeric: "tabular-nums"
                    }
                }, l().createElement(a.Dr, {
                    className: "klaviyo-sr-only"
                }, "Countdown ends in:"), (null == g ? void 0 : g.days) && l().createElement(l().Fragment, null, l().createElement(a.ZC, {
                    a11yIdentifier: o,
                    style: {
                        justifyContent: "center",
                        justifySelf: "center",
                        display: "grid"
                    }
                }, l().createElement(it, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: null == g ? void 0 : g.days
                }), l().createElement(vt, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    clockFace: m,
                    text: Z.days
                })), l().createElement(it, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: " "
                })), (null == g ? void 0 : g.hours) && l().createElement(l().Fragment, null, l().createElement(a.ZC, {
                    a11yIdentifier: o,
                    style: {
                        justifyContent: "center",
                        justifySelf: "center",
                        display: "grid"
                    }
                }, l().createElement(it, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: null == g ? void 0 : g.hours
                }), l().createElement(vt, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    clockFace: m,
                    text: Z.hours
                })), l().createElement(it, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: ":"
                })), l().createElement(a.ZC, {
                    a11yIdentifier: o,
                    style: {
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center"
                    }
                }, l().createElement(it, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: null == g ? void 0 : g.minutes
                }), l().createElement(vt, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    clockFace: m,
                    text: Z.minutes
                })), l().createElement(it, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: ":"
                }), l().createElement(a.ZC, {
                    a11yIdentifier: o,
                    style: {
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center"
                    },
                    "aria-hidden": "true"
                }, l().createElement(it, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: null == g ? void 0 : g.seconds
                }), l().createElement(vt, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    clockFace: m,
                    text: Z.seconds
                }))) : "flip" === m ? l().createElement(a.ZC, {
                    className: "klaviyo-countdown",
                    a11yIdentifier: o,
                    "data-testid": "klaviyo-countdown",
                    role: "timer",
                    "aria-live": "polite",
                    "aria-atomic": "true",
                    style: {
                        width: "100%",
                        justifyContent: "center",
                        justifySelf: "center",
                        display: "flex",
                        animation: `${V}`,
                        fontVariantNumeric: "tabular-nums"
                    }
                }, l().createElement(a.Dr, {
                    className: "klaviyo-sr-only"
                }, "Countdown ends in:"), (null == g ? void 0 : g.days) && l().createElement(a.ZC, {
                    a11yIdentifier: o,
                    style: {
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center"
                    }
                }, l().createElement(pt, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: null == g ? void 0 : g.days,
                    prevText: null == b ? void 0 : b.days,
                    animate: !i
                }), l().createElement(vt, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    clockFace: m,
                    text: Z.days
                })), (null == g ? void 0 : g.hours) && l().createElement(a.ZC, {
                    a11yIdentifier: o,
                    style: {
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center"
                    }
                }, l().createElement(pt, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: null == g ? void 0 : g.hours,
                    prevText: null == b ? void 0 : b.hours,
                    animate: !i
                }), l().createElement(vt, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    clockFace: m,
                    text: Z.hours
                })), l().createElement(a.ZC, {
                    a11yIdentifier: o,
                    style: {
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center"
                    }
                }, l().createElement(pt, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: null == g ? void 0 : g.minutes,
                    prevText: null == b ? void 0 : b.minutes,
                    animate: !i
                }), l().createElement(vt, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    clockFace: m,
                    text: Z.minutes
                })), l().createElement(a.ZC, {
                    a11yIdentifier: o,
                    style: {
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center"
                    },
                    "aria-hidden": "true"
                }, l().createElement(pt, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: null == g ? void 0 : g.seconds,
                    prevText: null == b ? void 0 : b.seconds,
                    animate: !i
                }), l().createElement(vt, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    clockFace: m,
                    text: Z.seconds
                }))) : l().createElement(a.ZC, null)
            };
            var Tt = ({
                itemId: e,
                a11yIdentifierBlock: t
            }) => {
                const n = (0, f.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                    o = (0, f.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) || null == (n = n.content) ? void 0 : n.html
                    })),
                    i = (0, s.useMemo)((() => `engagement-counter-${e}`), [e]),
                    r = /{{ *(&nbsp; *)*form_submit_count *(&nbsp; *)*}}/,
                    a = (0, f.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.dynamicInfoState) || null == (n = n.results) ? void 0 : n[e].submits
                    }));
                let d = null;
                const c = (0, f.Z)((t => {
                    var n;
                    return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.minThreshold
                }));
                return n ? d = l().createElement(U, {
                    a11yIdentifierBlock: t,
                    id: i,
                    html: o
                }) : "number" == typeof a && a >= c && (d = l().createElement(U, {
                    a11yIdentifierBlock: t,
                    id: i,
                    html: o.replace(r, null == a ? void 0 : a.toString())
                })), d
            };
            let Vt, Zt = e => e;
            const _t = {
                right: "flex-end",
                left: "flex-start",
                center: "center"
            };
            var Ot = ({
                    componentId: e,
                    a11yIdentifierBlock: t,
                    formVersionCId: n,
                    theme: i,
                    a11yIdentifierStyles: r
                }) => {
                    const d = (0, f.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                        c = (0, f.Z)((t => {
                            var n;
                            return (null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.fieldId) || ""
                        })),
                        m = (0, f.Z)((t => {
                            var n;
                            return (null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.label) || ""
                        })),
                        u = (0, f.Z)((t => {
                            var n;
                            return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.showLabel
                        })),
                        p = (0, f.Z)((t => {
                            var n;
                            return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.checkboxLabel
                        })),
                        h = (0, f.Z)((t => {
                            var n;
                            const o = null == (n = t.formsState.components[e]) || null == (n = n.data) || null == (n = n.styling) ? void 0 : n.innerAlignment;
                            return o ? _t[o] : "flex-start"
                        })),
                        {
                            inputName: v,
                            labelId: y
                        } = (0, s.useMemo)((() => {
                            const e = (0, g.Z)(`${encodeURIComponent(c)}__`);
                            return {
                                inputName: e,
                                labelId: `kl_${e}_label`
                            }
                        }), [c]);
                    (0, s.useEffect)((() => {
                        (0, E.hX)({
                            formVersionCId: n,
                            componentId: e,
                            value: "false"
                        })
                    }), [e, n]);
                    return l().createElement(a.ZC, {
                        a11yIdentifier: t,
                        style: {
                            width: "100%",
                            justifyContent: h,
                            display: "flex"
                        }
                    }, l().createElement(a.C3, {
                        className: (0, I.iv)(Vt || (Vt = Zt `
          &&& {
            input:focus-visible + label > svg {
              outline: 2px solid;
              outline-color: ${0};
              outline-offset: 0;
              box-shadow: 0 0 0 4px #ffffff;
            }
          }
        `), i.inputStyles.border.activeColor || i.focusColor),
                        style: {
                            alignSelf: "flex-end",
                            display: "block"
                        },
                        a11yIdentifier: r
                    }, l().createElement(x.Z, {
                        a11yIdentifier: r,
                        id: y,
                        theme: i,
                        style: {
                            marginRight: 8,
                            marginBottom: 8
                        },
                        showLabel: !(void 0 !== u || !m) || u,
                        asLegend: !0
                    }, m), l().createElement(re, {
                        formVersionCId: n,
                        theme: i,
                        name: v,
                        label: p,
                        alignCheckbox: "flex-start",
                        isValid: !0,
                        componentType: o.OV,
                        componentAriaID: y,
                        onChange: t => {
                            (0, $.l)(), (0, E.hX)({
                                formVersionCId: n,
                                componentId: e,
                                value: t.target.checked.toString()
                            })
                        },
                        tabIndex: d ? -1 : 0,
                        a11yIdentifierStyles: r
                    })))
                },
                Ft = n(22043),
                Mt = n(73578),
                At = n(53918);
            const Dt = () => null,
                {
                    THEME_KEY: Nt
                } = Mt.default,
                Bt = {
                    blue: "https://d3k81ch9hvuctc.cloudfront.net/assets/email/review-block/verified.png",
                    dark: "https://d3k81ch9hvuctc.cloudfront.net/assets/email/review-block/verified-dark.png",
                    light: "https://d3k81ch9hvuctc.cloudfront.net/assets/email/review-block/verified-light.png"
                };
            var Rt = ({
                componentId: e,
                theme: t,
                a11yIdentifierBlock: n
            }) => {
                var o, i, r, s, d, c;
                const m = (0, f.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                    u = (0, f.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.reviewData
                    })),
                    p = (0, f.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.reviewDisplayOptions
                    })),
                    h = !!u,
                    v = null != (o = null == u ? void 0 : u.rating) ? o : 5,
                    y = null != (i = null == u ? void 0 : u.content) ? i : "",
                    g = null != u && u.author ? `- ${null==u?void 0:u.author}` : "",
                    I = null != (r = null == u ? void 0 : u.verified) && r,
                    b = null == (s = null == p ? void 0 : p.showRating) || s,
                    S = null == (d = null == p ? void 0 : p.showAuthor) || d,
                    w = null == (c = null == p ? void 0 : p.showVerified) || c,
                    x = {
                        color: t[Nt].ratingStyle.color,
                        fontSize: t[Nt].ratingStyle.fontSize
                    },
                    C = {
                        color: t[Nt].ratingStyle.emptyColor,
                        fontSize: t[Nt].ratingStyle.fontSize
                    },
                    E = (e => {
                        switch (e) {
                            case At.B.STAR:
                                return "★";
                            case At.B.HEART:
                                return "♥";
                            case At.B.CIRCLE:
                                return "●";
                            default:
                                return "★"
                        }
                    })(t[Nt].ratingStyle.shape);
                return m && !h ? l().createElement(Dt, null) : l().createElement(a.ZC, {
                    a11yIdentifier: n,
                    style: {
                        alignItems: "center",
                        justifyContent: "center",
                        width: "100%",
                        height: "auto"
                    }
                }, b && l().createElement("div", {
                    style: {
                        display: "flex",
                        justifyContent: (() => {
                            switch (t[Nt].ratingStyle.alignment) {
                                case "center":
                                    return "center";
                                case "right":
                                    return "flex-end";
                                default:
                                    return "flex-start"
                            }
                        })(),
                        gap: `${t[Nt].ratingStyle.characterSpacing}px`,
                        marginBottom: "12px"
                    }
                }, l().createElement("span", {
                    style: v >= 1 ? x : C
                }, E), l().createElement("span", {
                    style: v >= 2 ? x : C
                }, E), l().createElement("span", {
                    style: v >= 3 ? x : C
                }, E), l().createElement("span", {
                    style: v >= 4 ? x : C
                }, E), l().createElement("span", {
                    style: v >= 5 ? x : C
                }, E)), l().createElement("div", {
                    style: {
                        marginBottom: "8px",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: (() => {
                            switch (t[Nt].quoteStyle.alignment) {
                                case "center":
                                    return "center";
                                case "right":
                                    return "flex-end";
                                default:
                                    return "flex-start"
                            }
                        })(),
                        gap: "8px"
                    }
                }, l().createElement("span", {
                    style: {
                        fontFamily: t[Nt].quoteStyle.fontFamily,
                        fontSize: t[Nt].quoteStyle.fontSize,
                        color: t[Nt].quoteStyle.textColor,
                        letterSpacing: `${t[Nt].quoteStyle.characterSpacing}px`,
                        fontWeight: t[Nt].quoteStyle.fontWeight,
                        lineHeight: t[Nt].quoteStyle.lineHeight
                    }
                }, "“", y, "”"), S && (g || I && w) && l().createElement("span", {
                    style: {
                        color: "#666",
                        display: "flex",
                        alignItems: "center",
                        gap: "4px",
                        lineHeight: t[Nt].quoteStyle.lineHeight
                    }
                }, S && l().createElement("span", null, g), I && w && l().createElement("img", {
                    src: Bt[t[Nt].verifiedBadgeStyle.colorAsset],
                    alt: "Verified",
                    style: {
                        width: t[Nt].verifiedBadgeStyle.size,
                        height: t[Nt].verifiedBadgeStyle.size
                    }
                }))))
            };
            var jt = (e, t = (() => l().createElement(l().Fragment, null))) => {
                function n(n) {
                    const [o, i] = l().useState(0), r = l().useCallback((() => i((e => e < 5 ? e + 1 : e))), []), s = l().useMemo((() => l().lazy((() => e().catch((() => ({
                        default: () => (r(), l().createElement(l().Fragment, null))
                    })))))), [e, o]);
                    return l().createElement(l().Suspense, {
                        fallback: l().createElement(t, null)
                    }, l().createElement(s, n))
                }
                return n.displayName = "LazyLoader", n
            };
            const zt = {
                [o.Ct]: y,
                [o.jR]: K,
                [o.qn]: M,
                [o.xC]: M,
                [o.J8]: jt((() => Promise.all([n.e(2462), n.e(9734), n.e(4371), n.e(6908)]).then(n.bind(n, 96370)))),
                [o.YQ]: R,
                [o.zV]: me,
                [o.hD]: me,
                [o.ZW]: M,
                [o.UO]: jt((() => Promise.all([n.e(2462), n.e(9734), n.e(4983)]).then(n.bind(n, 20231)))),
                [o.B1]: Le,
                [o.Xe]: Xe,
                [o.Ys]: M,
                [o._2]: $t,
                [o.eC]: M,
                [o.rY]: Tt,
                [o.OV]: Ot,
                [o.K0]: Ft.ZP,
                [o.SO]: R,
                [o.ye]: Rt
            }
        },
        70554: function(e, t, n) {
            var o = n(95775),
                i = n.n(o),
                r = n(87789),
                s = n.n(r),
                l = n(76223),
                a = n.n(l),
                d = n(39263);
            const c = ["children", "theme", "showLabel", "style", "asLegend"];
            t.Z = e => {
                let {
                    children: t,
                    theme: n,
                    showLabel: o,
                    style: r,
                    asLegend: l
                } = e, m = s()(e, c);
                if (!t) return null;
                const u = l ? d.De : d.__;
                return a().createElement(u, i()({
                    className: o ? "" : "klaviyo-sr-only",
                    style: Object.assign({
                        color: n.inputStyles.textStyles.color,
                        fontFamily: n.inputStyles.textStyles.fontFamily,
                        fontSize: n.inputStyles.textStyles.fontSize,
                        fontWeight: n.inputStyles.textStyles.labelFontWeight,
                        letterSpacing: n.inputStyles.textStyles.letterSpacing,
                        paddingBottom: 6
                    }, r)
                }, m), t)
            }
        },
        22043: function(e, t, n) {
            n.d(t, {
                Rd: function() {
                    return k
                }
            });
            n(92461), n(39265), n(60873), n(83362);
            var o = n(76223),
                i = n.n(o),
                r = n(94926),
                s = n(17547),
                l = n(39263),
                a = n(75186),
                d = n(1247),
                c = n(23759),
                m = n(51440);
            let u, f, p, h, v, y, g, I, b, S, w, x, C = e => e;
            const E = 1e3,
                k = 8e3,
                $ = e => {
                    let t = 0;
                    e > 75 ? t = 270 : e > 50 ? t = 180 : e > 25 && (t = 90);
                    const n = 3.6 * e - t,
                        o = (90 - n) * (Math.PI / 180),
                        i = 50 * Math.sin(o),
                        r = n * (Math.PI / 180),
                        s = 50 * Math.sin(r);
                    let l = `\n    50% 50%,\n    50% 0%,\n    100% 0%,\n    ${e<=25?`${50+s}% ${50-i}%`:"100% 50%"}\n  `;
                    return e > 25 && (l = `${l},\n      100% 100%,\n      ${e<=50?`${50+i}% ${50+s}%`:"50% 100%"}\n    `), e > 50 && (l = `${l},\n      0% 100%,\n      ${e<=75?`${50-s}% ${50+i}%`:"0% 100%"}\n    `), e > 75 && (l = `${l},\n      0% 0%,\n      ${e<=100?`${50-i}% ${50-s}%`:"50% 0%"}\n    `), `polygon(${l})`
                };
            t.ZP = ({
                componentId: e,
                a11yIdentifierBlock: t
            }) => {
                const n = (0, a.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.wheelLogic
                    })),
                    k = (0, a.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.wheelStyle
                    })),
                    T = (0, a.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.sliceStyles
                    })) || [],
                    V = (0, a.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.textStyle
                    })),
                    Z = (0, o.useMemo)((() => {
                        let e = [];
                        return e = null != n && n.duplicate ? null != n && n.slices ? [...null == n ? void 0 : n.slices, ...null == n ? void 0 : n.slices] : [] : null != n && n.slices ? [...n.slices] : [], e.map(((e, t) => Object.assign({}, e, {
                            key: `slice_${t}`
                        })))
                    }), [n]),
                    _ = (0, a.Z)((t => {
                        var n;
                        const o = (0, c.Hp)(t, e);
                        if (!o) return null;
                        const i = null == (n = t.formsState.views[o]) ? void 0 : n.formVersionId;
                        return i ? (0, m.Tf)(t, i) : null
                    })),
                    O = (0, a.Z)((e => _ ? (0, d.L)(e, _) : "")),
                    F = (0, o.useMemo)((() => null != n && n.slices && O ? n.slices.find((e => e.childViewId === O)) : null), [n, O]),
                    M = (0, o.useMemo)((() => {
                        if (!F) return null;
                        const e = ((e, t) => {
                            const n = ((e, t) => e.reduce(((e, n, o) => (n.childViewId === t && e.push(o), e)), []))(e, t);
                            return n.length ? n[Math.floor(Math.random() * n.length)] : null
                        })(Z, F.childViewId);
                        if ((0, s.x)(e)) return null;
                        const {
                            anticipation: t,
                            acceleration: n,
                            deceleration: o,
                            overshoot: i
                        } = ((e, t) => {
                            const n = 360 / t,
                                o = e * n,
                                i = (e => 90 - 360 / e / 2)(t),
                                s = i - o + 3240,
                                l = s - (Math.floor(Math.random() * n / 2) - n / 2) + 720;
                            return {
                                anticipation: (0, r.F4)(u || (u = C `
      0% {
        transform: rotate(0deg);
      }
      100% {
        transform: rotate(-8deg);
      }
    `)),
                                acceleration: (0, r.F4)(f || (f = C `
      0% {
        transform: rotate(-8deg);
      }
      100% {
        transform: rotate(${0}deg);
      }
    `), s),
                                deceleration: (0, r.F4)(p || (p = C `
      0% {
        transform: rotate(${0}deg);
      }
      100% {
        transform: rotate(${0}deg);
      }
    `), s, l),
                                overshoot: (0, r.F4)(h || (h = C `
      0% {
        transform: rotate(${0}deg);
      }
      100% {
        transform: rotate(${0}deg);
      }
    `), l, l - 4)
                            }
                        })(e, Z.length);
                        return `${t} 500ms cubic-bezier(0.35, 0, 0.50, 1) forwards,\n            ${n} 2750ms cubic-bezier(0.36, 0, 0.52, 0.70) 500ms forwards,\n            ${o} 3000ms cubic-bezier(0.3, 0.8, 0.5, 0.99) 3250ms forwards,\n            ${i} 1000ms cubic-bezier(0.75, 0.2, 0.67, 1) 6250ms forwards`
                    }), [F, Z]),
                    A = (0, o.useMemo)((() => {
                        var e, t;
                        let n = null != (e = null == k ? void 0 : k.wheelSize) ? e : 400,
                            o = n / 2,
                            i = n / 4,
                            s = n / 5;
                        n > E && (n = E, o = 500, i = 250, s = 200);
                        let l = null != (t = null == k ? void 0 : k.outlineThickness) ? t : 0;
                        return l > 100 && (l = 100), {
                            container: (0, r.iv)(v || (v = C `
        &&& {
          & {
            position: relative;
            width: ${0}px;
            height: ${0}px;
            display: flex;
            justify-content: center;
            align-items: center;
          }
        }
      `), n, n + l),
                            innerContainer: (0, r.iv)(y || (y = C `
        &&& {
          & {
            width: ${0}px;
            height: ${0}px;
            display: flex;
            justify-content: center;
            align-items: center;
            ${0};
          }
        }
      `), n, n, M ? `@media (prefers-reduced-motion: no-preference) {\n                  animation: ${M};\n                }` : ""),
                            slice: (0, r.iv)(g || (g = C `
        &&& {
          & {
            position: absolute;
            width: ${0}px;
            height: ${0}px;
            transform-origin: center;
            border-radius: 50%;
            border: ${0}px solid ${0};
          }
        }
      `), n, n, l, null == k ? void 0 : k.outlineColor),
                            sliceLabelContainer: (0, r.iv)(I || (I = C `
        &&& {
          & {
            width: ${0}px;
            margin: 0 auto;
            transform: rotate(-90deg) translate(-80px);
            transform-origin: center;
          }
        }
      `), o),
                            sliceLabel: (0, r.iv)(b || (b = C `
        &&& {
          & {
            text-align: center;
            font-family: ${0};
            font-size: ${0};
            font-weight: ${0};
            transform: rotate(${0}deg);
            transform-origin: left;
            padding-left: 20px;
            text-overflow: ellipsis;
            overflow: hidden;
          }
        }
      `), null == V ? void 0 : V.fontFamily, null == V ? void 0 : V.fontSize, null == V ? void 0 : V.fontWeight, 180 / Z.length),
                            center: (0, r.iv)(S || (S = C `
        &&& {
          & {
            position: absolute;
            width: ${0}px;
            height: ${0}px;
            background-color: ${0};
            border-radius: 50%;
            display: flex;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2),
              0 6px 20px 0 rgba(0, 0, 0, 0.2);
          }
        }
      `), i, i, null == k ? void 0 : k.centerColor),
                            pin: (0, r.iv)(w || (w = C `
        &&& {
          & {
            position: absolute;
            right: 1px;
            width: ${0}px;
            height: ${0}px;
            background-color: ${0};
            clip-path: polygon(100% 0%, 50% 50%, 100% 100%);
            border-radius: 20%;
            display: flex;
          }
        }
      `), s, s, null == k ? void 0 : k.pinColor),
                            pinOutline: (0, r.iv)(x || (x = C `
        &&& {
          & {
            position: absolute;
            width: ${0}px;
            height: ${0}px;
            border-radius: 49%;
            display: flex;
            background: radial-gradient(
              circle at center,
              transparent 69%,
              ${0} 25%
            );
          }
        }
      `), n, n, null == k ? void 0 : k.pinColor)
                        }
                    }), [k, V, Z, M]);
                return i().createElement(l.ZC, {
                    className: "klaviyo-spintowin",
                    a11yIdentifier: t,
                    "data-testid": "klaviyo-spintowin",
                    style: {
                        width: "100%",
                        justifyContent: "center",
                        justifySelf: "center",
                        display: "flex"
                    }
                }, i().createElement(l.ZC, {
                    className: A.container,
                    a11yIdentifier: t
                }, i().createElement(l.ZC, {
                    className: A.innerContainer,
                    a11yIdentifier: t
                }, Z.map(((e, n) => {
                    var o, r;
                    return i().createElement(l.ZC, {
                        key: e.key,
                        className: A.slice,
                        a11yIdentifier: t,
                        style: {
                            clipPath: $(100 / Z.length),
                            transform: `rotate(${n*(360/Z.length)}deg)`,
                            backgroundColor: null == (o = T[n % T.length]) ? void 0 : o.backgroundColor
                        }
                    }, i().createElement(l.ZC, {
                        className: A.sliceLabelContainer,
                        a11yIdentifier: t
                    }, i().createElement(l.ZC, {
                        className: A.sliceLabel,
                        a11yIdentifier: t,
                        style: {
                            color: null == (r = T[n % T.length]) ? void 0 : r.textColor
                        }
                    }, e.label)))
                }))), i().createElement(l.ZC, {
                    className: A.center,
                    a11yIdentifier: t
                }), i().createElement(l.ZC, {
                    className: A.pin,
                    a11yIdentifier: t
                }), i().createElement(l.ZC, {
                    className: A.pinOutline,
                    a11yIdentifier: t
                })))
            }
        },
        3689: function(e, t, n) {
            var o = n(76223),
                i = n.n(o),
                r = n(94926),
                s = n(39263),
                l = n(22830),
                a = n(5598),
                d = n(72534),
                c = n(48753),
                m = n(81422),
                u = n(75186);
            let f, p = e => e;
            t.Z = ({
                formVersionCId: e,
                validationErrorType: t,
                validationErrorMessage: n,
                metadata: o,
                componentAriaID: h,
                theme: v,
                a11yIdentifier: y
            }) => {
                const g = (0, u.Z)((t => {
                        var n;
                        const o = t.onsiteState.openFormVersions[e];
                        return o ? null == (n = t.formsState.formVersions[o.formVersionId]) ? void 0 : n.formTypeDirection : void 0
                    })),
                    I = !(null == g || !g.startsWith("BOTTOM")),
                    b = v.inputStyles.textStyles.errorColor;
                return i().createElement(s.ZC, {
                    style: {
                        width: "100%",
                        position: "relative"
                    },
                    a11yIdentifier: y
                }, t && i().createElement(s.ZC, {
                    a11yIdentifier: y,
                    style: Object.assign({
                        backgroundColor: "white",
                        position: "absolute",
                        zIndex: 1,
                        right: 0,
                        borderRadius: 4,
                        animation: "klaviyo-fadein 0.4s",
                        pointerEvents: "none"
                    }, I ? {
                        bottom: 47
                    } : {
                        top: 9
                    })
                }, i().createElement(s.ZC, {
                    a11yIdentifier: y,
                    className: (0, r.iv)(f || (f = p `
              &&& {
                &::after {
                  content: '';
                  display: block;
                  position: absolute;
                  width: 0;
                  height: 0;
                  border-style: solid;
                  left: 8px;
                  border-width: 8px;
                  ${0}
                }
                &::before {
                  content: '';
                  display: block;
                  position: absolute;
                  width: 0;
                  height: 0;
                  border-style: solid;
                  border-width: 9px;
                  left: 7px;
                  ${0};
                }
              }
            `), I ? "bottom: -15px;\n                  border-color: rgb(255, 244, 240) transparent transparent transparent;" : "top: -15px;\n                  border-color: transparent transparent rgb(255, 244, 240) transparent;", I ? `bottom: -17px;\n                    border-color: ${b} transparent transparent transparent;` : `top: -17px;\n                    border-color: transparent transparent ${b} transparent;`),
                    style: {
                        borderRadius: 4,
                        boxShadow: "1px 1px 4px 0 rgba(0, 0, 0, 0.26)",
                        border: `1px solid ${v.inputStyles.textStyles.errorColor}`,
                        backgroundColor: "rgb(255, 244, 240)",
                        pointerEvents: "none"
                    }
                }, i().createElement(s.Dr, {
                    style: {
                        fontSize: 14,
                        padding: 8,
                        fontFamily: v.inputStyles.textStyles.fontFamily,
                        color: v.inputStyles.textStyles.errorColor,
                        pointerEvents: "none"
                    },
                    role: "alert",
                    id: h,
                    a11yIdentifier: y
                }, (({
                    validationErrorType: e,
                    validationErrorMessage: t,
                    metadata: n
                }) => {
                    if (t) return t;
                    switch (e) {
                        case l.d:
                            return "This field is required";
                        case a.d:
                            return "This email is invalid";
                        case d.d:
                            return "The date format is invalid";
                        case c.d:
                            return n ? `Must be ${n.smsMinimumAge||21} or older.` : "";
                        case m.d:
                            return "This number is invalid";
                        default:
                            return ""
                    }
                })({
                    validationErrorType: t,
                    validationErrorMessage: n,
                    metadata: o
                })))))
            }
        },
        16958: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return x
                }
            });
            var o = n(95775),
                i = n.n(o),
                r = n(76223),
                s = n.n(r),
                l = n(89010),
                a = n(94926),
                d = n(23034),
                c = n(75186),
                m = n(39263),
                u = n(13901),
                f = n(57905),
                p = n(9247),
                h = n(8054),
                v = n(51440),
                y = n(32820);
            let g, I = e => e;
            const b = () => null,
                S = {
                    right: 0,
                    top: 0
                },
                w = y.Z;
            var x = ({
                title: e,
                onClick: t,
                viewId: n,
                buttonStyling: o,
                positionalStyles: y = S,
                isTeaser: x = !1,
                designerFunctions: C,
                designerInfo: E
            }) => {
                const k = (0, c.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                    $ = (0, c.Z)((e => {
                        if (n) return (0, v.l)(e, n)
                    }), d.X),
                    [T, V] = (0, r.useState)(!1),
                    Z = null == E ? void 0 : E.activeSidebar,
                    _ = (0, r.useMemo)((() => (null == Z ? void 0 : Z.type) === p.cn || (null == Z ? void 0 : Z.type) === p.iy), [Z]),
                    O = x ? p.iy : p.cn,
                    F = () => {
                        C && C.setActiveSidebar({
                            type: O
                        })
                    },
                    M = x ? h.Z.dismissButtonStyles : u.Z.dismissButtonStyles,
                    A = (0, l.Z)({}, M, o),
                    D = A.size,
                    N = T || _,
                    B = y === S,
                    R = (0, r.useMemo)((() => k ? "dismiss:dismiss:form" : void 0), [k]),
                    j = (0, c.Z)((e => !!e.onsiteState.client.isDesignWorkflow && !!e.onsiteState.client.isIAM));
                return s().createElement(s().Fragment, null, N && s().createElement(b, {
                    size: D,
                    isSelected: _,
                    $margin: B ? A.margin : {},
                    positionalStyles: y,
                    closeButton: !0
                }), s().createElement(w, {
                    isIAMEditor: j,
                    componentId: p.cn,
                    readonly: !0
                }, (n => s().createElement(m.CI, i()({
                    dndElProps: n,
                    a11yIdentifier: R,
                    width: D,
                    height: D,
                    tabIndex: 0,
                    alt: "Close dialog",
                    style: Object.assign({}, y, {
                        position: "absolute",
                        zIndex: 6,
                        cursor: "pointer",
                        height: `${D}px`,
                        width: `${D}px`,
                        borderRadius: "50%"
                    }, B && {
                        marginRight: `${A.margin.right}px`,
                        marginTop: `${A.margin.top}px`
                    }),
                    className: `${k?"":"klaviyo-close-form"} ${(0,a.iv)(g||(g=I`
              &&& {
                &:focus-visible {
                  outline-width: 2px;
                  outline-style: auto;
                  outline-color: ${0};
                  outline-offset: 0;
                }
              }
            `),(null==$?void 0:$.focusColor)||f.Z.theme.focusColor)}`,
                    viewBox: "0 0 20 20",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    onClick: t,
                    "aria-label": e
                }, k && !j && {
                    onClick: F,
                    onMouseOver: () => {
                        V(!0)
                    },
                    onMouseLeave: () => V(!1)
                }), s().createElement("title", {
                    id: `title-${e.split(" ").join("-")}`
                }, e), s().createElement("circle", {
                    style: {
                        cursor: "pointer"
                    },
                    cx: "10",
                    cy: "10",
                    r: "9.5",
                    fill: A.backgroundColor,
                    stroke: A.borderColor
                }), s().createElement("path", {
                    style: {
                        cursor: "pointer"
                    },
                    d: "M6 6L14 14M6 14L14 6L6 14Z",
                    stroke: A.xColor,
                    strokeWidth: A.xStroke,
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                })))))
            }
        },
        19416: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return ie
                }
            });
            var o = n(95775),
                i = n.n(o),
                r = (n(92461), n(39265), n(76223)),
                s = n.n(r),
                l = n(94926),
                a = n(23034),
                d = n(60093),
                c = n(64954);
            var m = () => (0, d.Z)() && !window.klaviyoForceMobile && window.screen.availHeight < window.screen.availWidth,
                u = n(28391);
            var f, p, h, v = (e, t) => {
                    var n, o, i;
                    let r = e.formType === u.nq && [u.Gi, u.qK].includes(null == (n = e.data) || null == (n = n.flyoutOptions) ? void 0 : n.docking);
                    m() && (r = !1);
                    let s = e.formTypeDirection || null;
                    var l;
                    r && t && (s = (null == (l = e.data) || null == (l = l.flyoutOptions) ? void 0 : l.docking) === u.Gi ? u.DA : u.qS);
                    return {
                        isDocked: r && t,
                        evaluatedFormTypeDirection: s,
                        dockedDirection: (null == (o = e.data) || null == (o = o.flyoutOptions) ? void 0 : o.docking) === u.kW || null == (i = e.data) || null == (i = i.flyoutOptions) ? void 0 : i.docking
                    }
                },
                y = n(14988),
                g = n(57905),
                I = n(9247),
                b = n(18886),
                S = n(20077),
                w = n(80101),
                x = n(22903),
                C = n(83485),
                E = n(16958),
                k = n(75186),
                $ = n(39263),
                T = n(95223);

            function V() {
                return V = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var o in n)({}).hasOwnProperty.call(n, o) && (e[o] = n[o])
                    }
                    return e
                }, V.apply(null, arguments)
            }
            var Z = function(e) {
                    return r.createElement("svg", V({
                        width: 160,
                        height: 24,
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg"
                    }, e), f || (f = r.createElement("path", {
                        d: "M0 0h160v22a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V0Z",
                        fill: "#373F47"
                    })), p || (p = r.createElement("path", {
                        d: "M24.728 15.144c1.416 0 2.376-.672 3.048-1.596l-.84-.456a2.723 2.723 0 0 1-2.208 1.164c-1.752 0-3.084-1.356-3.084-3.252 0-1.92 1.332-3.252 3.084-3.252.912 0 1.752.48 2.208 1.164l.828-.468c-.636-.912-1.62-1.584-3.036-1.584-2.304 0-4.116 1.68-4.116 4.14s1.812 4.14 4.116 4.14ZM29.909 15v-4.104c.264-.468 1.02-.924 1.584-.924.132 0 .24.012.348.024v-.924c-.792 0-1.464.456-1.932 1.056v-.924h-.9V15h.9Zm5.69.144c.935 0 1.715-.324 2.303-.9l-.432-.588a2.522 2.522 0 0 1-1.8.744c-1.248 0-2.004-.912-2.076-2.004h4.68v-.228c0-1.74-1.032-3.108-2.784-3.108-1.656 0-2.856 1.356-2.856 3.036 0 1.812 1.236 3.048 2.964 3.048Zm1.787-3.42h-3.804c.048-.876.66-1.92 1.896-1.92 1.32 0 1.896 1.068 1.908 1.92ZM44.256 15v-3.984c0-1.404-1.008-1.956-2.244-1.956-.948 0-1.692.312-2.316.96l.42.624c.516-.564 1.08-.804 1.776-.804.84 0 1.464.444 1.464 1.212v1.044c-.468-.528-1.128-.78-1.92-.78-.984 0-2.016.6-2.016 1.908 0 1.26 1.044 1.92 2.016 1.92.78 0 1.452-.276 1.92-.804V15h.9Zm-2.484-.504c-.852 0-1.44-.528-1.44-1.272 0-.732.588-1.26 1.44-1.26.624 0 1.236.24 1.584.708v1.104c-.348.48-.96.72-1.584.72Zm5.776.648c.516 0 .84-.156 1.068-.372l-.264-.684a.852.852 0 0 1-.612.252c-.384 0-.576-.312-.576-.744v-3.6h1.176v-.792h-1.176V7.62h-.912v1.584h-.96v.792h.96v3.792c0 .864.432 1.356 1.296 1.356Zm4.68 0c.935 0 1.715-.324 2.303-.9l-.432-.588a2.522 2.522 0 0 1-1.8.744c-1.248 0-2.004-.912-2.076-2.004h4.68v-.228c0-1.74-1.032-3.108-2.784-3.108-1.656 0-2.856 1.356-2.856 3.036 0 1.812 1.236 3.048 2.964 3.048Zm1.787-3.42h-3.804c.048-.876.66-1.92 1.896-1.92 1.32 0 1.896 1.068 1.908 1.92ZM61.461 15V6.996h-.9v3.084c-.468-.636-1.176-1.02-1.956-1.02-1.512 0-2.58 1.188-2.58 3.048 0 1.884 1.068 3.036 2.58 3.036a2.44 2.44 0 0 0 1.956-1.008V15h.9Zm-2.628-.66c-1.176 0-1.872-.948-1.872-2.232 0-1.284.696-2.244 1.872-2.244.708 0 1.416.432 1.728.936v2.616c-.312.504-1.02.924-1.728.924Zm13.464.66 1.848-5.796h-.948l-1.416 4.62-1.512-4.62h-.78l-1.524 4.62-1.416-4.62h-.936L67.46 15h.9l1.512-4.656L71.385 15h.912Zm3.34-6.624c.336 0 .6-.264.6-.6a.604.604 0 0 0-.6-.612.615.615 0 0 0-.612.612c0 .336.276.6.612.6ZM76.081 15V9.204h-.9V15h.9Zm3.272.144c.516 0 .84-.156 1.068-.372l-.264-.684a.852.852 0 0 1-.612.252c-.384 0-.576-.312-.576-.744v-3.6h1.176v-.792h-1.176V7.62h-.912v1.584h-.96v.792h.96v3.792c0 .864.432 1.356 1.296 1.356ZM86.228 15v-4.092c0-1.26-.636-1.848-1.848-1.848-.876 0-1.668.492-2.064.984V6.996h-.9V15h.9v-4.236c.336-.468 1.008-.9 1.704-.9.792 0 1.308.288 1.308 1.32V15h.9ZM119.251 7.717a.956.956 0 0 0 .684-.287 1.03 1.03 0 0 0 .296-.703 1.052 1.052 0 0 0-.29-.717.973.973 0 0 0-.69-.301.959.959 0 0 0-.676.307c-.178.19-.277.446-.276.711.002.262.103.513.281.698.178.185.419.29.671.292ZM125.909 8.667h2.363v.195c-.131.024-.257.07-.375.135-.216.105-.648.614-.979 1.468-.562 1.483-1.152 3.235-1.772 5.242l-.23.762c-.102.344-.188.569-.231.704-.043.136-.101.344-.202.599-.057.19-.13.376-.219.554-.116.224-.332.685-.505.824-.274.24-.677.509-1.181.464-.98 0-1.714-.761-1.729-1.662 0-.614.375-1.019.937-1.019.403 0 .763.229.763.704 0 .345-.331.704-.331.884 0 .464.259.685.764.685.402 0 .732-.27.979-.809.331-.614.36-1.288.086-2.037l-2.074-5.706c-.476-1.318-.836-1.751-1.282-1.798v-.195h3.27v.195c-.389.045-.591.285-.591.719 0 .314.115.794.331 1.408l.389 1.108c.447 1.199.806 2.247.995 2.906a81.428 81.428 0 0 1 1.181-3.61c.274-.778.403-1.332.403-1.662 0-.584-.302-.854-.763-.854l.003-.204ZM103.166 15.963c-.418-.076-.778-.465-.778-1.288v-9.93l-2.377.538v.21c.404-.045.806.33.806 1.123v8.059c0 .778-.404 1.227-.806 1.288a1.221 1.221 0 0 1-.715-.096c-.319-.145-.585-.403-.81-.788l-1.1-1.828a2.043 2.043 0 0 0-.981-.846 1.95 1.95 0 0 0-1.274-.067l1.24-1.423c.935-1.078 1.8-1.767 2.62-2.052v-.195h-2.725v.195c.706.285.663.914-.146 1.903l-1.743 2.112V4.744L92 5.284v.21c.403 0 .805.418.805 1.152v8.029c0 .883-.388 1.227-.805 1.288v.195h3.158v-.195c-.519-.076-.778-.494-.778-1.288v-1.483l.677-.779 1.638 2.8c.39.675.75.945 1.326.945h5.485v-.153s-.157-.011-.34-.042ZM109.707 15.014v-3.35c-.032-2.19-.915-3.188-2.938-3.188a2.808 2.808 0 0 0-1.786.63c-.533.419-.792.898-.792 1.453 0 .539.288.943.763.943.505 0 .865-.3.865-.719 0-.314-.202-.749-.202-1.048 0-.54.389-1.004 1.066-1.004.865 0 1.484.674 1.484 2.172v.898l-.72.18a10.01 10.01 0 0 0-.937.228c-.245.076-.561.18-.936.33-.75.3-1.152.584-1.499 1.123a1.62 1.62 0 0 0-.259.884c0 1.242.836 1.812 2.003 1.812.922 0 1.904-.51 2.348-1.468.006.302.076.6.204.871.488 1.028 2.106.42 2.106.42v-.195c-.708.115-.767-.76-.77-.972Zm-1.538-1.037c0 .494-.173.899-.519 1.183-.331.285-.676.435-1.037.435-.706 0-1.167-.48-1.167-1.364 0-.418.22-.808.404-1.033.145-.155.316-.282.504-.374.245-.135.366-.204.533-.285l.659-.254c.331-.135.533-.21.619-.255l.004 1.947ZM140 8.668h-5.603V4.744H140l-1.176 1.962L140 8.668ZM128.61 15.203a4.018 4.018 0 0 1-1.068-2.79 4.01 4.01 0 0 1 .266-1.5c.183-.476.456-.91.802-1.276.707-.78 1.572-1.17 2.583-1.17.995 0 1.861.39 2.568 1.17.351.363.627.796.813 1.273.186.477.278.988.269 1.503a4.04 4.04 0 0 1-.27 1.508 3.9 3.9 0 0 1-.812 1.282c-.707.761-1.573 1.155-2.568 1.155-1.011 0-1.876-.39-2.583-1.155Zm3.881-5.441c-.285-.58-.659-.92-1.098-1.01-.892-.187-1.679.765-1.973 2.28a7.466 7.466 0 0 0-.09 2.062c.064.689.248 1.36.543 1.98.286.58.659.918 1.099 1.01.891.186 1.701-.806 1.997-2.336.246-1.278.121-2.835-.482-3.987h.004Z",
                        fill: "#fff"
                    })), h || (h = r.createElement("path", {
                        d: "M120.085 14.675V8.67h-5.071v.18c.678.105 1 .637.692 1.499-1.584 4.478-1.483 4.277-1.584 4.636-.101-.345-.332-1.192-.706-2.255-.374-1.063-.62-1.768-.721-2.082-.389-1.243-.259-1.708.375-1.782V8.67h-3.285v.195c.49.105.922.689 1.282 1.737l.505 1.363c.554 1.472 1.205 3.502 1.423 4.194h1.092c.351-1.066 1.761-5.32 1.95-5.752.204-.492.435-.866.692-1.124.125-.139.276-.248.445-.322a1.24 1.24 0 0 1 .532-.102s.792 0 .792.794v5.022c0 .838-.389 1.228-.792 1.288v.195h3.14v-.195c-.415-.06-.761-.449-.761-1.288Z",
                        fill: "#fff"
                    })))
                },
                _ = n(89709),
                O = n(32820);
            const F = () => null,
                M = () => null,
                A = O.Z;
            var D = ({
                    openFormVersion: e,
                    designerFunctions: t,
                    designerInfo: n
                }) => {
                    const o = (0, k.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                        r = (0, k.Z)((e => e.onsiteState.client.klaviyoCompanyId)),
                        [l, a] = s().useState(!1),
                        d = (0, k.Z)((e => !!e.onsiteState.client.isDesignWorkflow && !!e.onsiteState.client.isIAM)),
                        c = null == n ? void 0 : n.activeSidebar,
                        m = (null == c ? void 0 : c.type) === I.zQ,
                        u = {
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                            cursor: "pointer",
                            marginTop: "4px"
                        },
                        f = l || m,
                        p = s().createElement(A, {
                            isIAMEditor: d,
                            componentId: I.zQ,
                            readonly: !0
                        }, (e => s().createElement($.ZC, i()({
                            ref: e.ref
                        }, e.listeners, e.attributes, {
                            className: e.className,
                            style: u
                        }), s().createElement(Z, null)))),
                        h = s().createElement($.ZC, {
                            style: u,
                            onMouseLeave: () => a(!1),
                            onMouseEnter: () => a(!0),
                            onClick: () => {
                                F("Created with Klaviyo Experiment | Clicked logo in builder", {
                                    companyId: r
                                }), t && t.setActiveSidebar({
                                    type: I.zQ
                                })
                            }
                        }, s().createElement(M, {
                            isSelected: m,
                            closeButton: !1,
                            $margin: {
                                top: 0,
                                bottom: 0,
                                left: 0,
                                right: 0
                            },
                            shouldWrap: f
                        }, s().createElement(Z, null))),
                        v = s().createElement("a", {
                            style: u,
                            href: "https://klaviyo.com/features/forms-web-personalization?utm_medium=referral&utm_source=plgform",
                            target: "_blank",
                            rel: "noopener noreferrer",
                            "aria-label": "Created with Klaviyo - opens in a new tab",
                            onClick: () => {
                                (0, _.M)({
                                    metric: T.tr,
                                    formVersionCId: e.formVersionCId,
                                    formId: e.formId,
                                    companyId: r
                                })
                            }
                        }, s().createElement(Z, null));
                    return s().createElement($.ZC, {
                        style: {
                            display: "flex",
                            justifyContent: "center"
                        }
                    }, d && p, !d && o && h, !d && !o && v)
                },
                N = n(87789),
                B = n.n(N),
                R = n(99946),
                j = n(98889);
            const z = ["animatingOut", "touchStartHandler", "touchMoveHandler", "touchEndHandler", "dragOffset", "useTransition", "transitionSpeed", "isSwipeToDismissEnabled", "formVersionCId", "designerInfo", "isA11y"],
                W = {
                    LEFT: "slideinleft",
                    TOP_CENTER: "slideinup",
                    BOTTOM_CENTER: "slideindown",
                    RIGHT: "slideinright"
                },
                P = {
                    POPUP: "fadeinup",
                    FULLSCREEN: "fadein"
                },
                L = ({
                    formType: e,
                    formTypeDirection: t,
                    teaserAnimationExists: n = !1,
                    animatingOut: o = !1,
                    isDesignWorkflow: i,
                    isA11y: r
                }) => {
                    const s = o || !o && n ? "both" : "forwards",
                        l = e === u.DV || e === u.UW ? P[e] : W[Object.keys(W).find((e => t && t.endsWith(e)))];
                    return Object.assign({}, R.s, {
                        animationFillMode: s
                    }, i ? {} : {
                        animationDelay: !o && n ? "0.25s" : "0s"
                    }, {
                        animationName: `klaviyo-${l}`
                    }, o ? {
                        animationDirection: "reverse",
                        animationDuration: e === u.DV || e === u.UW ? "0.35s" : ".5s"
                    } : {
                        animationDirection: "normal",
                        animationDuration: e === u.DV || e === u.UW ? "0.35s" : "1s"
                    }, r ? {
                        animationDelay: "0s",
                        animationDuration: "0s"
                    } : {})
                },
                H = ({
                    formTypeDirection: e,
                    modalScale: t
                }) => {
                    const n = {
                            TOP: {
                                top: 0
                            },
                            CENTER: {
                                top: "50%",
                                transform: `scale(${t}) translateY(-50%)`,
                                marginTop: "auto",
                                marginBottom: "auto"
                            },
                            BOTTOM: {
                                bottom: 0
                            }
                        },
                        o = {
                            LEFT: {
                                left: 0
                            },
                            CENTER: {
                                left: "50%",
                                transform: `scale(${t}) translateX(-50%)`,
                                marginLeft: "auto",
                                marginRight: "auto"
                            },
                            RIGHT: {
                                right: 0
                            }
                        };
                    return Object.assign({}, n[Object.keys(n).find((t => e && e.startsWith(t)))], o[Object.keys(o).find((t => e && e.endsWith(t)))])
                },
                q = e => {
                    let {
                        animatingOut: t = !1,
                        touchStartHandler: n,
                        touchMoveHandler: o,
                        touchEndHandler: l,
                        dragOffset: a = 0,
                        useTransition: c = !1,
                        transitionSpeed: m = .5,
                        isSwipeToDismissEnabled: f = !1,
                        formVersionCId: p,
                        designerInfo: h,
                        isA11y: y
                    } = e, g = B()(e, z);
                    const b = (0, k.Z)((e => {
                            var t;
                            return null == (t = e.onsiteState.openFormVersions[p]) ? void 0 : t.teaserAnimationInProgress
                        })),
                        S = (0, k.Z)((e => {
                            var t;
                            return null == (t = e.onsiteState.openFormVersions[p]) ? void 0 : t.formAnimationInProgress
                        })),
                        w = (0, k.Z)((e => {
                            var t;
                            return null == (t = e.onsiteState.openFormVersions[p]) ? void 0 : t.formVersionId
                        })),
                        x = (0, k.Z)((e => {
                            var t;
                            return null == (t = e.onsiteState.openFormVersions[p]) ? void 0 : t.currentViewId
                        })),
                        C = (0, k.Z)((e => {
                            var t;
                            return w ? null == (t = e.formsState.formVersions[w]) ? void 0 : t.formType : void 0
                        })),
                        E = (0, k.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                        T = (0, k.Z)((e => {
                            const t = w ? e.formsState.formVersions[w] : void 0;
                            if (t) return v(t, E ? (null == h ? void 0 : h.mobileDesktopType) === I.Jq : (0, d.Z)()).evaluatedFormTypeDirection
                        })),
                        [V, Z] = (0, r.useState)(!1);
                    (0, r.useEffect)((() => {
                        b && !V && Z(!0)
                    }), [V, b]);
                    const _ = (0, r.useMemo)((() => E ? `${I.Sq}:${I.Pg}:${x}` : void 0), [E, x]);
                    return s().createElement($.ZC, i()({
                        a11yIdentifier: _
                    }, g, {
                        onAnimationEnd: () => {
                            (0, j.fK)({
                                id: p,
                                changes: {
                                    formAnimationInProgress: !1
                                }
                            }), (0, j.sd)({
                                formVersionCId: p
                            })
                        },
                        onTouchStart: e => {
                            n && n(e)
                        },
                        onTouchMove: e => {
                            o && o(e)
                        },
                        onTouchEnd: e => {
                            l && l(e)
                        },
                        onAnimationStart: () => {
                            (0, j.fK)({
                                id: p,
                                changes: {
                                    hideFormBeforeAnimation: !1
                                }
                            })
                        },
                        style: Object.assign({
                            flex: 1,
                            minHeight: C === u.UW ? "100%" : void 0
                        }, f ? Object.assign({
                            bottom: -1 * a + "px",
                            position: "relative"
                        }, c ? {
                            transition: `bottom ${m}s`
                        } : {}) : {}, (S || E || t) && L({
                            formType: C,
                            formTypeDirection: T,
                            teaserAnimationExists: V,
                            animatingOut: t,
                            isDesignWorkflow: E,
                            isA11y: y
                        }) || {})
                    }))
                };
            var U = n(82883),
                K = n(52266);
            let G, Y, X = e => e;
            const J = e => !!e.id.includes("downshift") || !("FORM" === e.tagName || !e.parentElement) && J(e.parentElement);
            var Q = ({
                closePortal: e,
                formVersionCId: t,
                style: n,
                setOverlayDismissalPercentage: o,
                designerFunctions: c,
                designerInfo: m,
                isA11y: f = !1,
                a11yViewId: p,
                className: h
            }) => {
                var y, b, S, T, V, Z;
                const _ = (0, k.Z)((e => e.onsiteState.openFormVersions[t]), a.X),
                    O = (0, k.Z)((e => {
                        var n;
                        return null == (n = e.onsiteState.openFormVersions[t]) ? void 0 : n.modalIsClosing
                    })),
                    F = (0, k.Z)((e => {
                        var n;
                        return null == (n = e.onsiteState.openFormVersions[t]) ? void 0 : n.closePortal
                    })),
                    M = (0, k.Z)((e => _ ? e.formsState.formVersions[_.formVersionId] : void 0), a.X),
                    A = (0, k.Z)((e => {
                        var t;
                        return _ ? null == (t = e.formsState.formVersions[_.formVersionId]) || null == (t = t.data) ? void 0 : t.ignoreOverlayDismissal : void 0
                    })),
                    N = (0, k.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                    B = (0, k.Z)((e => e.onsiteState.client.showingShopLogin)),
                    R = (0, k.Z)((e => {
                        const t = _ ? e.formsState.forms[_.formId] : void 0;
                        return !!t && t.showKlaviyoBranding && (null == M ? void 0 : M.formType) === u.DV
                    })),
                    z = (0, k.Z)((e => (0, K.FK)(e))),
                    W = (0, k.Z)((e => {
                        var n;
                        return f && p ? p : null == (n = e.onsiteState.openFormVersions[t]) ? void 0 : n.currentViewId
                    })),
                    P = null == M || null == (y = M.data) ? void 0 : y.styling,
                    L = null == M || null == (b = M.data) || null == (b = b.styling) ? void 0 : b.borderRadius,
                    H = null == M || null == (S = M.data) || null == (S = S.styling) ? void 0 : S.dropShadow,
                    Q = null == M || null == (T = M.data) || null == (T = T.styling) ? void 0 : T.isReflow,
                    ee = null == m ? void 0 : m.mobileDesktopType,
                    {
                        isDocked: te,
                        evaluatedFormTypeDirection: ne,
                        dockedDirection: oe
                    } = M ? v(M, N ? ee === I.Jq : (0, d.Z)()) : {
                        isDocked: void 0,
                        evaluatedFormTypeDirection: void 0,
                        dockedDirection: void 0
                    },
                    [ie, re] = (0, r.useState)(),
                    se = (0, r.useRef)(null);
                (0, r.useEffect)((() => {
                    re((0, w.Z)("modal_animation_key"))
                }), [null == M ? void 0 : M.formType, null == M ? void 0 : M.formTypeDirection, ee]);
                const le = () => {
                        (0, j.et)({
                            formVersionCId: t
                        })
                    },
                    [ae, de] = (0, r.useState)(0),
                    [ce, me] = (0, r.useState)(0),
                    [ue, fe] = (0, r.useState)(!1),
                    [pe, he] = (0, r.useState)(.5),
                    [ve, ye] = (0, r.useState)(new Date),
                    ge = (e, t = !1) => {
                        o && o(e, t)
                    };
                (0, r.useEffect)((() => {
                    !F && (null == _ || !_.modalIsClosing || null != _ && _.formAnimationInProgress || !_.closeModalWhenAnimationCompletes) && (null != _ && _.modalIsClosing || null != _ && _.teaserAnimationInProgress || null == _ || !_.closeModalWhenAnimationCompletes || _.currentTeaserId) || e()
                }), [F, _]), (0, r.useEffect)((() => {
                    const n = n => {
                        var o, i, r, s;
                        null != (o = se.current) && o.contains(n.target) || N || t !== z || null === e || null != _ && _.currentTeaserId || (i = null == M ? void 0 : M.formType, r = A, s = B, !i || s === U.K.SHOWING || void 0 !== r && i === u.DV && ((0, d.Z)() ? !0 === (null == r ? void 0 : r.mobile) : !0 === (null == r ? void 0 : r.desktop))) || le()
                    };
                    return document.addEventListener("mousedown", n), document.addEventListener("touchstart", n), () => {
                        document.removeEventListener("mousedown", n), document.removeEventListener("touchstart", n)
                    }
                }), [N, t, z, e, A, _, B]);
                const Ie = null == M || null == (V = M.data) || null == (V = V.styling) ? void 0 : V.margin,
                    be = (0, r.useMemo)((() => N ? `${I.Sq}:${I.Pg}:${W}` : void 0), [N, W]),
                    Se = !N && te,
                    we = (0, l.iv)(Y || (Y = X `
    &&& {
      &::before {
        content: '';
        height: 100%;
        background-color: ${0};
        top: ${0};
        width: 100%;
        position: absolute;
      }
    }
  `), (null == P ? void 0 : P.backgroundColor) || g.Z.theme.backgroundColor, oe === u.qK ? "50%" : "-50%"),
                    xe = (0, r.useMemo)((() => void 0 === (null == M ? void 0 : M.data.showCloseButton) || (null == M ? void 0 : M.data.showCloseButton)), [null == M ? void 0 : M.data.showCloseButton]);
                return ie ? s().createElement($.ZC, {
                    a11yIdentifier: be,
                    ref: se,
                    style: Object.assign({}, n, {
                        borderRadius: `${L||g.Z.theme.borderRadius}px`,
                        position: "relative",
                        display: "flex",
                        justifyContent: "center"
                    }, !Q && {
                        flex: "0 0 auto"
                    }, (null == M ? void 0 : M.formType) === u.DV ? {
                        alignSelf: "center"
                    } : {}, (null == M ? void 0 : M.formType) === u.UW || (null == M ? void 0 : M.formType) === u.Mk ? {
                        alignSelf: "stretch",
                        flex: 1
                    } : {}, f ? {
                        position: "absolute",
                        zIndex: 1
                    } : {}),
                    "data-testid": ee,
                    className: h
                }, s().createElement(r.Suspense, {
                    fallback: s().createElement($.ZC, null)
                }, s().createElement(q, i()({
                    key: ie,
                    formVersionCId: t,
                    animatingOut: O,
                    "data-testid": null == M ? void 0 : M.formType,
                    isSwipeToDismissEnabled: Se
                }, Se ? {
                    touchStartHandler: e => {
                        J(e.target) || (he(.5), fe(!1), me(e.touches[0].clientY), ye(new Date))
                    },
                    touchMoveHandler: e => {
                        if (J(e.target)) return;
                        e.preventDefault();
                        const t = Math.abs(e.touches[0].clientY - ce);
                        if (oe === u.qK)
                            if (ce <= e.touches[0].clientY) {
                                const e = window.innerHeight - ce;
                                ge(t / e), de(t)
                            } else {
                                const e = .8 * window.innerHeight;
                                if (he(.1), t < e) {
                                    de(-1 * t / (10 / 2 ** (-1 * t / e)))
                                }
                            }
                        else if (ce >= e.touches[0].clientY) {
                            ge(t / ce), de(-1 * t)
                        } else {
                            const e = .8 * window.innerHeight;
                            if (t < e) {
                                de(t / (10 / 2 ** (-1 * t / e)))
                            }
                        }
                    },
                    touchEndHandler: e => {
                        if (J(e.target)) return;
                        fe(!0);
                        const t = (new Date).getTime() - ve.getTime(),
                            n = Math.abs(e.changedTouches[0].clientY - ce),
                            o = n / t,
                            i = oe === u.qK ? e.changedTouches[0].clientY > ce : e.changedTouches[0].clientY < ce,
                            r = oe === u.qK ? .9 : .1;
                        (oe === u.qK ? e.changedTouches[0].clientY / window.innerHeight > r : e.changedTouches[0].clientY / window.innerHeight < r) && n > .2 * window.innerHeight || Math.abs(o) > .8 && i && n >= .2 * window.innerHeight ? (de(oe === u.qK ? window.innerHeight : -1 * window.innerHeight), ge(1, !0), setTimeout((() => le()), 500)) : (de(0), ge(0, !0)), me(0)
                    },
                    dragOffset: ae,
                    useTransition: ue,
                    transitionSpeed: pe
                } : {}, {
                    designerInfo: m,
                    isA11y: f
                }), (Ce = s().createElement($.ZC, {
                    a11yIdentifier: be,
                    className: !N && te ? we : "",
                    style: (null == M ? void 0 : M.formType) === u.UW ? {
                        display: "flex",
                        flex: 1,
                        alignSelf: "stretch"
                    } : void 0
                }, s().createElement($.ZC, {
                    inert: !(!(0, d.Z)() || null == _ || !_.currentTeaserId) || void 0,
                    a11yIdentifier: be,
                    style: Object.assign({
                        position: "relative",
                        display: "flex"
                    }, {
                        flex: 1,
                        alignSelf: "stretch"
                    }, H && H.enabled ? {
                        boxShadow: `0px 0px ${H.blur}px ${H.color}`
                    } : {}, L ? {
                        borderRadius: `${L}px`
                    } : {})
                }, xe && !!W && s().createElement(E.Z, {
                    viewId: W,
                    buttonStyling: null == M || null == (Z = M.data) || null == (Z = Z.styling) ? void 0 : Z.dismissButtonStyles,
                    title: "Close dialog",
                    onClick: le,
                    designerFunctions: c,
                    designerInfo: m
                }), null != _ && _.errorViewMessage || null == _ || !_.formVersionId || !W ? s().createElement(C.Z, {
                    errorViewMessage: null == _ ? void 0 : _.errorViewMessage,
                    isFullscreen: (null == M ? void 0 : M.formType) === u.UW
                }) : s().createElement(x.Z, {
                    formVersionCId: t,
                    formVersionId: null == _ ? void 0 : _.formVersionId,
                    viewId: W,
                    isDocked: te,
                    formTypeDirection: ne,
                    designerFunctions: c,
                    designerInfo: m
                })), R && !!_ && s().createElement(D, {
                    openFormVersion: _,
                    designerFunctions: c,
                    designerInfo: m
                })), te ? Ce : s().createElement($.ZC, {
                    a11yIdentifier: be,
                    className: (0, l.iv)(G || (G = X `
            &&& {
              &::before {
                content: '';
                display: block;
                min-height: ${0}px;
                width: 100%;
              }
              &::after {
                content: '';
                display: block;
                min-height: ${0}px;
                width: 100%;
              }
            }
          `), (null == Ie ? void 0 : Ie.top) || 0, (null == Ie ? void 0 : Ie.bottom) || 0),
                    style: {
                        position: "relative",
                        flexDirection: "column",
                        display: "flex",
                        marginLeft: null == Ie ? void 0 : Ie.left,
                        marginRight: null == Ie ? void 0 : Ie.right,
                        flex: 1,
                        alignSelf: "stretch",
                        minHeight: (null == M ? void 0 : M.formType) === u.UW ? "100%" : void 0
                    }
                }, Ce))))) : null;
                var Ce
            };
            let ee, te, ne = e => e;
            const oe = 'button, [href], input:not([tabindex="-1"]), select, textarea, details, [tabindex]:not([tabindex="-1"])';
            var ie = ({
                formVersionCId: e,
                closePortal: t,
                className: n,
                designerFunctions: o,
                designerInfo: m,
                isA11y: f = !1,
                a11yViewId: p,
                portalNode: h
            }) => {
                var w, x, C;
                const E = (0, k.Z)((e => !!e.onsiteState.client.isIAM)),
                    T = (0, k.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                    V = E && T,
                    Z = (0, k.Z)((t => {
                        var n;
                        return f && p ? p : null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.currentViewId
                    })),
                    _ = (0, k.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.currentTeaserId
                    })),
                    O = (0, k.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.formVersionId
                    })),
                    F = (0, k.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.teaserAnimationInProgress
                    })),
                    M = (0, k.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.formAnimationInProgress
                    })),
                    A = (0, k.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.closeModalWhenAnimationCompletes
                    })),
                    D = (0, k.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.hideFormBeforeAnimation
                    })),
                    N = (0, k.Z)((e => O ? e.formsState.formVersions[O] : void 0), a.X);
                let B = (0, k.Z)((e => {
                    var t;
                    return (O ? null == (t = e.formsState.formVersions[O]) || null == (t = t.data) || null == (t = t.styling) ? void 0 : t.size : void 0) || g.Z.theme.size
                }));
                const R = (0, k.Z)((e => {
                        var t;
                        return O ? null == (t = e.formsState.formVersions[O]) || null == (t = t.data) ? void 0 : t.sideImage : void 0
                    }), a.X),
                    z = (0, k.Z)((e => {
                        var t;
                        return (O ? null == (t = e.formsState.formVersions[O]) || null == (t = t.data) || null == (t = t.styling) ? void 0 : t.overlayColor : void 0) || g.Z.theme.overlayColor
                    })),
                    W = (0, k.Z)((e => {
                        var t;
                        return (O ? null == (t = e.formsState.formVersions[O]) || null == (t = t.data) || null == (t = t.styling) ? void 0 : t.mobileOverlay : void 0) || g.Z.theme.mobileOverlay
                    }), a.X),
                    P = (0, k.Z)((e => e.onsiteState.client.isFetchingForms)),
                    L = (0, k.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.modalIsClosing
                    })),
                    q = (0, k.Z)((e => Object.values(e.formsState.columns).find((e => (null == e ? void 0 : e.position) === (null == R ? void 0 : R.position) && (null == e ? void 0 : e.viewId) === Z))), a.X),
                    U = (e => {
                        const t = (0, r.useRef)(!1),
                            n = (0, r.useRef)(null),
                            [o, i] = (0, r.useState)(null);
                        return (0, r.useEffect)((() => (t.current = !0, () => {
                            t.current = !1
                        })), []), (0, r.useEffect)((() => {
                            if (!e) return;
                            const t = new ResizeObserver((e => {
                                var t;
                                const o = null == e || null == (t = e[0]) || null == (t = t.contentRect) ? void 0 : t.width;
                                o && o !== n.current && i(o)
                            }));
                            return t.observe(e, {
                                box: "content-box"
                            }), () => t.disconnect()
                        }), [e]), o
                    })(h),
                    G = (0, r.useRef)(null),
                    [Y, X] = (0, r.useState)(0),
                    [J, ie] = (0, r.useState)(!1),
                    [re, se] = (0, r.useState)("none"),
                    le = null == R || null == (w = R.data) || null == (w = w.styling) ? void 0 : w.sizeMultiplier,
                    ae = le ? (0, c.Z)(le, B) : 0,
                    de = null == m ? void 0 : m.mobileDesktopType,
                    ce = T && de === I.Jq,
                    {
                        isDocked: me,
                        evaluatedFormTypeDirection: ue
                    } = N ? v(N, T ? de === I.Jq : (0, d.Z)()) : {
                        isDocked: void 0,
                        evaluatedFormTypeDirection: void 0
                    };
                ((0, d.Z)() || ce) && R && !(0, y.V)(R, T, de || I.q5, q) && (B -= ae);
                const fe = null == N || null == (x = N.data) || null == (x = x.styling) ? void 0 : x.margin,
                    pe = me ? 0 : (null == fe ? void 0 : fe.left) || 0,
                    he = me ? 0 : (null == fe ? void 0 : fe.right) || 0,
                    ve = null == N || null == (C = N.data) || null == (C = C.styling) ? void 0 : C.isReflow,
                    ye = Math.max(Math.min(parseInt(B.toString(), 10), b.Ez), b.Gg) + he + pe,
                    [ge, Ie] = (0, r.useState)(1),
                    be = (0, l.iv)(ee || (ee = ne `
    &&& {
      [data-testid='form-row'] {
        margin-bottom: calc((${0} - 1) * 1%);
      }
    }
  `), ge),
                    Se = (0, r.useMemo)((() => T ? be : void 0), [be, T]),
                    [we, xe] = (0, r.useState)(!1);
                (0, r.useEffect)((() => {
                    F && !we && xe(!0)
                }), [we, F]);
                const Ce = Object.assign({
                        animationTimingFunction: "ease",
                        animationPlayState: "running",
                        animationIterationCount: 1,
                        animationFillMode: !L && we ? "both" : "forwards"
                    }, f ? {
                        animationDelay: "0s",
                        animationDuration: "0s"
                    } : {
                        animationDelay: L || !we || T ? "0s" : "0.25s",
                        animationDuration: "0.35s"
                    }),
                    Ee = Object.assign({}, Ce, {
                        animationName: "klaviyo-fadeout"
                    }),
                    ke = Object.assign({}, Ce, {
                        animationName: "klaviyo-fadein"
                    });
                (0, r.useEffect)((() => {
                    if (ve) return () => {};
                    const e = () => {
                        if ((null == N ? void 0 : N.formType) !== u.UW && (null == N ? void 0 : N.formType) !== u.Mk) {
                            var e;
                            const t = (null == (e = document) || null == (e = e.documentElement) ? void 0 : e.clientWidth) || window.innerWidth,
                                n = ce ? I.aH : Math.min(t, U || 1 / 0),
                                o = me ? n / ye : Math.min(n / ye, 1);
                            Ie(o)
                        }
                    };
                    return window.addEventListener("resize", e), e(), () => {
                        window.removeEventListener("resize", e)
                    }
                }), [ve, U, ye, de]);
                const $e = (0, k.Z)((t => (0, K.JZ)(t, e)));
                ((e, t, n, o, i, s, l) => {
                    const a = (0, r.useRef)(!1);
                    (0, r.useEffect)((() => {
                        a.current = !!i
                    }), [i]), (0, r.useEffect)((() => {
                        let o;
                        if (!t && (l === u.DV || l === u.UW) && n && !a.current) {
                            const t = null == e ? void 0 : e.querySelectorAll(oe);
                            if (e && t)
                                if (t.length > 1) {
                                    const e = Array.from(t).find((e => "INPUT" === e.nodeName));
                                    null == e || e.focus()
                                } else if (t.length) {
                                var i;
                                null == (i = t[0]) || i.focus()
                            }
                            o = null == e ? void 0 : e.addEventListener("keydown", (t => {
                                if ("Tab" !== t.key && 9 !== t.keyCode) return;
                                const n = e.querySelectorAll(oe),
                                    o = null == n ? void 0 : n[0],
                                    i = null == n ? void 0 : n[n.length - 1];
                                o !== i && (t.shiftKey ? document.activeElement === o && (null == i || i.focus(), t.preventDefault()) : document.activeElement === i && (null == o || o.focus(), t.preventDefault()))
                            }))
                        }
                        return () => o ? null == e ? void 0 : e.removeEventListener("keydown", o) : void 0
                    }), [e, t, l, n, o, s])
                })(G.current, T, $e, !!F, L, Z, null == N ? void 0 : N.formType);
                let Te = Object.assign({
                    display: re,
                    zIndex: T ? 0 : S.B
                }, D ? {
                    opacity: 0
                } : {});
                if (de === I.Jq && T && (null == N ? void 0 : N.formType) !== u.Mk) Te = Object.assign({}, Te, {
                    position: "relative",
                    justifyContent: "center",
                    alignItems: (Fe = null == N ? void 0 : N.formType, Me = ue, Fe === u.nq && Me ? Me.startsWith("BOTTOM") ? "flex-end" : Me.startsWith("CENTER") ? "center" : "flex-start" : "center"),
                    backgroundColor: (null == N ? void 0 : N.formType) === u.nq ? (null == W ? void 0 : W.enabled) && (null == W ? void 0 : W.color) || "transparent" : z,
                    alignSelf: "center",
                    height: "100%",
                    width: "100%",
                    overflowY: "auto",
                    overflowX: "clip"
                });
                else if ((ce || (0, d.Z)()) && (null == N ? void 0 : N.formType) === u.Mk) {
                    var Ve, Ze;
                    Te = Object.assign({}, Te, {
                        width: "100%",
                        position: T || null == N || null == (Ve = N.data.bannerOptions) || !Ve.scrollWithPage ? "absolute" : "fixed",
                        overflow: T ? "initial" : "visible"
                    }, (null == N || null == (Ze = N.data) || null == (Ze = Ze.bannerOptions) ? void 0 : Ze.mobileBannerPosition) === u.ko ? {
                        top: 0
                    } : {
                        bottom: 0
                    })
                } else if ((null == N ? void 0 : N.formType) === u.nq) Te = Object.assign({}, Te, Object.assign({
                    maxHeight: T ? "100%" : 100 / ge + "%",
                    position: T ? "absolute" : "fixed",
                    transform: `scale(${ge})`,
                    transformOrigin: `${ue&&ue.endsWith("RIGHT")?"right":"left"} ${ue&&ue.startsWith("BOTTOM")?"bottom":"top"}`,
                    overflow: T ? "initial" : "visible"
                }, H({
                    formTypeDirection: ue,
                    modalScale: ge
                })));
                else if ((null == N ? void 0 : N.formType) === u.Mk) {
                    var _e, Oe;
                    Te = Object.assign({}, Te, {
                        width: "100%",
                        position: T || null == N || null == (_e = N.data.bannerOptions) || !_e.scrollWithPage ? "absolute" : "fixed"
                    }, (null == N || null == (Oe = N.data) || null == (Oe = Oe.bannerOptions) ? void 0 : Oe.desktopBannerPosition) === u.ko ? {
                        top: 0
                    } : {
                        bottom: 0
                    })
                } else Te = Object.assign({}, Te, {
                    position: T ? "initial" : "fixed",
                    left: 0,
                    top: 0,
                    width: "100%",
                    height: V ? "initial" : "100%",
                    justifyContent: "center",
                    alignItems: T ? "flex-start" : "center",
                    overflow: V ? "initial" : "auto",
                    backgroundColor: z,
                    overflowX: "clip"
                }, L ? Ee : ke);
                var Fe, Me;
                let Ae = {};
                de === I.Jq && T ? Ae = Object.assign({
                    position: "absolute",
                    transform: `scale(${ge})`,
                    transformOrigin: (null == N ? void 0 : N.formType) === u.nq && ue ? "" + (ue.startsWith("BOTTOM") ? "bottom" : "top") : "center",
                    maxHeight: 100 / ge + "%"
                }, (null == N ? void 0 : N.formType) !== u.nq || me || 1 !== ge ? {} : H({
                    formTypeDirection: ue,
                    modalScale: ge
                })) : (null == N ? void 0 : N.formType) !== u.DV && (null == N ? void 0 : N.formType) !== u.UW || (Ae = {
                    overflow: T ? "initial" : "visible",
                    transform: `scale(${ge})`,
                    transformOrigin: "center",
                    maxHeight: T ? "100%" : 100 / ge + "%"
                });
                const De = null == W ? void 0 : W.enabled,
                    Ne = (0, l.iv)(te || (te = ne `
    &&& {
      &::before {
        content: '';
        background-color: ${0};
        height: 100%;
        width: 100%;
        left: 0;
        top: 0;
        bottom: 0;
        right: 0;
        position: fixed;
        z-index: ${0};
        ${0};
        opacity: ${0};
      }
    }
  `), (null == W ? void 0 : W.color) || g.Z.theme.mobileOverlay.color, S.B, J ? "transition: opacity .5s ease;" : "", Y ? 1 - Y : 1),
                    Be = (0, r.useMemo)((() => T ? `${I.Pg}:${I.Pg}:${Z}` : void 0), [T, Z]);
                return (0, r.useEffect)((() => {
                    !_ || F || M ? se(!_ && F && A ? "none" : "flex") : (!T && L && (0, j.fK)({
                        id: e,
                        changes: {
                            modalIsClosing: !1,
                            modalWasDismissed: !0
                        }
                    }), se("none"))
                }), [_, F, M, L]), Re = (null == N ? void 0 : N.formType) === u.nq && (0, d.Z)() && (null == W ? void 0 : W.enabled) && "none" !== Te.display, je = s().createElement($.ZC, {
                    a11yIdentifier: Be,
                    ref: G,
                    role: "dialog",
                    "aria-modal": "true",
                    "aria-label": `${null==N?void 0:N.formType} Form`,
                    className: n || "",
                    style: Object.assign({}, Te, f ? {
                        position: "absolute",
                        transform: "scale(0.001)",
                        zIndex: 1
                    } : {})
                }, P ? s().createElement($.P, null, "Loading...") : s().createElement(Q, i()({
                    closePortal: t,
                    formVersionCId: e,
                    style: Ae,
                    designerFunctions: o,
                    designerInfo: m
                }, De ? {
                    setOverlayDismissalPercentage: (e, t = !1) => {
                        X(e), ie(t)
                    }
                } : {}, {
                    isA11y: f,
                    a11yViewId: p,
                    className: Se
                }))), T ? je : s().createElement($.ZC, {
                    style: Object.assign({}, f ? {
                        position: "absolute",
                        transform: "scale(0.001)",
                        zIndex: 1
                    } : {}),
                    a11yIdentifier: Be
                }, s().createElement($.ZC, {
                    a11yIdentifier: Be,
                    className: Ne,
                    style: De && Re ? Object.assign({}, L ? Ee : ke) : {
                        display: "none"
                    }
                }), je);
                var Re, je
            }
        },
        31274: function(e, t, n) {
            n.d(t, {
                n: function() {
                    return u
                }
            });
            var o = n(95775),
                i = n.n(o),
                r = n(87789),
                s = n.n(r),
                l = n(76223),
                a = n.n(l),
                d = n(78542);
            const c = ["a11yIdentifier"],
                m = a().lazy((() => n.e(4077).then(n.t.bind(n, 84420, 23)))),
                u = e => {
                    let {
                        a11yIdentifier: t
                    } = e, n = s()(e, c);
                    return a().createElement(l.Suspense, {
                        fallback: a().createElement("div", null)
                    }, a().createElement(m, i()({}, n, {
                        "data-a11y-identifier": t,
                        className: `needsclick ${n.className} ${d.Tc}`
                    })))
                }
        },
        39263: function(e, t, n) {
            n.d(t, {
                C3: function() {
                    return V
                },
                CI: function() {
                    return B
                },
                De: function() {
                    return Z
                },
                Dr: function() {
                    return M
                },
                Ei: function() {
                    return F
                },
                II: function() {
                    return D
                },
                P: function() {
                    return O
                },
                ZC: function() {
                    return $
                },
                __: function() {
                    return R
                },
                aG: function() {
                    return N
                },
                l0: function() {
                    return T
                },
                ny: function() {
                    return A
                },
                zx: function() {
                    return _
                }
            });
            var o = n(95775),
                i = n.n(o),
                r = n(87789),
                s = n.n(r),
                l = n(76223),
                a = n.n(l),
                d = n(12083),
                c = n.n(d),
                m = n(78542);
            n(56544);
            const u = ["a11yIdentifier"],
                f = ["a11yIdentifier"],
                p = ["a11yIdentifier"],
                h = ["a11yIdentifier"],
                v = ["a11yIdentifier"],
                y = ["a11yIdentifier"],
                g = ["a11yIdentifier"],
                I = ["a11yIdentifier"],
                b = ["a11yIdentifier"],
                S = ["a11yIdentifier"],
                w = ["a11yIdentifier"],
                x = ["tabIndex", "className", "alt", "a11yIdentifier"],
                C = ["tabIndex", "className", "style", "alt", "onClick", "a11yIdentifier", "aria-label", "children", "dndElProps"],
                E = ["a11yIdentifier"],
                k = ({
                    children: e
                }) => e,
                $ = a().forwardRef(((e, t) => {
                    let {
                        a11yIdentifier: n
                    } = e, o = s()(e, u);
                    return a().createElement("div", i()({
                        ref: t
                    }, o, {
                        "data-a11y-identifier": n,
                        className: `needsclick ${o.className||""} ${m.Tc}`
                    }))
                }));
            $.displayName = "Div";
            const T = a().forwardRef(((e, t) => {
                let {
                    a11yIdentifier: n
                } = e, o = s()(e, f);
                return a().createElement("form", i()({
                    ref: t
                }, o, {
                    "data-a11y-identifier": n,
                    className: `needsclick ${o.className||""} ${m.Tc}`
                }))
            }));
            T.displayName = "Form";
            const V = a().forwardRef(((e, t) => {
                let {
                    a11yIdentifier: n
                } = e, o = s()(e, p);
                return a().createElement("fieldset", i()({
                    ref: t
                }, o, {
                    "data-a11y-identifier": n,
                    className: `needsclick ${o.className||""} ${m.Tc}`
                }))
            }));
            V.displayName = "FieldSet";
            const Z = a().forwardRef(((e, t) => {
                let {
                    a11yIdentifier: n
                } = e, o = s()(e, h);
                return a().createElement("legend", i()({
                    ref: t
                }, o, {
                    "data-a11y-identifier": n,
                    className: `needsclick ${o.className||""} ${m.Tc}`
                }))
            }));
            Z.displayName = "Legend";
            const _ = a().forwardRef(((e, t) => {
                let {
                    a11yIdentifier: n
                } = e, o = s()(e, v);
                return a().createElement("button", i()({
                    ref: t
                }, o, {
                    "data-a11y-identifier": n,
                    className: `needsclick ${o.className||""} ${m.Tc}`
                }), o.children)
            }));
            _.displayName = "Button";
            const O = a().forwardRef(((e, t) => {
                let {
                    a11yIdentifier: n
                } = e, o = s()(e, y);
                return a().createElement("p", i()({
                    ref: t
                }, o, {
                    "data-a11y-identifier": n,
                    className: `needsclick ${o.className||""} ${m.Tc}`
                }))
            }));
            O.displayName = "P";
            a().forwardRef(((e, t) => {
                let {
                    a11yIdentifier: n
                } = e, o = s()(e, g);
                return a().createElement("a", i()({
                    ref: t
                }, o, {
                    "data-a11y-identifier": n,
                    className: `needsclick ${o.className||""} ${m.Tc}`
                }))
            })).displayName = "A";
            const F = a().forwardRef(((e, t) => {
                let {
                    a11yIdentifier: n
                } = e, o = s()(e, I);
                return a().createElement("img", i()({
                    ref: t
                }, o, {
                    "data-a11y-identifier": n,
                    className: `needsclick ${o.className||""} ${m.Tc}`
                }))
            }));
            F.displayName = "Img";
            const M = a().forwardRef(((e, t) => {
                let {
                    a11yIdentifier: n
                } = e, o = s()(e, b);
                return a().createElement("span", i()({
                    ref: t
                }, o, {
                    "data-a11y-identifier": n,
                    className: `needsclick ${o.className||""} ${m.Tc}`
                }))
            }));
            M.displayName = "Span";
            const A = a().forwardRef(((e, t) => {
                let {
                    a11yIdentifier: n
                } = e, o = s()(e, S);
                return a().createElement("svg", i()({
                    ref: t
                }, o, {
                    "data-a11y-identifier": n,
                    className: `needsclick ${o.className||""} ${m.Tc}`
                }))
            }));
            A.displayName = "Svg";
            const D = a().forwardRef(((e, t) => {
                let {
                    a11yIdentifier: n
                } = e, o = s()(e, w);
                return a().createElement("input", i()({
                    ref: t
                }, o, {
                    "data-a11y-identifier": n,
                    className: `needsclick ${o.className||""} ${m.Tc}`
                }))
            }));
            D.displayName = "Input";
            const N = e => {
                    let {
                        tabIndex: t,
                        className: n,
                        alt: o,
                        a11yIdentifier: r
                    } = e, l = s()(e, x);
                    return a().createElement(_, {
                        type: "button",
                        tabIndex: t,
                        className: n
                    }, a().createElement(F, i()({
                        alt: o
                    }, l, {
                        a11yIdentifier: r
                    })))
                },
                B = e => {
                    let {
                        tabIndex: t,
                        className: n,
                        style: o,
                        onClick: r,
                        a11yIdentifier: l,
                        "aria-label": d,
                        children: m,
                        dndElProps: u
                    } = e, f = s()(e, C);
                    return a().createElement(_, i()({
                        tabIndex: t,
                        className: c()(n, u.className),
                        style: o,
                        onClick: r,
                        "aria-label": d,
                        ref: u.ref
                    }, u.listeners, u.attributes), a().createElement(A, i()({
                        role: "img"
                    }, f, {
                        "data-a11y-identifier": l
                    }), l && m ? a().createElement(k, {
                        identifier: l
                    }, a().createElement(a().Fragment, null, m)) : m))
                },
                R = a().forwardRef(((e, t) => {
                    let {
                        a11yIdentifier: n
                    } = e, o = s()(e, E);
                    return a().createElement("label", i()({
                        ref: t
                    }, o, {
                        "data-a11y-identifier": n,
                        className: `needsclick ${o.className||""} ${m.Tc}`
                    }))
                }));
            R.displayName = "Label"
        },
        97506: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return W
                }
            });
            var o = n(95775),
                i = n.n(o),
                r = (n(92461), n(70818), n(39265), n(76223)),
                s = n.n(r),
                l = n(80101),
                a = n(94926),
                d = n(23034),
                c = n(60093),
                m = n(75186),
                u = n(39263),
                f = n(51301),
                p = n(50947),
                h = n(9247);
            var v = ({
                    formVersionCId: e,
                    designerInfo: t
                }) => {
                    const n = (0, m.Z)((t => {
                            var n, o;
                            const i = null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.formVersionId;
                            return i ? null == (o = t.formsState.formVersions[i]) ? void 0 : o.formType : void 0
                        })),
                        o = (0, m.Z)((t => {
                            var n, o;
                            const i = null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.formVersionId;
                            return i ? null == (o = t.formsState.formVersions[i]) ? void 0 : o.formTypeDirection : void 0
                        })),
                        i = (0, m.Z)((t => {
                            var n;
                            const o = null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.formVersionId;
                            return t.formsState.teasers && Object.values(t.formsState.teasers).filter((e => (null == e ? void 0 : e.formVersionId) === o))[0]
                        }), d.X),
                        a = (0, m.Z)((e => e.onsiteState.client.isDesignWorkflow)),
                        c = null == t ? void 0 : t.mobileDesktopType,
                        [v, y] = (0, r.useState)();
                    (0, r.useEffect)((() => {
                        y((0, l.Z)("modal_animation_key"))
                    }), [n, o, c]);
                    const g = f.c.TEXT,
                        I = (0, r.useMemo)((() => a ? `${h.KI}:${h.s4}:${null==i?void 0:i.teaserId}` : void 0), [a, null == i ? void 0 : i.teaserId]);
                    return v && i ? s().createElement(u.ZC, {
                        a11yIdentifier: I
                    }, s().createElement(r.Suspense, {
                        fallback: s().createElement(u.ZC, null)
                    }, s().createElement(g, {
                        itemId: i.teaserId,
                        parentType: p.p,
                        formVersionCId: e,
                        a11yIdentifierBlock: I
                    }))) : null
                },
                y = n(98889),
                g = n(70599),
                I = n(20077),
                b = n(78698),
                S = n(28391),
                w = n(8054);
            let x;
            const C = 16,
                E = {
                    [b.GE]: {
                        [S.MG]: {},
                        [S.DA]: {},
                        [S.pz]: {},
                        [S.pq]: {},
                        [S.j$]: {},
                        [S.kB]: {},
                        [S.qS]: {},
                        [S.tC]: {}
                    },
                    [b.uv]: {
                        [S.MG]: {},
                        [S.DA]: {},
                        [S.pz]: {},
                        [S.pq]: {},
                        [S.j$]: {},
                        [S.kB]: {},
                        [S.qS]: {},
                        [S.tC]: {}
                    },
                    [b.aR]: {
                        [S.MG]: {
                            clipPath: "polygon(100% 0, 0 100%, 0 0)"
                        },
                        [S.pz]: {
                            clipPath: "polygon(100% 100%, 0 0, 100% 0)"
                        },
                        [S.kB]: {
                            clipPath: "polygon(0 0, 0 100%, 100% 100%)"
                        },
                        [S.tC]: {
                            clipPath: "polygon(100% 100%, 0 100%, 100% 0)"
                        }
                    }
                },
                k = ({
                    type: e,
                    direction: t,
                    dismissButtonMargin: n
                }) => {
                    var o, i;
                    const r = null != (o = null == n ? void 0 : n.top) ? o : w.Z.dismissButtonStyles.margin.top,
                        s = -1 * r,
                        l = -1 * (null != (i = null == n ? void 0 : n.right) ? i : w.Z.dismissButtonStyles.margin.right);
                    return {
                        [b.GE]: {
                            [S.MG]: {
                                bottom: s,
                                right: l
                            },
                            [S.DA]: {
                                bottom: s,
                                right: l
                            },
                            [S.pz]: {
                                bottom: s,
                                left: l
                            },
                            [S.pq]: {
                                bottom: s,
                                right: l
                            },
                            [S.j$]: {
                                bottom: s,
                                right: l
                            },
                            [S.kB]: {
                                top: s,
                                right: l
                            },
                            [S.qS]: {
                                top: s,
                                right: l
                            },
                            [S.tC]: {
                                top: s,
                                left: l
                            }
                        },
                        [b.uv]: {
                            [S.MG]: {
                                bottom: s,
                                right: l
                            },
                            [S.DA]: {
                                bottom: s,
                                right: l
                            },
                            [S.pz]: {
                                bottom: s,
                                left: l
                            },
                            [S.pq]: {
                                top: s,
                                right: l
                            },
                            [S.j$]: {
                                top: s,
                                left: l
                            },
                            [S.kB]: {
                                top: s,
                                right: l
                            },
                            [S.qS]: {
                                top: s,
                                right: l
                            },
                            [S.tC]: {
                                top: s,
                                left: l
                            }
                        },
                        [b.aR]: {
                            [S.MG]: {
                                top: r,
                                right: l
                            },
                            [S.pz]: {
                                top: r,
                                left: l
                            },
                            [S.kB]: {
                                bottom: r,
                                right: l
                            },
                            [S.tC]: {
                                bottom: r,
                                left: l
                            }
                        }
                    }[e][t]
                },
                $ = ({
                    theme: e,
                    type: t,
                    direction: n
                }) => {
                    const o = Math.sqrt(e.size * e.size * 2) / 2,
                        i = Math.sqrt(e.size * e.size - o * o);
                    return {
                        [b.GE]: {
                            [S.DA]: {},
                            [S.pq]: {},
                            [S.j$]: {},
                            [S.qS]: {}
                        },
                        [b.uv]: {
                            [S.pq]: {},
                            [S.j$]: {}
                        },
                        [b.aR]: {
                            [S.MG]: {
                                width: Math.sqrt(e.size * e.size * 2),
                                transform: "rotate(-45deg)",
                                transformOrigin: "top left",
                                top: e.size / 2,
                                left: -1 * e.size / 2,
                                position: "relative",
                                height: i,
                                display: "flex",
                                flexDirection: "column-reverse",
                                alignItems: "center"
                            },
                            [S.pz]: {
                                width: Math.sqrt(e.size * e.size * 2),
                                transform: "rotate(45deg)",
                                transformOrigin: "top left",
                                top: -1 * e.size / 2,
                                left: e.size / 2,
                                position: "relative",
                                height: i,
                                display: "flex",
                                flexDirection: "column-reverse",
                                alignItems: "center"
                            },
                            [S.kB]: {
                                height: e.size - C,
                                width: Math.sqrt(e.size * e.size * 2),
                                transform: "rotate(45deg)",
                                transformOrigin: "top left"
                            },
                            [S.tC]: {
                                height: e.size - C,
                                width: Math.sqrt(e.size * e.size * 2),
                                position: "relative",
                                top: e.size,
                                left: 0,
                                transform: "rotate(-45deg)",
                                transformOrigin: "top left"
                            }
                        }
                    }[t][n] || {}
                },
                T = e => {
                    var t;
                    return Object.assign({
                        backgroundColor: e.backgroundColor
                    }, e.backgroundImage ? {
                        backgroundImage: e.backgroundImage && `url(${e.backgroundImage.url})`,
                        backgroundRepeat: "no-repeat",
                        backgroundSize: e.backgroundImage && ("custom" === e.backgroundImage.position ? `${e.backgroundImage.customWidth}px` : e.backgroundImage.position),
                        backgroundPositionX: e.backgroundImage && e.backgroundImage.alignment,
                        backgroundPositionY: (null == (t = e.backgroundImage) ? void 0 : t.verticalAlignment) || "center"
                    } : {})
                },
                V = (0, a.iv)(x || (x = (e => e)
                    `
  > div {
    padding-bottom: 8px;
    padding-top: 8px;
  }
`));
            var Z = n(87789),
                _ = n.n(Z),
                O = n(99946);
            const F = ["teaserType", "teaserDirection", "teaserDisplayOrder", "animatingOut", "endAnimationCallback", "formVersionCId", "style", "isA11y", "a11yTeaserId"],
                M = {
                    [b.GE]: {
                        CENTER_LEFT: "slideinup",
                        TOP: "slideinup",
                        BOTTOM: "slideindown",
                        CENTER_RIGHT: "slideinup"
                    },
                    [b.uv]: {
                        CENTER_LEFT: "slideinleft",
                        TOP: "slideinup",
                        BOTTOM: "slideindown",
                        CENTER_RIGHT: "slideinright"
                    },
                    [b.aR]: {
                        TOP_LEFT: "slideintopleft",
                        BOTTOM_LEFT: "slideinbottomleft",
                        TOP_RIGHT: "slideintopright",
                        BOTTOM_RIGHT: "slideinbottomright"
                    }
                },
                A = ({
                    teaserType: e,
                    teaserDirection: t,
                    animatingOut: n = !1,
                    isDesignWorkflow: o,
                    isFirstRender: i,
                    isA11y: r
                }) => {
                    const s = M[e],
                        l = s[Object.keys(s).find((e => t && t.startsWith(e)))];
                    let a = "0s",
                        d = "forwards";
                    return o ? a = "0.35s" : i && !n && (a = "2s", d = "both"), Object.assign({}, O.s, {
                        animationDelay: a,
                        animationFillMode: d,
                        animationDuration: ".4s",
                        animationName: `klaviyo-${l}`
                    }, n ? {
                        animationDirection: "reverse"
                    } : {
                        animationDirection: "normal"
                    }, r ? {
                        animationDelay: "0s",
                        animationDuration: "0s"
                    } : {})
                },
                D = e => {
                    let {
                        teaserType: t,
                        teaserDirection: n,
                        animatingOut: o = !1,
                        endAnimationCallback: l = (() => {}),
                        formVersionCId: a,
                        style: d = {},
                        isA11y: c,
                        a11yTeaserId: f
                    } = e, p = _()(e, F);
                    const [v, g] = (0, r.useState)(!1), I = (0, m.Z)((e => !!e.onsiteState.client.isDesignWorkflow)), b = (0, m.Z)((e => {
                        var t;
                        return null == (t = e.onsiteState.openFormVersions[a]) ? void 0 : t.teaserIsFirstRender
                    }));
                    (0, r.useEffect)((() => {
                        o && g(!1)
                    }), [o]);
                    const S = (0, r.useMemo)((() => I ? `${h.KI}:${h.s4}:${f}` : void 0), [I, f]);
                    return s().createElement(u.ZC, i()({
                        a11yIdentifier: S
                    }, p, {
                        onAnimationEnd: () => {
                            (0, y.fK)({
                                id: a,
                                changes: {
                                    teaserAnimationInProgress: !1
                                }
                            }), g(!0), l()
                        },
                        onAnimationStart: () => {
                            (0, y.ng)({
                                formVersionCId: a
                            }), o && (0, y.fK)({
                                id: a,
                                changes: {
                                    teaserAnimationInProgress: !0,
                                    formAnimationInProgress: !0
                                }
                            }), (0, y.fK)({
                                id: a,
                                changes: {
                                    hideTeaserBeforeAnimation: !1
                                }
                            })
                        },
                        style: Object.assign({
                            height: "100%",
                            width: "100%"
                        }, d, (!v || o) && A({
                            teaserType: t,
                            teaserDirection: n,
                            animatingOut: o,
                            isDesignWorkflow: I,
                            isFirstRender: !!b,
                            isA11y: c
                        }) || {})
                    }))
                };
            var N = n(89010),
                B = n(9615);
            var R = n(16958);
            let j, z = e => e;
            var W = ({
                formVersionCId: e,
                className: t,
                designerFunctions: n,
                designerInfo: o,
                isA11y: f = !1,
                a11yTeaserId: p
            }) => {
                var w, x, Z, _, O, F;
                const M = (0, m.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.closeModalWhenAnimationCompletes
                    })),
                    A = (0, m.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                    W = (0, m.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.formVersionId
                    })),
                    P = (0, m.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.formId
                    })),
                    L = (0, m.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.hideTeaserBeforeAnimation
                    })),
                    H = (0, m.Z)((t => {
                        var n;
                        return f && p ? p : null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.currentTeaserId
                    })),
                    q = (0, m.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.teaserAnimationInProgress
                    })),
                    U = (0, m.Z)((e => e.formsState.teasers && Object.values(e.formsState.teasers).filter((e => (null == e ? void 0 : e.formVersionId) === W))[0]), d.X),
                    K = (0, m.Z)((e => {
                        const t = Object.values(e.onsiteState.triggerGroups).find((e => (null == e ? void 0 : e.formVersionId) === W));
                        return t && void 0 !== t[g.w1] || !1
                    })),
                    G = (0, c.Z)() || (null == o ? void 0 : o.mobileDesktopType) === h.Jq,
                    Y = (0, r.useRef)(null),
                    [X, J] = (0, r.useState)(!1),
                    Q = (0, r.useMemo)((() => A ? `${h.KI}:${h.s4}:${null==U?void 0:U.teaserId}` : void 0), [A, null == U ? void 0 : U.teaserId]),
                    [ee, te] = (0, r.useState)(),
                    [ne, oe] = (0, r.useState)(!1),
                    ie = (0, r.useCallback)((() => {
                        ne && !A && (M || (0, y.$J)({
                            formVersionCId: e
                        }), oe(!1))
                    }), [ne]);
                if ((0, r.useEffect)((() => {
                        te((0, l.Z)("teaser_animation_key"))
                    }), [null == U ? void 0 : U.type, null == U ? void 0 : U.direction]), (0, r.useEffect)((() => {
                        U && H && X && !ne && !q && Y.current && (Y.current.focus(), J(!1))
                    }), [e, H, q, X, ne, U]), !U || !H && !q) return null;
                const re = null == (w = U.data) || null == (w = w.styling) || null == (w = w.dismissButtonStyles) ? void 0 : w.margin,
                    se = U.type === b.GE && ((null == (x = U.direction) ? void 0 : x.includes("TOP")) || (null == (Z = U.direction) ? void 0 : Z.includes("BOTTOM"))) && G,
                    le = (({
                        teaserStyling: e,
                        teaserType: t
                    }) => {
                        const n = b.ds[t];
                        return (0, N.Z)({}, Object.assign({}, B.al, {
                            size: n
                        }), e)
                    })({
                        teaserStyling: null == (_ = U.data) ? void 0 : _.styling,
                        teaserType: U.type
                    }),
                    ae = {
                        theme: le,
                        type: U.type,
                        direction: U.direction
                    },
                    de = Object.assign({
                        zIndex: A ? 0 : I.B
                    }, f ? {
                        transform: "scale(0.001)",
                        zIndex: 1
                    } : {}, {
                        position: A ? "absolute" : "fixed"
                    }, le.dropShadow.enabled ? {
                        filter: `drop-shadow(0px 0px ${le.dropShadow.blur}px ${le.dropShadow.color})`
                    } : {}, (({
                        theme: e,
                        type: t,
                        direction: n
                    }) => {
                        const o = e.margin.left,
                            i = e.margin.top;
                        return {
                            [b.GE]: {
                                [S.MG]: {
                                    top: 0,
                                    left: 0,
                                    margin: `${i}px ${o}px`
                                },
                                [S.DA]: {
                                    top: 0,
                                    left: "50%",
                                    transform: `translate(calc(-50% - ${o}px))`,
                                    margin: `${i}px ${o}px`
                                },
                                [S.pz]: {
                                    top: 0,
                                    right: 0,
                                    margin: `${i}px ${o}px`
                                },
                                [S.pq]: {
                                    top: "50%",
                                    left: 0,
                                    transform: "rotate(-90deg) translate(-50%, 0)",
                                    transformOrigin: "top left",
                                    marginLeft: `${i}px`
                                },
                                [S.j$]: {
                                    top: "50%",
                                    right: 0,
                                    transform: "rotate(90deg) translate(50%, 0)",
                                    transformOrigin: "top right",
                                    marginRight: `${i}px`
                                },
                                [S.kB]: {
                                    bottom: 0,
                                    left: 0,
                                    margin: `${i}px ${o}px`
                                },
                                [S.qS]: {
                                    bottom: 0,
                                    left: "50%",
                                    transform: `translate(calc(-50% - ${o}px))`,
                                    margin: `${i}px ${o}px`
                                },
                                [S.tC]: {
                                    bottom: 0,
                                    right: 0,
                                    margin: `${i}px ${o}px`
                                }
                            },
                            [b.uv]: {
                                [S.MG]: {
                                    top: 0,
                                    left: 0,
                                    margin: `${i}px ${o}px`
                                },
                                [S.DA]: {
                                    top: 0,
                                    left: "50%",
                                    transform: `translate(calc(-50% - ${o}px))`,
                                    margin: `${i}px ${o}px`
                                },
                                [S.pz]: {
                                    top: 0,
                                    right: 0,
                                    margin: `${i}px ${o}px`
                                },
                                [S.pq]: {
                                    left: 0,
                                    margin: `${i}px ${o}px`,
                                    top: `calc(50% - ${i}px)`,
                                    transform: "translateY(-50%)"
                                },
                                [S.j$]: {
                                    right: 0,
                                    margin: `${i}px ${o}px`,
                                    top: `calc(50% - ${i}px)`,
                                    transform: "translateY(-50%)"
                                },
                                [S.kB]: {
                                    bottom: 0,
                                    left: 0,
                                    margin: `${i}px ${o}px`
                                },
                                [S.qS]: {
                                    bottom: 0,
                                    left: "50%",
                                    transform: `translate(calc(-50% - ${o}px))`,
                                    margin: `${i}px ${o}px`
                                },
                                [S.tC]: {
                                    bottom: 0,
                                    right: 0,
                                    margin: `${i}px ${o}px`
                                }
                            },
                            [b.aR]: {
                                [S.MG]: {
                                    top: 0,
                                    left: 0,
                                    height: e.size,
                                    width: e.size,
                                    margin: `${i}px ${o}px`
                                },
                                [S.pz]: {
                                    top: 0,
                                    right: 0,
                                    height: e.size,
                                    width: e.size,
                                    margin: `${i}px ${o}px`
                                },
                                [S.kB]: {
                                    bottom: 0,
                                    left: 0,
                                    height: e.size,
                                    width: e.size,
                                    margin: `${i}px ${o}px`
                                },
                                [S.tC]: {
                                    bottom: 0,
                                    right: 0,
                                    height: e.size,
                                    width: e.size,
                                    margin: `${i}px ${o}px`
                                }
                            }
                        }[t][n]
                    })(ae), (({
                        theme: e,
                        type: t,
                        direction: n
                    }) => ({
                        [b.GE]: {
                            [S.MG]: {
                                width: e.size - C
                            },
                            [S.DA]: {
                                width: e.size - C
                            },
                            [S.pz]: {
                                width: e.size - C
                            },
                            [S.pq]: {
                                width: e.size - C
                            },
                            [S.j$]: {
                                width: e.size - C
                            },
                            [S.kB]: {
                                width: e.size - C
                            },
                            [S.qS]: {
                                width: e.size - C
                            },
                            [S.tC]: {
                                width: e.size - C
                            }
                        },
                        [b.uv]: {
                            [S.MG]: {
                                height: e.size - C,
                                width: e.size - C
                            },
                            [S.DA]: {
                                height: e.size - C,
                                width: e.size - C
                            },
                            [S.pz]: {
                                height: e.size - C,
                                width: e.size - C
                            },
                            [S.pq]: {
                                width: e.size - C,
                                height: e.size - C
                            },
                            [S.j$]: {
                                width: e.size - C,
                                height: e.size - C
                            },
                            [S.kB]: {
                                height: e.size - C,
                                width: e.size - C
                            },
                            [S.qS]: {
                                height: e.size - C,
                                width: e.size - C
                            },
                            [S.tC]: {
                                height: e.size - C,
                                width: e.size - C
                            }
                        },
                        [b.aR]: {
                            [S.MG]: {},
                            [S.pz]: {},
                            [S.kB]: {},
                            [S.tC]: {}
                        }
                    }[t][n] || {}))(ae), se ? {
                        width: `calc(100% - ${2*le.margin.left}px)`
                    } : {}, L && A ? {
                        opacity: 0
                    } : {}),
                    ce = Object.assign({
                        overflow: "hidden",
                        boxSizing: "border-box"
                    }, E[U.type][U.direction] || {}, ((e, t, n) => {
                        const o = {};
                        switch (t) {
                            case b.GE:
                                o.borderRadius = ((e, t) => {
                                    const n = e.margin.top,
                                        o = e.margin.left;
                                    let [i, r, s, l] = [e.borderRadius, e.borderRadius, e.borderRadius, e.borderRadius];
                                    return null != t && t.includes("BOTTOM") && 0 === n && (s = 0, l = 0), null != t && t.includes("TOP") && 0 === n && (r = 0, i = 0), null != t && t.includes("LEFT") && 0 === o && (i = 0, l = 0), null != t && t.includes("RIGHT") && 0 === o && (r = 0, s = 0), null != t && t.includes("CENTER") && null != t && t.includes("LEFT") && 0 === n && (i = 0, r = 0), null != t && t.includes("CENTER") && null != t && t.includes("RIGHT") && 0 === n && (i = 0, r = 0), `${i}px ${r}px ${s}px ${l}px`
                                })(e, n);
                                break;
                            case b.uv:
                                o.borderRadius = "50%"
                        }
                        return o
                    })(le, U.type, U.direction), U.type !== b.aR ? T(le) : {}, b.GE === U.type ? {
                        minHeight: 50,
                        height: "100%",
                        padding: 8
                    } : {}, b.uv === U.type ? {
                        height: "100%",
                        padding: 8
                    } : {
                        height: "100%"
                    }, U.type === b.aR ? {
                        display: "block"
                    } : {
                        display: "flex",
                        flexDirection: "column",
                        justifyContent: "center"
                    }),
                    me = (0, a.iv)(j || (j = z `
    cursor: pointer;
    * {
      cursor: pointer;
    }
  `));
                return s().createElement(u.ZC, i()({}, null != (O = U.data.content) && O.html ? {} : {
                    "aria-label": "Open Form"
                }, {
                    a11yIdentifier: Q,
                    ref: Y,
                    className: `kl-teaser-${P} ${t}`,
                    tabIndex: A ? -1 : 0,
                    style: de
                }, A ? {} : {
                    onClick: () => {
                        oe(!0), J(!0)
                    }
                }), s().createElement(D, {
                    key: ee,
                    teaserType: U.type,
                    teaserDirection: U.direction,
                    teaserDisplayOrder: U.displayOrder,
                    animatingOut: q && !H || ne,
                    endAnimationCallback: ie,
                    formVersionCId: e,
                    "data-testid": "animated-teaser",
                    isA11y: f,
                    a11yTeaserId: p
                }, s().createElement(u.Dr, {
                    a11yIdentifier: Q,
                    style: ce,
                    className: A ? "" : me
                }, s().createElement(u.ZC, {
                    a11yIdentifier: Q,
                    style: Object.assign({}, $(ae), U.type === b.aR ? T(le) : {}),
                    className: U.type === b.aR ? V : ""
                }, s().createElement(v, {
                    formVersionCId: e,
                    designerInfo: o
                }))), K && !q && s().createElement(R.Z, {
                    buttonStyling: null == (F = U.data) || null == (F = F.styling) ? void 0 : F.dismissButtonStyles,
                    title: "Close teaser",
                    onClick: () => {
                        (0, y.YW)({
                            formVersionCId: e
                        })
                    },
                    positionalStyles: k(Object.assign({}, ae, {
                        dismissButtonMargin: re
                    })),
                    isTeaser: !0,
                    designerFunctions: n,
                    designerInfo: o
                })))
            }
        },
        83485: function(e, t, n) {
            var o = n(76223),
                i = n.n(o),
                r = n(53896),
                s = n(39263);
            t.Z = ({
                errorViewMessage: e,
                isEmbed: t = !1,
                isFullscreen: n = !1
            }) => i().createElement(s.ZC, {
                role: "status",
                "aria-live": "polite",
                style: Object.assign({
                    height: 165,
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    background: "#ffffff"
                }, t ? {
                    width: "100%"
                } : Object.assign({}, n ? {
                    width: "100%",
                    overflow: "auto",
                    height: "fit-content",
                    minHeight: "100%"
                } : {
                    width: 450
                }))
            }, i().createElement(s.ZC, {
                style: {
                    textAlign: "center",
                    width: 300
                }
            }, e || r.xl))
        },
        22903: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return P
                }
            });
            n(19986), n(92461), n(70818), n(39265), n(44159), n(60873), n(83362);
            var o = n(76223),
                i = n.n(o),
                r = n(94926),
                s = n(23034),
                l = n(87974),
                a = n(62839),
                d = n(9247),
                c = n(18886),
                m = n(95775),
                u = n.n(m);
            const f = "top",
                p = "bottom";
            var h = n(12083),
                v = n.n(h),
                y = n(89010),
                g = n(87447),
                I = n(75186),
                b = n(51301),
                S = n(39263),
                w = n(62623),
                x = n(14988),
                C = n(51440),
                E = n(23759),
                k = n(32820);
            const $ = {
                    right: "0 0 0 auto",
                    left: "0 auto 0 0",
                    center: "0 auto"
                },
                T = ({
                    children: e
                }) => e,
                V = k.Z;

            function Z(...e) {
                return t => {
                    for (let n = 0; n < e.length; n += 1) {
                        const o = e[n];
                        o && ("function" == typeof o ? o(t) : "string" != typeof o && (o.current = t))
                    }
                }
            }
            var _ = ({
                componentId: e,
                componentPosition: t,
                formVersionCId: n,
                rowDroppableHover: r,
                setDragState: l,
                dragFinished: a,
                designerFunctions: c,
                designerInfo: m,
                isA11y: f = !1
            }) => {
                var p, h;
                const [k, _] = (0, o.useState)(!1), O = (0, o.useRef)(null), F = (0, I.Z)((t => t.formsState.components[e]), s.X), M = (0, I.Z)((e => !!e.onsiteState.client.isDesignWorkflow)), A = (0, I.Z)((e => !!e.onsiteState.client.isDesignWorkflow && !!e.onsiteState.client.isIAM)), D = (0, I.Z)((e => {
                    var t;
                    return null == (t = e.onsiteState.openFormVersions[n]) ? void 0 : t.currentViewId
                })), N = (0, I.Z)((t => D ? (0, E.su)(t, e, D) : {}), s.X), B = (0, I.Z)((e => D ? (0, C.l)(e, D) : {}), s.X), R = (0, I.Z)((t => {
                    var n, o;
                    const i = null == (n = t.formsState.components[e]) ? void 0 : n.actionId;
                    return t.formsState.actions && i ? null == (o = t.formsState.actions[i]) ? void 0 : o.actionType : void 0
                })), j = (0, o.useMemo)((() => M ? (null == m ? void 0 : m.mobileDesktopType) || d.q5 : (0, w.Z)()), [M, null == m ? void 0 : m.mobileDesktopType]), z = (null == m ? void 0 : m.activeComponentId) || (null == m ? void 0 : m.activeA11yComponentId), W = (0, o.useMemo)((() => {
                    var e;
                    return (0, y.Z)({}, B, N, {
                        [g.Z.THEME_KEY]: null == F || null == (e = F.data) ? void 0 : e.styling
                    })
                }), [B, N, null == F || null == (p = F.data) ? void 0 : p.styling]), P = (0, o.useMemo)((() => M ? `${d.f2}:${d.j1}:${e}` : void 0), [e, M]), L = (0, o.useMemo)((() => M ? `${d.f2}:${d.Pg}:${e}` : void 0), [e, M]), H = (0, o.useMemo)((() => {
                    if (!F) return null;
                    const t = b.c[F.componentType];
                    return t ? i().createElement(t, {
                        theme: W,
                        componentId: e,
                        formVersionCId: n,
                        itemId: e,
                        a11yIdentifierBlock: P,
                        a11yIdentifierStyles: L
                    }) : null
                }), [P, L, F, e, n, W]);
                if (null != F && null != (h = F.data) && null != (h = h.styling) && h.hidden) return null;
                const q = z === e,
                    U = Object.assign({
                        component: F
                    }, M && !A ? {
                        onClick: () => {
                            null == c || c.setActiveSidebar({
                                type: d.NV,
                                key: e
                            })
                        },
                        onMouseOver: () => {
                            a ? l(!1) : _(!0)
                        },
                        onMouseLeave: () => _(!1),
                        onDragStart: () => _(!1),
                        onDragEnd: () => {
                            l(!0)
                        },
                        ref: O
                    } : {}),
                    K = (0, x.C)(F, j, R);
                return F && K ? i().createElement(V, {
                    isIAMEditor: A,
                    componentId: e
                }, (({
                    ref: o,
                    attributes: s,
                    listeners: l,
                    className: a
                }) => {
                    var d, p, h, y;
                    return i().createElement(S.ZC, u()({
                        a11yIdentifier: P,
                        style: Object.assign({
                            display: "flex",
                            justifyContent: "flex-start",
                            padding: `${W[g.Z.THEME_KEY].padding.top||0}px ${W[g.Z.THEME_KEY].padding.right||0}px ${W[g.Z.THEME_KEY].padding.bottom||0}px ${W[g.Z.THEME_KEY].padding.left||0}px`,
                            position: "relative"
                        }, W[g.Z.THEME_KEY].blockBackgroundColor ? {
                            backgroundColor: W[g.Z.THEME_KEY].blockBackgroundColor
                        } : {}, k ? {
                            cursor: "pointer"
                        } : {}, {
                            flex: !1 !== (null == F || null == (d = F.data) || null == (d = d.styling) ? void 0 : d.fullWidth) ? "1 0 0" : "0 1 auto"
                        }, !1 === (null == F || null == (p = F.data) || null == (p = p.styling) ? void 0 : p.fullWidth) && {
                            margin: $[null != (h = null == F || null == (y = F.data) ? void 0 : y.styling.alignment) ? h : "center"]
                        })
                    }, U, {
                        ref: Z(o, O)
                    }, s, l, {
                        "data-testid": "form-component",
                        className: v()({
                            notranslate: !1
                        }, a)
                    }), M && c && m && !f ? i().createElement(T, {
                        theme: W,
                        active: q,
                        componentId: e,
                        componentPosition: t,
                        componentRef: O.current,
                        formVersionCId: n,
                        isHovering: k,
                        rowDroppableHover: r,
                        setIsHovering: _,
                        designerFunctions: c,
                        designerInfo: m
                    }, H) : H)
                })) : null
            };
            var O = ({
                rowId: e,
                formVersionCId: t,
                designerFunctions: n,
                designerInfo: r,
                isA11y: l
            }) => {
                const a = (0, I.Z)((t => {
                        var n;
                        return (null == (n = t.formsState.rows[e]) ? void 0 : n.components) || []
                    }), s.X),
                    c = (0, I.Z)((e => e.onsiteState.client.isDesignWorkflow)),
                    [m, u] = (0, o.useState)(!1),
                    [h, v] = (0, o.useState)(!1),
                    [y, g] = (0, o.useState)(!1),
                    b = (m ? f : h && p) || !1,
                    w = (0, o.useMemo)((() => c ? `${d.Vs}:${d.ij}:${e}` : void 0), [c, e]);
                return a.length ? i().createElement(S.ZC, {
                    a11yIdentifier: w,
                    "data-testid": "form-row",
                    style: Object.assign({
                        display: "flex",
                        flexDirection: "row",
                        alignItems: "stretch",
                        position: "relative"
                    }, b ? Object.assign({}, "bottom" === b ? {
                        borderBottom: "2px",
                        borderBottomStyle: "solid",
                        borderBottomColor: "#2B98D3",
                        marginBottom: "-2px"
                    } : {
                        borderTop: "2px",
                        borderTopStyle: "solid",
                        borderTopColor: "#2B98D3",
                        marginTop: "-2px"
                    }) : {})
                }, a.map(((e, o) => i().createElement(_, {
                    key: e,
                    componentId: e,
                    componentPosition: o,
                    formVersionCId: t,
                    rowDroppableHover: (e, t) => {
                        e === f ? u(t) : v(t)
                    },
                    setDragState: e => g(e),
                    dragFinished: y,
                    designerFunctions: n,
                    designerInfo: r,
                    isA11y: l
                }))), null) : null
            };
            const F = ({
                    children: e
                }) => e,
                M = {
                    .5: "35%",
                    1: "50%",
                    2: "65%"
                };
            var A = ({
                    columnId: e,
                    formVersionCId: t,
                    formVersionId: n,
                    viewId: r,
                    sideImageExistsAndHidden: l,
                    isFullscreen: a,
                    designerFunctions: c,
                    designerInfo: m,
                    isA11y: f
                }) => {
                    var p, h, v, y, g;
                    const b = (0, o.useRef)(null),
                        [w, E] = (0, o.useState)(!1),
                        k = (0, I.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                        $ = (0, I.Z)((e => {
                            var t;
                            return null == (t = e.formsState.formVersions[n]) || null == (t = t.data) ? void 0 : t.sideImage
                        }), s.X),
                        T = (0, I.Z)((t => {
                            var n;
                            return (null == (n = t.formsState.columns[e]) ? void 0 : n.rows) || []
                        }), s.X),
                        V = (0, I.Z)((t => t.formsState.columns[e]), s.X),
                        Z = (0, I.Z)((e => (0, C.l)(e, r)), s.X),
                        _ = (0, o.useMemo)((() => k ? `${d.PF}:${d.k_}:${e}` : void 0), [k, e]);
                    if (!V) return null;
                    const A = null == m ? void 0 : m.activeColumnId,
                        {
                            padding: D,
                            minimumHeight: N
                        } = Z,
                        B = void 0 !== (null == (p = V.data) || null == (p = p.styling) ? void 0 : p.sizeMultiplier) && 0 === V.rows.length,
                        {
                            columnMargin: R,
                            columnPadding: j
                        } = ((e, t, n, o) => {
                            const i = {
                                    top: 0,
                                    left: 0,
                                    right: 0,
                                    bottom: 0
                                },
                                r = {
                                    top: 0,
                                    left: 0,
                                    right: 0,
                                    bottom: 0
                                };
                            return o || void 0 !== n && (e ? (i.top = t && t.top ? -1 * t.top : 0, i.bottom = t && t.bottom ? -1 * t.bottom : 0, 0 === n ? i.left = t && t.left ? -1 * t.left : 0 : 1 === n && (i.right = t && t.right ? -1 * t.right : 0)) : 0 === n ? r.left = (null == t ? void 0 : t.left) || 0 : 1 === n && (r.right = (null == t ? void 0 : t.right) || 0)), {
                                columnMargin: i,
                                columnPadding: r
                            }
                        })(B, D, null == $ ? void 0 : $.position, l),
                        z = null == (h = V.data) || null == (h = h.styling) ? void 0 : h.sizeMultiplier,
                        W = null == Z ? void 0 : Z.size,
                        P = z && W ? ((e, t, n) => {
                            const o = e / (e + 1) * t;
                            return n ? o : t - o
                        })(z, W, B) : 0,
                        L = A === V.columnId,
                        H = (null == Z ? void 0 : Z.borderStyle) && "none" !== (null == Z ? void 0 : Z.borderStyle) && (null == Z ? void 0 : Z.borderWidth) || 0,
                        q = null == (v = V.data) || null == (v = v.styling) ? void 0 : v.backgroundImage,
                        U = null == (y = V.data) || null == (y = y.styling) ? void 0 : y.backgroundColor,
                        K = Object.assign({}, k && B ? {
                            onClick: () => {
                                c && c.setActiveSidebar({
                                    type: d.aC,
                                    key: e
                                })
                            },
                            onMouseOver: () => {
                                E(!0)
                            },
                            onMouseLeave: () => E(!1),
                            ref: b
                        } : {}),
                        G = null == m ? void 0 : m.mobileDesktopType,
                        Y = (null == (g = V.rows) ? void 0 : g.length) > 0 || $ && (0, x.V)($, k, G || d.q5, V),
                        X = B ? Object.assign({
                            borderColor: "transparent",
                            borderStyle: "solid",
                            borderWidth: Z.borderWidth
                        }, 1 === (null == $ ? void 0 : $.position) ? {
                            borderBottomRightRadius: Z.borderRadius,
                            borderTopRightRadius: Z.borderRadius,
                            marginRight: R.right - Z.borderWidth,
                            borderLeft: 0
                        } : {
                            borderBottomLeftRadius: Z.borderRadius,
                            borderTopLeftRadius: Z.borderRadius,
                            marginLeft: R.left - Z.borderWidth,
                            borderRight: 0
                        }, {
                            marginBottom: R.bottom - Z.borderWidth,
                            marginTop: R.top - Z.borderWidth,
                            overflow: "hidden"
                        }) : {},
                        J = e => {
                            switch (e) {
                                case "center":
                                    return "center";
                                case "left":
                                case "top":
                                    return "start";
                                case "right":
                                case "bottom":
                                    return "end";
                                default:
                                    return
                            }
                        },
                        Q = e => {
                            switch (e) {
                                case "center":
                                    return "50%";
                                case "right":
                                case "top":
                                    return "0";
                                default:
                                    return
                            }
                        };
                    return Y ? i().createElement(S.ZC, u()({
                        a11yIdentifier: _,
                        title: B || null == q ? void 0 : q.altText,
                        style: Object.assign({
                            display: "flex",
                            flexDirection: "column",
                            width: P ? `${P}px` : "100%",
                            marginTop: `${R.top}px`,
                            marginBottom: `${R.bottom}px`,
                            marginLeft: `${R.left}px`,
                            marginRight: `${R.right}px`,
                            paddingTop: `${j.top}px`,
                            paddingBottom: `${j.bottom}px`,
                            paddingLeft: `${j.left}px`,
                            paddingRight: `${j.right}px`
                        }, X, {
                            backgroundColor: U
                        }, w && {
                            cursor: "pointer"
                        }, P && {
                            minWidth: `${P}px`
                        }, void 0 !== N && !a && {
                            minHeight: `${N}px`
                        }, !B && {
                            justifyContent: "center"
                        }, a && !B && {
                            margin: "0 auto",
                            minWidth: "100px",
                            maxWidth: `${W}px`,
                            width: `${W}px`
                        }, a && z && {
                            position: "relative",
                            maxWidth: M[z],
                            width: "100%"
                        })
                    }, K), B && q && i().createElement(S.ZC, {
                        a11yIdentifier: _,
                        style: Object.assign({
                            width: "100%",
                            height: "100%",
                            position: "relative"
                        }, "custom" === (null == q ? void 0 : q.position) && (null == q ? void 0 : q.customWidth) < P && {
                            display: "flex",
                            justifyContent: J(null == q ? void 0 : q.alignment) || "center",
                            alignItems: J(null == q ? void 0 : q.verticalAlignment) || "center"
                        })
                    }, i().createElement(S.Ei, {
                        src: null == q ? void 0 : q.url,
                        alt: null == q ? void 0 : q.altText,
                        style: q && Object.assign({}, "custom" === (null == q ? void 0 : q.position) ? Object.assign({
                            width: `${null==q?void 0:q.customWidth}px`,
                            height: "auto"
                        }, (null == q ? void 0 : q.customWidth) > P && {
                            position: "absolute",
                            left: "left" === (null == q ? void 0 : q.alignment) ? 0 : void 0,
                            right: Q(null == q ? void 0 : q.alignment),
                            top: Q(null == q ? void 0 : q.verticalAlignment),
                            bottom: "bottom" === (null == q ? void 0 : q.verticalAlignment) ? 0 : void 0,
                            transform: `translate(${"center"===(null==q?void 0:q.alignment)?"50%":0}, ${"center"===(null==q?void 0:q.verticalAlignment)?"-50%":0})`
                        }) : {
                            width: "100%",
                            height: "100%",
                            objectFit: null == q ? void 0 : q.position,
                            objectPosition: `${(null==q?void 0:q.alignment)||"center"} ${(null==q?void 0:q.verticalAlignment)||"center"}`
                        })
                    })), i().createElement(F, {
                        backgroundColorExists: !!U,
                        backgroundImageExists: !!q,
                        calculatedWidth: P,
                        column: V,
                        isDesignWorkflow: k,
                        isHovering: w,
                        isSelected: L,
                        isSideImageColumn: B,
                        viewBorderWidth: H,
                        viewSize: W,
                        isFullscreen: a
                    }, null == T ? void 0 : T.map((e => i().createElement(O, {
                        key: e,
                        rowId: e,
                        formVersionCId: t,
                        designerFunctions: c,
                        designerInfo: m,
                        isA11y: f
                    }))))) : null
                },
                D = n(64954),
                N = n(28391);
            let B, R = e => e;
            const j = {
                    left: {
                        float: "left"
                    },
                    center: {
                        margin: "0 auto"
                    },
                    right: {
                        float: "right"
                    }
                },
                z = (e, t, n) => t ? null != n && n.includes("BOTTOM") ? `${e}px ${e}px 0 0` : `0 0 ${e}px ${e}px` : `${e}px`;
            var W = ({
                    viewId: e,
                    isEmbed: t,
                    formVersionId: n,
                    formVersionCId: m,
                    isDocked: u,
                    formTypeDirection: f,
                    designerFunctions: p,
                    designerInfo: h,
                    isA11y: v
                }) => {
                    var y, g;
                    const b = (0, I.Z)((e => {
                            var t;
                            return null == (t = e.formsState.formVersions[n]) ? void 0 : t.formId
                        })),
                        w = (0, I.Z)((e => {
                            var t;
                            return null == (t = e.formsState.formVersions[n]) ? void 0 : t.formType
                        })),
                        E = (0, I.Z)((t => t.formsState.views[e] ? Object.values(t.formsState.columns).filter((e => !!e)).filter((n => {
                            var o;
                            return null == (o = t.formsState.views[e]) ? void 0 : o.columns.includes(n.columnId)
                        })).sort(((e, t) => e.position - t.position)) : []), s.X),
                        k = (0, I.Z)((e => {
                            const t = E.reduce(((e, t) => (t.rows.forEach((t => {
                                e.push(t)
                            })), e)), []).reduce(((t, n) => {
                                var o;
                                return null == (o = e.formsState.rows[n]) || o.components.forEach((e => {
                                    t.push(e)
                                })), t
                            }), []).map((t => e.formsState.components[t]));
                            return Object.values(e.formsState.actions || {}).filter((e => !!e && t.find((t => (null == t ? void 0 : t.actionId) === e.actionId && a.Fz.has(e.actionType)))))
                        }), s.X),
                        $ = (0, I.Z)((t => (0, C.l)(t, e)), s.X),
                        T = (0, I.Z)((e => {
                            var t;
                            return null == (t = e.formsState.formVersions[n]) || null == (t = t.data) ? void 0 : t.sideImage
                        }), s.X),
                        V = (0, I.Z)((t => Object.values(t.formsState.columns).filter((t => (null == t ? void 0 : t.viewId) === e)).find((e => (null == e ? void 0 : e.position) === (null == T ? void 0 : T.position))))),
                        Z = null == T || null == (y = T.data) || null == (y = y.styling) ? void 0 : y.sizeMultiplier,
                        _ = Z ? (0, D.Z)(Z, $.size) : 0,
                        O = (0, I.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                        F = null == h ? void 0 : h.mobileDesktopType,
                        M = T && !(0, x.V)(T, O, F || d.q5, V),
                        W = $.isReflow,
                        P = M ? $.size - _ : void 0,
                        L = (0, o.useMemo)((() => O ? `${d.Sq}:${d.Pg}:${e}` : void 0), [O, e]),
                        H = w === N.DV && W ? {
                            minWidth: `${c.Gg}px`,
                            maxWidth: `${P||$.size}px`
                        } : {
                            width: `${P||$.size}px`,
                            minWidth: `${c.Gg}px`,
                            maxWidth: `${c.Ez}px`
                        };
                    return i().createElement(S.l0, {
                        a11yIdentifier: L,
                        "aria-live": "polite",
                        style: Object.assign({
                            display: "flex",
                            flexDirection: "row",
                            boxSizing: "border-box"
                        }, t ? Object.assign({
                            width: "100%",
                            overflow: "visible"
                        }, $.isMaxWidth ? {
                            maxWidth: `${$.size}px`
                        } : {}, $.embedAlignment ? j[$.embedAlignment] : {}) : Object.assign({}, w !== N.UW && w !== N.Mk ? H : {
                            overflow: "auto",
                            height: "fit-content",
                            minHeight: "100%"
                        }), {
                            borderRadius: `${z($.borderRadius,u,f)}`,
                            borderStyle: $.borderStyle,
                            borderWidth: `${$.borderWidth||0}px`,
                            borderColor: $.borderColor,
                            backgroundColor: $.backgroundColor,
                            backgroundImage: $.backgroundImage ? `url(${$.backgroundImage.url})` : void 0,
                            backgroundRepeat: "no-repeat",
                            backgroundSize: $.backgroundImage && ("custom" === $.backgroundImage.position ? `${$.backgroundImage.customWidth}px` : $.backgroundImage.position) || void 0,
                            backgroundPositionX: $.backgroundImage ? $.backgroundImage.alignment : void 0,
                            backgroundPositionY: (null == (g = $.backgroundImage) ? void 0 : g.verticalAlignment) || "center",
                            paddingTop: `${$.padding.top}px`,
                            paddingRight: `${$.padding.right}px`,
                            paddingBottom: `${$.padding.bottom}px`,
                            paddingLeft: `${$.padding.left}px`,
                            flex: 1
                        }),
                        className: `klaviyo-form klaviyo-form-version-cid_${m} ${(0,r.iv)(B||(B=R`
        &&& {
          [href]:focus-visible {
            outline-width: 2px;
            outline-style: auto;
            outline-color: ${0};
          }
        }
      `),$.focusColor)}`,
                        "data-testid": `klaviyo-form-${b}`,
                        noValidate: !0,
                        onSubmit: async e => {
                            if (e.preventDefault(), 1 !== k.length) return !1;
                            const t = k[0];
                            if (!t) return !1;
                            const {
                                actionId: n
                            } = t, o = (0, l.j)({
                                actionId: n,
                                formVersionCId: m
                            });
                            return await new o({
                                actionId: n,
                                formVersionCId: m
                            }).runAction(), !0
                        }
                    }, E.map((t => i().createElement(A, {
                        key: t.columnId,
                        columnId: t.columnId,
                        formVersionCId: m,
                        formVersionId: n,
                        viewId: e,
                        sideImageExistsAndHidden: M,
                        isFullscreen: w === N.UW,
                        designerFunctions: p,
                        designerInfo: h,
                        isA11y: v
                    }))), i().createElement("input", {
                        style: {
                            display: "none"
                        },
                        type: "submit",
                        tabIndex: -1,
                        value: "Submit"
                    }))
                },
                P = W
        },
        68350: function(e, t, n) {
            n.r(t), n.d(t, {
                default: function() {
                    return q
                }
            });
            var o = n(76223),
                i = n.n(o),
                r = n(14324),
                s = n(94926),
                l = n(95775),
                a = n.n(l),
                d = (n(92461), n(70818), n(60873), n(23034)),
                c = n(67453);
            var m = n(19416).Z,
                u = n(75186),
                f = n(98889);
            var p, h, v, y, g, I, b = n(97506).Z;

            function S() {
                return S = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var o in n)({}).hasOwnProperty.call(n, o) && (e[o] = n[o])
                    }
                    return e
                }, S.apply(null, arguments)
            }
            var w, x = function(e) {
                return o.createElement("svg", S({
                    width: 167,
                    height: 182,
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), p || (p = o.createElement("path", {
                    d: "M103.52 3.036C88.562 8.51 70.961 5.635 61.51 2.751c-1.859-.567-3.876-.444-5.586.478L5.884 30.212a6.744 6.744 0 0 0-3.122 8.281l7.907 21.32a6.744 6.744 0 0 0 6.323 4.4H27.06a6.744 6.744 0 0 1 6.744 6.743v96.876c0 2.882 1.827 5.464 4.59 6.286 34.048 10.129 71.284 4.898 89.945-.094 2.833-.757 4.708-3.363 4.708-6.294V70.956a6.744 6.744 0 0 1 6.744-6.744h10.067a6.744 6.744 0 0 0 6.323-4.398l7.884-21.256a6.743 6.743 0 0 0-3.192-8.317L109.514 3.316c-1.849-.97-4.033-.997-5.994-.28Z",
                    fill: "#E9E9E9"
                })), h || (h = o.createElement("path", {
                    d: "M55.124 1.746C57.272.587 59.76.456 62 1.139c9.305 2.839 26.483 5.603 40.94.315 2.339-.856 5.025-.853 7.356.369l51.359 26.925a8.429 8.429 0 0 1 3.989 10.397l-7.883 21.256a8.43 8.43 0 0 1-7.904 5.498h-10.067a5.058 5.058 0 0 0-5.058 5.058v96.773c0 3.644-2.34 6.956-5.958 7.923-18.824 5.035-56.403 10.333-90.862.081-3.515-1.046-5.795-4.314-5.795-7.902V70.957a5.058 5.058 0 0 0-5.058-5.058H16.992A8.43 8.43 0 0 1 9.089 60.4L1.18 39.08a8.43 8.43 0 0 1 3.902-10.351l50.04-26.983Zm5.893 2.618c-1.476-.45-3.022-.336-4.293.35L6.684 31.697a5.058 5.058 0 0 0-2.342 6.21l7.908 21.321a5.058 5.058 0 0 0 4.742 3.299H27.06a8.43 8.43 0 0 1 8.43 8.43v96.875c0 2.177 1.375 4.072 3.385 4.67 33.637 10.007 70.53 4.842 89.029-.106 2.046-.547 3.457-2.446 3.457-4.666V70.957a8.43 8.43 0 0 1 8.43-8.43h10.067a5.057 5.057 0 0 0 4.742-3.299l7.884-21.255a5.057 5.057 0 0 0-2.394-6.239L108.731 4.81c-1.368-.717-3.049-.768-4.632-.189-15.46 5.656-33.483 2.673-43.082-.256Z",
                    fill: "#FEFEFE"
                })), v || (v = o.createElement("path", {
                    d: "m47.798 7.494 8.058-3.172c27.568 8.906 44.674 2.115 52.591 0l9.33 3.172c-29.264 13.368-58.104 5.287-69.979 0ZM140.68 65.395l14.723-38.17 9.452 6.362-11.451 30.536-12.724 1.272ZM26.169 65.395l-13.572-38.17L.72 33.863l10.18 28.988 15.268 2.544Z",
                    fill: "#D5D5D6"
                })), y || (y = o.createElement("path", {
                    d: "M55.124 1.746C57.272.587 59.76.456 62 1.139c9.305 2.839 26.483 5.603 40.94.315 2.339-.856 5.025-.853 7.356.369l51.359 26.925a8.429 8.429 0 0 1 3.989 10.397l-7.883 21.256a8.43 8.43 0 0 1-7.904 5.498h-10.067a5.058 5.058 0 0 0-5.058 5.058v96.773c0 3.644-2.34 6.956-5.958 7.923-18.824 5.035-56.403 10.333-90.862.081-3.515-1.046-5.795-4.314-5.795-7.902V70.957a5.058 5.058 0 0 0-5.058-5.058H16.992A8.43 8.43 0 0 1 9.089 60.4L1.18 39.08a8.43 8.43 0 0 1 3.902-10.351l50.04-26.983Zm5.893 2.618c-1.476-.45-3.022-.336-4.293.35L6.684 31.697a5.058 5.058 0 0 0-2.342 6.21l7.908 21.321a5.058 5.058 0 0 0 4.742 3.299H27.06a8.43 8.43 0 0 1 8.43 8.43v96.875c0 2.177 1.375 4.072 3.385 4.67 33.637 10.007 70.53 4.842 89.029-.106 2.046-.547 3.457-2.446 3.457-4.666V70.957a8.43 8.43 0 0 1 8.43-8.43h10.067a5.057 5.057 0 0 0 4.742-3.299l7.884-21.255a5.057 5.057 0 0 0-2.394-6.239L108.731 4.81c-1.368-.717-3.049-.768-4.632-.189-15.46 5.656-33.483 2.673-43.082-.256Z",
                    fill: "#DEE2E4"
                })), g || (g = o.createElement("path", {
                    d: "M112.689 76.847c0 16.162-13.102 29.264-29.264 29.264-16.163 0-29.265-13.102-29.265-29.264s13.102-29.264 29.264-29.264c16.163 0 29.265 13.102 29.265 29.264Z",
                    fill: "#D5D5D6"
                })), I || (I = o.createElement("path", {
                    d: "M82.195 59.008c.388-1.193 2.075-1.193 2.463 0l3.334 10.261c.173.534.67.895 1.231.895h10.79c1.254 0 1.776 1.605.761 2.342l-8.729 6.342c-.454.33-.644.914-.47 1.448l3.334 10.26c.387 1.194-.978 2.186-1.993 1.448l-8.728-6.341a1.295 1.295 0 0 0-1.523 0l-8.728 6.341c-1.015.738-2.38-.254-1.993-1.447l3.334-10.261a1.295 1.295 0 0 0-.47-1.448l-8.729-6.342c-1.015-.737-.493-2.342.761-2.342h10.79c.56 0 1.058-.361 1.231-.895l3.334-10.261Z",
                    fill: "#FEFEFE"
                })))
            };

            function C() {
                return C = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var o in n)({}).hasOwnProperty.call(n, o) && (e[o] = n[o])
                    }
                    return e
                }, C.apply(null, arguments)
            }
            var E, k = function(e) {
                return o.createElement("svg", C({
                    xmlns: "http://www.w3.org/2000/svg",
                    fill: "none",
                    viewBox: "0 0 24 24"
                }, e), w || (w = o.createElement("path", {
                    fill: "currentColor",
                    fillRule: "evenodd",
                    d: "M11 3a8 8 0 1 0 4.906 14.32l3.887 3.887 1.414-1.414-3.887-3.887A8 8 0 0 0 11 3Zm-6 8a6 6 0 1 1 12 0 6 6 0 0 1-12 0Z",
                    clipRule: "evenodd"
                })))
            };

            function $() {
                return $ = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var o in n)({}).hasOwnProperty.call(n, o) && (e[o] = n[o])
                    }
                    return e
                }, $.apply(null, arguments)
            }
            var T = function(e) {
                    return o.createElement("svg", $({
                        xmlns: "http://www.w3.org/2000/svg",
                        fill: "none",
                        viewBox: "0 0 24 24"
                    }, e), E || (E = o.createElement("path", {
                        fill: "currentColor",
                        fillRule: "evenodd",
                        d: "M2.5 3a1 1 0 0 1 1-1h3.28l.5 2h10.334c2.095 0 3.544 2.092 2.809 4.053L18.193 14H7.118l-.276.553A1 1 0 0 0 7.736 16H18.5a3 3 0 1 1-2.83 2h-5.34a3 3 0 1 1-4.94-1.131 2.984 2.984 0 0 1-.337-3.21L5.882 12h1.337l-2-8H3.5a1 1 0 0 1-1-1Zm16 15a1 1 0 1 0 0 2 1 1 0 0 0 0-2ZM7.78 6l1.5 6h7.527l1.743-4.649A1 1 0 0 0 17.614 6H7.781ZM6.5 19a1 1 0 1 1 2 0 1 1 0 0 1-2 0Z",
                        clipRule: "evenodd"
                    })))
                },
                V = n(39263);
            let Z, _, O = e => e;
            var F = ({
                dynamicButtonId: e,
                a11yIdentifierBlock: t
            }) => {
                const n = (0, u.Z)((t => {
                        var n;
                        return t.formsState.dynamicButtons && (null == (n = t.formsState.dynamicButtons[e]) || null == (n = n.data) ? void 0 : n.label)
                    })),
                    r = (0, u.Z)((t => {
                        var n;
                        return t.formsState.dynamicButtons && (null == (n = t.formsState.dynamicButtons[e]) || null == (n = n.data) ? void 0 : n.textStyles)
                    })),
                    l = (0, u.Z)((t => {
                        var n;
                        return t.formsState.dynamicButtons && (null == (n = t.formsState.dynamicButtons[e]) || null == (n = n.data) ? void 0 : n.buttonStyles)
                    })),
                    a = (0, o.useMemo)((() => null != l && l.alignment ? "left" === (null == l ? void 0 : l.alignment) ? "0 auto 0 0" : "right" === (null == l ? void 0 : l.alignment) ? "0 0 0 auto" : "0 auto" : "0 auto"), [l]),
                    d = (0, o.useMemo)((() => {
                        var e, t, n, o, i, d, c, m, u, f, p, h, v, y, g, I, b, S, w, x;
                        return {
                            outerDiv: (0, s.iv)(Z || (Z = O `
        &&& {
          & {
            ${0}
          }
        }
      `), "fitToText" === (null == l ? void 0 : l.width) ? `\n                margin: ${a};\n              ` : ""),
                            button: (0, s.iv)(_ || (_ = O `
        &&& {
          & {
            text-align: center;
            color: ${0};
            font-family: ${0};
            font-size: ${0}px;
            font-style: ${0};
            font-weight: ${0};
            letter-spacing: ${0}px;
            text-decoration: ${0};

            background-color: ${0};
            border-radius: ${0}px;
            height: ${0}px;

            width: ${0};
            ${0}

            ${0}

            ${0}
          }
        }
      `), null != (e = null == r ? void 0 : r.fontColor) ? e : "#FFFFFF", null != (t = null == r ? void 0 : r.fontFamily) ? t : "", null != (n = null == r ? void 0 : r.fontSize) ? n : 16, null != (o = null == r ? void 0 : r.fontStyle) ? o : "", null != (i = null == r ? void 0 : r.fontWeight) ? i : "", null != (d = null == r ? void 0 : r.letterSpacing) ? d : 0, null != (c = null == r ? void 0 : r.textDecoration) ? c : "", null != (m = null == l ? void 0 : l.color) ? m : "#000000", null != (u = null == l ? void 0 : l.borderRadius) ? u : 4, null != (f = null == l ? void 0 : l.height) ? f : 44, "fitToText" === (null == l ? void 0 : l.width) ? "fit-content" : "100%", "fitToText" === (null == l ? void 0 : l.width) ? "padding: 0 10px;" : "", null != l && null != (p = l.border) && p.enabled ? `\n                  border-style: ${null!=(h=null==l||null==(v=l.border)?void 0:v.style)?h:"solid"};\n                  border-width: ${null!=(y=null==l||null==(g=l.border)?void 0:g.width)?y:1}px;\n                  border-color: ${null!=(I=null==l||null==(b=l.border)?void 0:b.color)?I:"#000000"};\n                ` : "", null != l && null != (S = l.dropShadow) && S.enabled ? `\n                  filter: drop-shadow(0px 0px 15px ${null!=(w=null==l||null==(x=l.dropShadow)?void 0:x.color)?w:"#000000"});\n                ` : "")
                        }
                    }), [r, l, a]);
                return i().createElement(V.ZC, {
                    a11yIdentifier: t,
                    className: d.outerDiv
                }, i().createElement(V.zx, {
                    a11yIdentifier: t,
                    type: "button",
                    className: d.button
                }, n))
            };
            var M = ({
                dynamicButtonId: e
            }) => i().createElement("div", {
                style: {
                    zIndex: "1",
                    display: "flex",
                    flex: 1,
                    width: "100%",
                    alignItems: "flex-start",
                    justifyContent: "center",
                    padding: "96px 0px",
                    backgroundColor: "var(--color-surface-app-background)"
                }
            }, i().createElement("div", {
                style: {
                    display: "flex",
                    flex: 1,
                    flexDirection: "column",
                    width: "100%",
                    maxWidth: "880px",
                    overflow: "hidden",
                    borderRadius: "12px",
                    border: "1px solid var(--color-border-general-subtle)",
                    backgroundColor: "var(--color-surface-primary-base)"
                }
            }, i().createElement("div", {
                style: {
                    display: "flex",
                    width: "100%",
                    height: "60px",
                    alignItems: "center",
                    padding: "0px 24px",
                    backgroundColor: "var(--color-background-default-base)"
                }
            }, i().createElement("div", {
                style: {
                    width: "10%",
                    height: "16px",
                    borderRadius: "var(--unit-border-radius-sm)",
                    backgroundColor: "var(--color-background-neutral-subtle-base)"
                }
            })), i().createElement("div", {
                style: {
                    display: "flex",
                    flex: 1,
                    width: "100%",
                    padding: "16px 24px",
                    alignItems: "center",
                    gap: "12px",
                    backgroundColor: "var(--color-background-neutral-subtle-base)",
                    color: "var(--color-background-neutral-subtle-selected)"
                }
            }, i().createElement("div", {
                style: {
                    display: "flex",
                    height: "8px",
                    width: "44px",
                    borderRadius: "var(--unit-border-radius-lg)",
                    backgroundColor: "var(--color-background-neutral-subtle-focused)"
                }
            }), i().createElement("div", {
                style: {
                    display: "flex",
                    height: "8px",
                    width: "44px",
                    borderRadius: "var(--unit-border-radius-lg)",
                    backgroundColor: "var(--color-background-neutral-subtle-focused)"
                }
            }), i().createElement("div", {
                style: {
                    display: "flex",
                    height: "8px",
                    width: "44px",
                    borderRadius: "var(--unit-border-radius-lg)",
                    backgroundColor: "var(--color-background-neutral-subtle-focused)"
                }
            }), i().createElement("div", {
                style: {
                    display: "flex",
                    flex: 1,
                    flexGrow: "0.95"
                }
            }), i().createElement("span", {
                style: {
                    width: "20px",
                    height: "20px"
                }
            }, i().createElement(k, null)), i().createElement("span", {
                style: {
                    width: "20px",
                    height: "20px",
                    paddingRight: "5px"
                }
            }, i().createElement(T, null))), i().createElement("div", {
                style: {
                    display: "flex",
                    width: "100%"
                }
            }, i().createElement("div", {
                style: {
                    display: "flex",
                    flex: 1,
                    flexDirection: "row",
                    backgroundColor: "var(--color-background-default-base)"
                }
            }, i().createElement("div", {
                style: {
                    display: "flex",
                    flex: 1,
                    width: "100%",
                    padding: "48px 0 64px 48px",
                    alignItems: "center",
                    justifyContent: "center"
                }
            }, i().createElement("div", {
                style: {
                    padding: "48px",
                    borderRadius: "var(--unit-border-radius-xl)",
                    backgroundColor: "var(--color-background-neutral-subtle-base)"
                }
            }, i().createElement(x, null))), i().createElement("div", {
                style: {
                    display: "flex",
                    flex: 1,
                    flexDirection: "column",
                    padding: "48px 64px 24px 24px",
                    gap: "12px"
                }
            }, i().createElement("div", {
                style: {
                    display: "flex",
                    width: "100%",
                    height: "16px",
                    borderRadius: "var(--unit-border-radius-sm)",
                    backgroundColor: "var(--color-background-neutral-subtle-base)"
                }
            }, " "), i().createElement("div", {
                style: {
                    display: "flex",
                    width: "100%",
                    height: "16px",
                    borderRadius: "var(--unit-border-radius-sm)",
                    backgroundColor: "var(--color-background-neutral-subtle-base)"
                }
            }, " "), i().createElement("div", {
                style: {
                    display: "flex",
                    width: "30%",
                    height: "16px",
                    borderRadius: "var(--unit-border-radius-sm)",
                    backgroundColor: "var(--color-background-neutral-subtle-base)"
                }
            }, " "), i().createElement(F, {
                dynamicButtonId: e
            }))))));
            var A = ({
                    formVersionCId: e,
                    node: t,
                    designerFunctions: n,
                    designerInfo: o
                }) => {
                    const r = (0, u.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                        s = (0, u.Z)((t => {
                            var n;
                            return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.formVersionId
                        })),
                        l = (0, u.Z)((t => {
                            var n;
                            return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.currentTeaserId
                        })),
                        a = (0, u.Z)((t => {
                            var n;
                            return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.currentDynamicButtonId
                        })),
                        d = (0, u.Z)((e => {
                            const t = e.formsState.teasers ? Object.values(e.formsState.teasers).filter((e => (null == e ? void 0 : e.formVersionId) === s)) : [];
                            return !!(t.length > 0 && t[0])
                        }));
                    if (r && null === t) return null;
                    const p = s => {
                        const c = i().createElement(b, {
                                formVersionCId: e,
                                closePortal: r ? () => {} : s,
                                designerFunctions: n,
                                designerInfo: o
                            }),
                            u = i().createElement(m, {
                                formVersionCId: e,
                                closePortal: r ? () => {} : s,
                                designerFunctions: n,
                                designerInfo: o,
                                portalNode: t
                            });
                        return r ? a ? i().createElement(M, {
                            dynamicButtonId: a
                        }) : l ? c : u : i().createElement(i().Fragment, null, d && c, u)
                    };
                    return i().createElement(c.Z, {
                        key: e,
                        defaultOpen: !0,
                        onClose: () => {
                            (0, f.zd)({
                                formVersionCId: e
                            })
                        },
                        closeOnEsc: !r,
                        node: r ? t : void 0
                    }, (({
                        closePortal: e,
                        portal: t
                    }) => [t(p(e))]))
                },
                D = n(22903),
                N = n(83485),
                B = n(89709),
                R = n(9247);
            var j = e => {
                    const [t, n] = (0, o.useState)(!1), [i, r] = (0, o.useState)(!1), s = (0, o.useRef)(null);
                    return (0, o.useEffect)((() => {
                        const t = s.current,
                            o = new IntersectionObserver((e => {
                                const [t] = e;
                                n(t.isIntersecting), t.isIntersecting && !i && r(!0)
                            }), e);
                        return t && o.observe(t), () => {
                            t && o.unobserve(t)
                        }
                    }), [e, i]), [s, {
                        isInView: t,
                        hasBeenViewed: i
                    }]
                },
                z = n(95223),
                W = n(51440);
            var P = ({
                    node: e,
                    formVersionCId: t,
                    designerFunctions: n,
                    designerInfo: r,
                    isA11y: s = !1,
                    a11yViewId: l
                }) => {
                    const [a, {
                        hasBeenViewed: d
                    }] = j({
                        threshold: .1
                    }), c = (0, u.Z)((e => {
                        var n;
                        return null == (n = e.onsiteState.openFormVersions[t]) ? void 0 : n.closed
                    })), m = (0, u.Z)((e => {
                        var n;
                        return null == (n = e.onsiteState.openFormVersions[t]) ? void 0 : n.formId
                    })), f = (0, u.Z)((e => {
                        var n;
                        return null == (n = e.onsiteState.openFormVersions[t]) ? void 0 : n.currentViewId
                    })), p = (0, u.Z)((e => {
                        var n;
                        return null == (n = e.onsiteState.openFormVersions[t]) ? void 0 : n.errorViewMessage
                    })), h = (0, u.Z)((e => {
                        var n;
                        return null == (n = e.onsiteState.openFormVersions[t]) ? void 0 : n.formVersionId
                    })), v = (0, u.Z)((e => e.onsiteState.client.klaviyoCompanyId));
                    (0, o.useEffect)((() => {
                        if (!d || !h) return;
                        const e = u.Z.getState(),
                            n = (0, W.Xk)(e, h);
                        n && ((0, B.M)({
                            metric: z.PZ,
                            formVersionCId: t,
                            logCustomEvent: !0,
                            formId: null != m ? m : "",
                            companyId: null != v ? v : "",
                            allowReTriggering: !1
                        }), (0, B.M)({
                            metric: z.n5,
                            formVersionCId: t,
                            logCustomEvent: !0,
                            formId: null != m ? m : "",
                            companyId: null != v ? v : "",
                            step_name: (0, W.E5)(e, n.viewId),
                            step_number: 1
                        }))
                    }), [m, t, d, v, h]);
                    const y = e || document.querySelector(`div.klaviyo-form-${m}.form-version-cid-${t}`),
                        g = (0, o.useMemo)((() => n ? `${R.Sq}:${R.Pg}:${f}` : void 0), [n, f]);
                    return y && !c ? (0, o.createPortal)(f && h ? i().createElement(i().Fragment, null, p ? i().createElement(N.Z, {
                        isEmbed: !0,
                        errorViewMessage: p
                    }) : i().createElement(V.ZC, {
                        ref: a,
                        a11yIdentifier: g,
                        style: Object.assign({
                            transform: "translate(0, 0)"
                        }, s ? {
                            position: "absolute",
                            transform: "scale(0.001)",
                            zIndex: 1
                        } : {})
                    }, i().createElement(D.Z, {
                        formVersionCId: t,
                        formVersionId: h,
                        viewId: l || f,
                        isEmbed: !0,
                        key: t,
                        designerFunctions: n,
                        designerInfo: r
                    }))) : null, y) : null
                },
                L = n(28391);
            var H = () => {
                const e = (0, u.Z)((e => Object.keys(e.onsiteState.openFormVersions)), d.X),
                    t = (0, u.Z)((e => Object.values(e.onsiteState.openFormVersions).filter((e => !!e)).filter((({
                        formVersionId: t
                    }) => {
                        var n;
                        return (null == (n = e.formsState.formVersions[t]) ? void 0 : n.formType) === L.LP
                    })).map((({
                        formVersionCId: e
                    }) => e))), d.X);
                return i().createElement(o.Suspense, {
                    fallback: i().createElement("div", null)
                }, e.map((e => {
                    const n = {
                        formVersionCId: e
                    };
                    return t.includes(e) ? i().createElement(P, a()({
                        key: e
                    }, n)) : i().createElement(A, a()({
                        key: e
                    }, n))
                })))
            };
            (0, s.cY)(r.h);
            var q = () => {
                const e = document.createElement("div");
                e.setAttribute("id", "dynamic-react-root"), document.body.appendChild(e), (0, o.render)(i().createElement(H, null), e)
            }
        },
        87974: function(e, t, n) {
            n.d(t, {
                j: function() {
                    return et
                }
            });
            var o = n(75186),
                i = n(87789),
                r = n.n(i),
                s = n(62839),
                l = n(7628),
                a = n(82767);
            class d {
                constructor({
                    formVersionCId: e,
                    actionId: t
                }) {
                    this.currentHandlerStep = "INSTANTIATED", this.formActionType = void 0, this.actionId = void 0, this.formVersionCId = void 0, this.formAction = void 0, this.formId = void 0, this.companyId = void 0, this.messageBus = void 0, this.profileEvents = void 0;
                    const n = o.Z.getState();
                    this.actionId = t, this.formVersionCId = e, this.formAction = (n.formsState.actions || {})[t];
                    const i = n.onsiteState.openFormVersions[e];
                    if (this.messageBus = (0, a.c)(n), !i) throw new Error("Open Form Version does not exist");
                    this.formId = i.formId, this.companyId = n.onsiteState.client.klaviyoCompanyId, this.profileEvents = {
                        formSubmitted: null,
                        formCompleted: null
                    }
                }
                runAction() {
                    return this.currentHandlerStep = "PREHANDLER", new Promise((e => e())).then((e => this.__preHandler(e))).then((e => this.__identify(e))).then((e => this.__createProfileEvents(e))).then((e => (this.currentHandlerStep = "HANDLER", e))).then((e => this.__handler(e))).then((e => (this.currentHandlerStep = "POSTHANDLER", e))).then((e => this.__postHandler(e))).catch((e => this.__errorHandler(e)))
                }
                __preHandler(e) {}
                __handler(e) {}
                __postHandler(e) {}
                __errorHandler(e) {
                    (0, l.qB)(e.toString(), {
                        formActionType: this.formActionType,
                        currentHandlerStep: this.currentHandlerStep
                    })
                }
                __identify(e) {}
                __createProfileEvents(e) {}
            }
            d.formActionType = void 0;
            var c = n(98889);
            const m = ["isSubmit"];
            class u extends d {
                constructor(e) {
                    let {
                        isSubmit: t
                    } = e;
                    super(r()(e, m)), this.isSubmit = void 0, this.isSubmit = t, this.formActionType = s.Pj
                }
                __handler() {
                    return (0, c.fK)({
                        id: this.formVersionCId,
                        changes: {
                            logCloseMetric: !this.isSubmit
                        }
                    }), (0, c.et)({
                        formVersionCId: this.formVersionCId,
                        isSubmit: this.isSubmit
                    })
                }
            }
            u.formActionType = s.Pj;
            var f = u,
                p = (n(51778), n(52266)),
                h = n(78542),
                v = (n(92461), n(39265), n(63775)),
                y = n(89709),
                g = n(23759),
                I = n(51440),
                b = n(16254),
                S = n(82883),
                w = n(71002),
                x = n(1247);
            const C = async (e, t, n, o, i, r, s) => {
                var a, d;
                const m = (0, I.QE)(e, s);
                let u = (0, I.Tf)(e, s);
                if ((0, l.Cw)("requestShopPayShow", {
                        firstViewId: m,
                        successViewId: u
                    }), !u) return !1;
                const f = (0, x.L)(e, u);
                f && (u = f, (0, l.Cw)("requestShopPayShow", {
                    overrideSuccessViewId: f
                }));
                const p = (0, I.I_)(e, u);
                var h;
                null != p && null != (a = p[0]) && a.viewId && (u = null == p || null == (h = p[0]) ? void 0 : h.viewId, (0, l.Cw)("requestShopPayShow", {
                    skippedDynamicViewCalculation: !0,
                    overrideSuccessViewId: u
                }));
                const C = (0, I.nC)(e, u).find((e => e && (0, g.J6)(e))),
                    E = (0, g.hB)(e, s) || (0, g.K1)(e, s),
                    k = (null == C ? void 0 : C.data.couponType) === b.$i.STATIC ? null == C || null == (d = C.data.couponData) ? void 0 : d.text : await (0, c.zS)({
                        formVersionCId: r
                    });
                if ((0, l.Cw)("requestShopPayShow", {
                        hasCouponComponent: void 0 !== C,
                        listId: E,
                        discountCode: k
                    }), C && E && "string" == typeof k) {
                    let e, s = !0;
                    const a = new Promise((t => {
                        e = t, setTimeout((() => {
                            s && t(!0)
                        }), 5e3)
                    }));
                    return (0, w.AN)(o, i, E, t, k, (() => {
                        s = !1, (0, v.UY)({
                            showingShopLogin: S.K.SHOWING
                        })
                    }), (() => {
                        e(!0), ((e, t) => {
                            (0, c.Cm)({
                                id: e,
                                changes: {
                                    currentViewId: t
                                }
                            })
                        })(r, n)
                    }), ((t, n) => {
                        e(!n), ((e, t, n, o, i, r) => {
                            (0, l.Cw)("onShopPayComplete"), r && (0, c.Cm)({
                                id: n,
                                changes: {
                                    currentViewId: o
                                }
                            }), (0, v.UY)({
                                showingShopLogin: S.K.CLOSED
                            }), i && e && (0, y.M)({
                                metric: i,
                                formVersionCId: n,
                                formId: t,
                                companyId: e
                            })
                        })(i, o, r, u, t, n)
                    }), (() => {
                        e(!1), ((e, t) => {
                            (0, l.Cw)("onShopPayRestart"), t ? ((0, c.Cm)({
                                id: e,
                                changes: {
                                    currentViewId: t
                                }
                            }), (0, v.UY)({
                                showingShopLogin: S.K.NEVER_SHOWN
                            })) : (0, v.UY)({
                                showingShopLogin: S.K.CLOSED
                            })
                        })(r, m)
                    })), a
                }
                return !1
            };
            n(22923), n(70818), n(44159);
            var E = n(32681),
                k = n(5762),
                $ = n(28977),
                T = n(17547),
                V = n(95357),
                Z = n(12367),
                _ = n(95223),
                O = n(78880),
                F = n(53896),
                M = n(61594),
                A = n(57762);
            var D = (e, t, n, o) => e === s.h7 || !!t[h.HD] || !!t[h.lL] && n && o,
                N = n(67674),
                B = n(62623),
                R = n(66545),
                j = n(69042);
            var z = ({
                    email: e,
                    exchangeId: t,
                    phoneNumber: n,
                    metricName: o,
                    formId: i,
                    formVersionId: r,
                    pageUrl: s,
                    deviceType: l,
                    utmParams: a,
                    isClientEvent: d = !1
                }) => {
                    if (!e && !n) return null;
                    return {
                        type: "event",
                        attributes: {
                            metric: {
                                data: {
                                    type: "metric",
                                    attributes: {
                                        name: o,
                                        service: "api"
                                    }
                                }
                            },
                            profile: {
                                data: {
                                    type: "profile",
                                    attributes: {
                                        email: e,
                                        phone_number: n,
                                        properties: {
                                            $email: e,
                                            $phone_number: n,
                                            $exchange_id: t
                                        },
                                        _kx: t
                                    }
                                }
                            },
                            properties: Object.assign({
                                form_id: i,
                                form_version_id: r,
                                page: s,
                                device_type: l,
                                $use_ip: !0,
                                $is_session_activity: !0,
                                $is_client_event: d
                            }, a)
                        }
                    }
                },
                W = n(13529);
            const P = () => {
                var e, t;
                return !(null == (e = window.Shopify) || null == (e = e.analytics) || !e.visitor) && "function" == typeof(null == (t = window.Shopify) || null == (t = t.analytics) ? void 0 : t.visitor)
            };
            var L = n(88911),
                H = (n(61099), n(81903)),
                q = n(70640),
                U = n(87100);
            const K = e => e instanceof R.TT;
            var G = class extends d {
                    constructor(e) {
                        super(e), this.hiddenFieldsComponentId = void 0, this.composedFields = void 0;
                        const t = o.Z.getState();
                        this.hiddenFieldsComponentId = (0, g.cA)(t, e.actionId), this.composedFields = (0, p.$f)(t, this.formVersionCId, this.hiddenFieldsComponentId)
                    }
                    async __preHandler() {
                        if (this.formAction.actionType && s.NB.has(this.formAction.actionType)) {
                            const e = await (0, c.eN)({
                                formVersionCId: this.formVersionCId
                            });
                            if (e && e.some((({
                                    valid: e
                                }) => !e))) throw new R.mN({
                                type: "form"
                            });
                            return !0
                        }
                        return !0
                    }
                    __requestUniqueID() {
                        (e => {
                            const t = {
                                method: "POST",
                                headers: {
                                    "content-type": "application/json",
                                    "Access-Control-Allow-Origin": "*"
                                },
                                body: JSON.stringify((0, q.Y)(e))
                            };
                            return (0, U.Z)("https://a.klaviyo.com/ajax/sms/subscribe_unique_id", t).then((e => {
                                if (e.status >= 500) throw Error(`Error sending request: ${e.url}`);
                                return e
                            })).then((e => e.json())).then((e => (0, q._)(e)))
                        })({
                            companyId: this.companyId,
                            form_id: this.formId,
                            email: this.composedFields[h.HD]
                        }).then((({
                            data: {
                                uniqueId: e
                            }
                        }) => {
                            void 0 !== e && (0, v.UY)({
                                smsSubscriptionUniqueId: e
                            })
                        })).catch((() => {}))
                    }
                    __errorHandler(e) {
                        const {
                            composedFields: t,
                            formId: n,
                            companyId: o,
                            formAction: i
                        } = this;
                        if (d.prototype.__errorHandler.call(this, e), (e => [R.vS, R.mN, R.a, R.FR].some((t => e instanceof t)))(e)) throw e;
                        (0, c.Cm)({
                            id: this.formVersionCId,
                            changes: {
                                errorViewMessage: K(e) ? F.gl : F.xl
                            }
                        }), (0, y.M)({
                            metric: K(e) ? _.yH : _.DF,
                            formVersionCId: this.formVersionCId,
                            formId: n,
                            companyId: o,
                            submittedFields: t,
                            listId: null == i ? void 0 : i.listId,
                            isProgressEventError: (0, R.pS)(e),
                            errorName: e.name,
                            errorMessage: e.message
                        }), (0, R.pS)(e) || K(e) || (0, H.T)(e, {
                            tags: {
                                onSubmit: "True"
                            },
                            extra: {
                                submitAction: !0,
                                formId: this.formId,
                                companyId: this.companyId
                            }
                        })
                    }
                },
                Y = n(64696),
                X = n(92550);
            var J = class extends G {
                    submitMetric({
                        state: e,
                        isSubscribe: t = !1,
                        submitMetric: n = _.dm,
                        submitMetricActionType: o = "Submit Form"
                    }) {
                        const i = e.onsiteState.openFormVersions[this.formVersionCId];
                        if (!i) throw new Error("Open Form Version does not exist");
                        const {
                            currentViewId: r
                        } = i, s = (0, Y.f8)(e, this.formVersionCId, t), l = (0, I.E5)(e, r), a = e.formsState.views[r], d = a ? (0, I.O)(e, a) : void 0, m = [(0, y.M)({
                            metric: _.AH,
                            formVersionCId: this.formVersionCId,
                            logCustomEvent: !0,
                            formId: this.formId,
                            companyId: this.companyId,
                            submittedFields: Object.assign({}, this.composedFields, {
                                $step_name: l
                            }),
                            step_name: l,
                            step_number: void 0 !== d ? d + 1 : d,
                            action_type: "Submit Step"
                        })];
                        if ((0, I.Qe)(e, r)) {
                            const t = this._trackSpinToWinSubmit(e, i, l, d);
                            t && m.push(t)
                        }
                        return (t || (0, p.Gt)(e, this.formVersionCId, s)) && m.push((0, y.M)({
                            metric: n,
                            logCustomEvent: !0,
                            formVersionCId: this.formVersionCId,
                            formId: this.formId,
                            companyId: this.companyId,
                            submittedFields: this.composedFields,
                            action_type: o
                        })), i && _.us.indexOf(s) < _.us.indexOf(i.topHierarchySubmitted) && (0, c.fK)({
                            id: this.formVersionCId,
                            changes: {
                                topHierarchySubmitted: s
                            }
                        }), Promise.all(m)
                    }
                    __identify() {
                        const e = (0, E.Un)();
                        let t;
                        const n = new Promise((e => {
                            t = e
                        }));
                        return !0 !== e ? Promise.resolve(null) : ((0, E.ro)({
                            fields: this.composedFields,
                            callback: () => (t(!0), !0)
                        }), n)
                    }
                    __handler() {
                        var e;
                        const t = o.Z.getState(),
                            n = t.onsiteState.openFormVersions[this.formVersionCId];
                        if (!n) throw new Error("Open Form Version does not exist");
                        const {
                            formVersionId: i
                        } = n;
                        !!Object.values(t.formsState.views).filter((e => (null == e ? void 0 : e.formVersionId) === i)).find((e => !!e && (0, I.nC)(t, e.viewId).find((e => {
                            const n = e ? t.formsState.components[e.componentId] : void 0;
                            return !!n && (0, g.FW)(t, n)
                        })))) && this.composedFields[h.HD] && this.__requestUniqueID();
                        const r = (0, g.B0)(t, i),
                            s = void 0 !== (0, g.CW)(t, this.formVersionCId);
                        if (!D(this.formActionType, this.composedFields, r, s)) return void this.submitMetric({
                            state: t
                        });
                        const l = (0, p.jo)(t, this.formVersionCId);
                        return this.composedFields = Object.assign({}, this.composedFields, l || {}), null != (e = t.formsState.formVersions[i]) && e.data.storeUtmParams && (this.composedFields = Object.assign({}, this.composedFields, (0, N.Z)())), this.__submitToList()
                    }
                    async __postHandler(e) {
                        var t, n;
                        const i = o.Z.getState(),
                            r = i.onsiteState.openFormVersions[this.formVersionCId];
                        if (!r) throw new Error("Open Form Version does not exist");
                        const {
                            formVersionId: s
                        } = r, l = (0, B.Z)(), a = !(null == (t = i.onsiteState.createdProfileEvents[this.formId]) || !t.formSubmitted);
                        a || (0, Y.LY)({
                            formId: this.formId,
                            formVersionId: s,
                            pageUrl: window.location.href,
                            deviceType: l,
                            hasSubmittedEventBeenCreated: a,
                            utmParams: (0, N.Z)()
                        });
                        const d = i.formsState.formVersions[s];
                        if (d) {
                            var c;
                            const e = (0, I.sb)(i, d.formVersionId, l, (0, p.wf)(i, this.formVersionCId)) === r.currentViewId,
                                t = !(null == (c = i.onsiteState.createdProfileEvents[this.formId]) || !c.formCompleted);
                            !t && e && (0, Y.ej)({
                                formId: this.formId,
                                formVersionId: s,
                                pageUrl: window.location.href,
                                deviceType: l,
                                hasCompletedEventBeenCreated: t,
                                utmParams: (0, N.Z)()
                            })
                        }
                        const m = null == i || null == (n = i.onsiteState) || null == (n = n.formSettings) ? void 0 : n.shopifyVisitorApi;
                        if (null != e && e.status && (null == e ? void 0 : e.status) >= 200 && (null == e ? void 0 : e.status) < 300 && m && P()) {
                            const {
                                syncSMSConsent: e,
                                syncEmailConsent: t
                            } = m, {
                                [h.HD]: n,
                                [h.lL]: o
                            } = this.composedFields;
                            if (!n && !o) return;
                            (({
                                email: e,
                                phone: t
                            }) => {
                                if ((e || t) && P()) {
                                    var n;
                                    let o = {};
                                    return e && (o = Object.assign({}, o, {
                                        email: e
                                    })), t && (o = Object.assign({}, o, {
                                        phone: t
                                    })), null == (n = window.Shopify) || null == (n = n.analytics) ? void 0 : n.visitor(o, {
                                        appId: W.cY.shopify.visitorApi.appId
                                    })
                                }
                            })(Object.assign({}, n && t ? {
                                email: n
                            } : {}, o && e ? {
                                phone: o
                            } : {}))
                        }
                    }
                    __submitHandlerCheck(e) {
                        const {
                            composedFields: t,
                            formId: n,
                            companyId: o,
                            formAction: i
                        } = this;
                        if (e !== O.Sz && e !== O.dl) throw (0, c.Cm)({
                            id: this.formVersionCId,
                            changes: {
                                errorViewMessage: F.xl
                            }
                        }), (0, y.M)({
                            metric: _.DF,
                            formVersionCId: this.formVersionCId,
                            formId: n,
                            companyId: o,
                            submittedFields: t,
                            listId: i.listId
                        }), new R.vS
                    }
                    __handlePassedCaptchaChallenge() {}
                    __handleSubmitToListError() {
                        const e = new AbortController,
                            {
                                signal: t
                            } = e;
                        window.addEventListener(M.H, (() => {
                            this.__handlePassedCaptchaChallenge(), (0, y.M)({
                                metric: _.uf,
                                formVersionCId: this.formVersionCId,
                                formId: this.formId,
                                companyId: this.companyId,
                                submittedFields: this.composedFields,
                                logTelemetric: !0
                            }), e.abort()
                        }), {
                            signal: t
                        }), window.addEventListener(M.vT, (() => {
                            new f({
                                formVersionCId: this.formVersionCId,
                                actionId: this.actionId
                            }).runAction(), e.abort()
                        }), {
                            signal: t
                        }), (0, y.M)({
                            metric: _.Wx,
                            formVersionCId: this.formVersionCId,
                            formId: this.formId,
                            companyId: this.companyId,
                            submittedFields: this.composedFields,
                            logTelemetric: !0
                        })
                    }
                    __handleWAFRuleViolationError() {
                        (0, y.M)({
                            metric: _.wL,
                            formVersionCId: this.formVersionCId,
                            formId: this.formId,
                            companyId: this.companyId,
                            submittedFields: this.composedFields,
                            logTelemetric: !0
                        });
                        new f({
                            formVersionCId: this.formVersionCId,
                            actionId: this.actionId
                        }).runAction()
                    }
                    __baseSubmitToList(e) {
                        const {
                            composedFields: t,
                            formId: n,
                            companyId: i
                        } = this, r = o.Z.getState(), s = (0, p.io)(r, this.formVersionCId), l = this.__makePOSTBody({
                            composedFields: t,
                            requestOTPCode: s,
                            phoneInputConsentTypes: (0, g.CW)(r, this.formVersionCId)
                        });
                        return (0, v.x7)(l), (0, k.W)((() => e(i, l)), 5, 1e3 + 1e3 * Math.random(), [429]).then((e => {
                            if (429 === e.status) throw new R.TT;
                            if (403 === e.status) throw new R.FR;
                            return e
                        })).then((e => {
                            if (e.status === O.Sz && this.formAction.actionType) {
                                const t = Object.fromEntries(Object.entries(this.profileEvents).filter((([, e]) => null !== e))),
                                    o = Object.keys(t);
                                if ((0, V.Z)(this.formId, o), o.length > 0) {
                                    const e = (0, X.iv)(X.yn),
                                        t = (null == e ? void 0 : e.submittedForms) || {},
                                        i = (null == e ? void 0 : e.completedForms) || {};
                                    try {
                                        (0, X.$T)(X.yn, Object.assign({}, e, {
                                            submittedForms: Object.assign({}, t, o.includes("formSubmitted") ? {
                                                [n]: (new Date).toISOString()
                                            } : {}),
                                            completedForms: Object.assign({}, i, o.includes("formCompleted") ? {
                                                [n]: (new Date).toISOString()
                                            } : {})
                                        }))
                                    } catch (e) {
                                        console.error("Error saving session storage", e)
                                    }
                                }
                                return (0, Z.$k)({
                                    formId: n,
                                    successActionType: this.formAction.actionType
                                }), (0, j.n)(200, this.submitMetric({
                                    state: r,
                                    isSubscribe: !0
                                })).then((() => e)).catch((() => e))
                            }
                            return e
                        })).catch((e => {
                            if (e instanceof R.a) throw this.__handleSubmitToListError(), e;
                            if (e instanceof R.FR || (0, $.p)(e)) return this.__handleWAFRuleViolationError(), null;
                            throw e
                        }))
                    }
                    __submitToList() {
                        return this.__baseSubmitToList(L.Y)
                    }
                    __makePOSTBody({
                        composedFields: e,
                        requestOTPCode: t = !1,
                        phoneInputConsentTypes: n
                    }) {
                        const o = new Date,
                            i = Object.assign({}, e, "object" == typeof window.Shopify && window.Shopify.shop ? {
                                services: JSON.stringify({
                                    shopify: {
                                        source: "form"
                                    }
                                })
                            } : {}),
                            {
                                $exchange_id: r
                            } = (0, E.zy)();
                        let s = Object.assign({}, i);
                        const l = {};
                        let a;
                        h.XK.forEach((e => {
                            if (i[e]) {
                                const t = i[e];
                                a = Array.isArray(t) ? 1 === t.length ? t[0] : t.join(", ") : t, delete s[e]
                            }
                        })), "email" in i && (l.email = i.email, delete s.email), "$email" in i && (l.email = i.$email, delete s.$email), "sms_consent" in i && (i.sms_consent && (l.phone_number = i.$phone_number, delete s.$phone_number), delete s.sms_consent), "opt_in_promotional_sms" in i && delete s.opt_in_promotional_sms, "whatsapp_consent" in i && (i.whatsapp_consent && (l.phone_number = i.$phone_number, delete s.$phone_number), delete s.whatsapp_consent), "sentIdentifiers" in i && (s = Object.assign({}, s, i.sentIdentifiers), delete s.sentIdentifiers);
                        const d = Object.values(this.profileEvents).filter((e => null !== e));
                        return Object.assign({
                            data: Object.assign({
                                type: O.NR,
                                attributes: Object.assign({}, d.length > 0 ? {
                                    events: {
                                        data: d
                                    }
                                } : {}, {
                                    profile: {
                                        data: {
                                            type: O.cC,
                                            attributes: Object.assign({}, l, {
                                                subscriptions: Object.assign({}, l.email ? {
                                                    email: {
                                                        marketing: {
                                                            consent: "SUBSCRIBED"
                                                        }
                                                    }
                                                } : {}, (() => {
                                                    if (!l.phone_number) return {};
                                                    switch (null == n ? void 0 : n.sms) {
                                                        case A.E3.PROMOTIONAL:
                                                            return "false" === i.opt_in_promotional_sms ? {} : {
                                                                sms: {
                                                                    marketing: {
                                                                        consent: "SUBSCRIBED"
                                                                    }
                                                                }
                                                            };
                                                        case A.E3.TRANSACTIONAL:
                                                            return {
                                                                sms: {
                                                                    transactional: {
                                                                        consent: "SUBSCRIBED"
                                                                    }
                                                                }
                                                            };
                                                        case A.E3.SINGLE_STEP_TRANSACTIONAL_PROMOTIONAL:
                                                            return {
                                                                sms: Object.assign({
                                                                    transactional: {
                                                                        consent: "SUBSCRIBED"
                                                                    }
                                                                }, "true" === i.opt_in_promotional_sms ? {
                                                                    marketing: {
                                                                        consent: "SUBSCRIBED"
                                                                    }
                                                                } : {})
                                                            };
                                                        case A.E3.MULTI_STEP_TRANSACTIONAL_PROMOTIONAL:
                                                            return {
                                                                sms: {
                                                                    transactional: {
                                                                        consent: "SUBSCRIBED"
                                                                    }
                                                                }
                                                            };
                                                        default:
                                                            return {}
                                                    }
                                                })(), (() => {
                                                    if (!l.phone_number) return {};
                                                    switch (null == n ? void 0 : n.whatsApp) {
                                                        case A.E3.PROMOTIONAL:
                                                            return {
                                                                whatsapp: {
                                                                    marketing: {
                                                                        consent: "SUBSCRIBED"
                                                                    }
                                                                }
                                                            };
                                                        case A.E3.TRANSACTIONAL:
                                                            return {
                                                                whatsapp: {
                                                                    transactional: {
                                                                        consent: "SUBSCRIBED"
                                                                    }
                                                                }
                                                            };
                                                        default:
                                                            return {}
                                                    }
                                                })()),
                                                properties: Object.assign({}, s, {
                                                    $timezone_offset: -o.getTimezoneOffset() / 60
                                                }, r ? {
                                                    $exchange_id: r
                                                } : {})
                                            })
                                        }
                                    }
                                }, a ? {
                                    custom_source: a
                                } : {})
                            }, this.formAction.listId ? {
                                relationships: {
                                    list: {
                                        data: {
                                            type: O._,
                                            id: this.formAction.listId
                                        }
                                    }
                                }
                            } : {})
                        }, t ? {
                            meta: {
                                send_otp_code: !0
                            }
                        } : {})
                    }
                    __createProfileEvents() {
                        const e = o.Z.getState(),
                            t = e.onsiteState.openFormVersions[this.formVersionCId];
                        if (!t) throw new Error("Open Form Version does not exist");
                        const {
                            formVersionId: n
                        } = t, i = (0, g.B0)(e, n), r = void 0 !== (0, g.CW)(e, this.formVersionCId), s = D(this.formActionType, this.composedFields, i, r), l = (0, E.pN)();
                        if (!s && !l) return;
                        const {
                            $exchange_id: a
                        } = (0, E.zy)();
                        l ? this.saveProfileEventsToClass(a) : this.saveProfileEventsToClass()
                    }
                    saveProfileEventsToClass(e) {
                        var t;
                        const n = o.Z.getState(),
                            i = n.onsiteState.openFormVersions[this.formVersionCId];
                        if (!i) throw new Error("Open Form Version does not exist");
                        const {
                            formVersionId: r,
                            currentViewId: s
                        } = i, l = (0, I.QR)(n, r), a = l.length, d = !(null == (t = n.onsiteState.createdProfileEvents[this.formId]) || !t.formSubmitted), c = (0, B.Z)(), m = n.formsState.formVersions[r], u = (0, X.iv)(X.yn), f = (null == u ? void 0 : u.submittedForms) || {}, h = (null == u ? void 0 : u.completedForms) || {}, v = d || this.formId in f ? null : z({
                            exchangeId: e,
                            email: this.composedFields.$email,
                            phoneNumber: this.composedFields.$phone_number,
                            formId: this.formId,
                            formVersionId: r,
                            deviceType: c,
                            pageUrl: window.location.href,
                            metricName: "Form submitted by profile",
                            utmParams: (0, N.Z)()
                        }), y = this.formId in h ? null : z({
                            exchangeId: e,
                            email: this.composedFields.$email,
                            phoneNumber: this.composedFields.$phone_number,
                            formId: this.formId,
                            formVersionId: r,
                            deviceType: c,
                            pageUrl: window.location.href,
                            metricName: "Form completed by profile",
                            utmParams: (0, N.Z)()
                        });
                        2 === a && (this.profileEvents = {
                            formSubmitted: v,
                            formCompleted: y
                        });
                        const g = !!m && (0, I.sb)(n, m.formVersionId, c, (0, p.wf)(n, this.formVersionCId)) === this.formAction.viewId,
                            b = l.find((({
                                viewId: e
                            }) => e === s));
                        if ((0, T.x)(b)) return;
                        const S = (0, I.ad)(n, b, c);
                        a > 2 && S.length > 1 && (this.profileEvents = Object.assign({}, this.profileEvents, {
                            formSubmitted: v
                        }), g && (this.profileEvents = Object.assign({}, this.profileEvents, {
                            formSubmitted: v,
                            formCompleted: y
                        }))), a > 2 && 1 === S.length && (this.profileEvents = Object.assign({}, this.profileEvents, {
                            formSubmitted: v,
                            formCompleted: y
                        }))
                    }
                    _trackSpinToWinSubmit(e, t, n, o) {
                        var i;
                        const r = (0, I.Qe)(e, t.currentViewId);
                        if (!r) return null;
                        const s = (0, I.Tf)(e, t.formVersionId);
                        if (!s) return null;
                        const l = (0, x.L)(e, s),
                            a = null == (i = r.data.wheelLogic.slices.find((e => e.childViewId === l))) ? void 0 : i.probability;
                        return (0, y.M)({
                            metric: _.nn,
                            formVersionCId: this.formVersionCId,
                            formId: this.formId,
                            companyId: this.companyId,
                            step_name: n,
                            step_number: void 0 !== o ? o + 1 : o,
                            componentId: r.componentId,
                            overrideViewId: l,
                            outcomeProbability: a
                        })
                    }
                },
                Q = (n(60873), n(93111));
            var ee = n(22043),
                te = n(7739),
                ne = n(19931);
            const oe = "form-view",
                ie = "form-version";
            class re extends Error {
                constructor() {
                    super(), this.constructor = re, Object.setPrototypeOf(this, re.prototype), this.message = "No outcome_view_id return in in response from API"
                }
            }
            const se = ({
                    formVersionId: e,
                    formViewId: t,
                    profile: n,
                    companyId: o
                }) => {
                    const i = (({
                        formVersionId: e,
                        formViewId: t,
                        profile: n
                    }) => ({
                        data: {
                            type: "form-outcome-view",
                            attributes: {
                                profile: {
                                    data: {
                                        type: "profile",
                                        attributes: {
                                            email: n.email,
                                            phone_number: n.phoneNumber,
                                            _kx: n._kx
                                        }
                                    }
                                }
                            },
                            relationships: {
                                [ie]: {
                                    data: {
                                        type: ie,
                                        id: e
                                    }
                                },
                                [oe]: {
                                    data: {
                                        type: oe,
                                        id: t
                                    }
                                }
                            }
                        }
                    }))({
                        formVersionId: e,
                        formViewId: t,
                        profile: n
                    });
                    return (0, k.W)((() => ((e, t) => fetch(`https://a.klaviyo.com/client/form-outcome-views/?company_id=${e}`, {
                        method: "POST",
                        headers: Object.assign({
                            "Access-Control-Allow-Headers": "*",
                            "Content-Type": "application/json"
                        }, (0, te.h)(), {
                            revision: "2025-01-15"
                        }),
                        body: JSON.stringify(t)
                    }))(o, i)), 5, 1e3 + 1e3 * Math.random(), [429])
                },
                le = async e => {
                    var t;
                    let n;
                    const o = e => {
                        var t, o;
                        (t = e) instanceof CustomEvent && (null == (o = t.detail) ? void 0 : o.captchaUrl) && (window.DataDomeCaptchaDisplayed = !0, n = e.detail.captchaUrl)
                    };
                    window.addEventListener(M.Pp, o, !1), await (0, ne.l)();
                    const i = await se(e);
                    if (window.removeEventListener(M.Pp, o, !1), n) throw new R.a({
                        captchaUrl: n
                    });
                    if (429 === i.status) throw new R.TT;
                    if (202 !== i.status) throw new re;
                    const r = await i.json();
                    if (null == r || null == (t = r.data) || null == (t = t.attributes) || !t.outcome_view_id) throw new re;
                    return r
                };
            var ae = n(6273);
            class de {
                constructor(e, t) {
                    this.openFormVersion = void 0, this.identifiers = void 0, this.profile = {}, this.openFormVersion = e, this.identifiers = t
                }
                checkForViewSideEffects(e) {
                    return {
                        componentSideEffects: this.getComponentSideEffects(e)
                    }
                }
                runViewSideEffects(e) {
                    return e.componentSideEffects.map((({
                        component: e,
                        viewIds: t
                    }) => this.handleComponentSideEffect({
                        component: e,
                        viewIds: t
                    })))
                }
                checkAndRunViewSideEffects(e) {
                    const t = this.checkForViewSideEffects(e);
                    return this.runViewSideEffects(t)
                }
                getComponentSideEffects({
                    state: e
                }) {
                    const t = this.openFormVersion.currentViewId,
                        n = (0, I.nC)(e, t);
                    return (0, Q.Z)(n.map((t => {
                        if (!t) return null;
                        const n = (0, x.D)(e, t.componentId);
                        return n.length < 1 ? null : {
                            component: t,
                            viewIds: n
                        }
                    })))
                }
                handleComponentSideEffect({
                    component: e,
                    viewIds: t
                }) {
                    return "SPIN_TO_WIN" === e.componentType ? this.handleSpinToWin({
                        component: e,
                        viewIds: t
                    }) : console.warn(`Unhandled component type: ${e.componentType}`)
                }
                async handleSpinToWin({
                    component: e,
                    viewIds: t
                }) {
                    var n, i;
                    if ("SPIN_TO_WIN" !== e.componentType) throw new Error("Invalid component type");
                    const r = o.Z.getState(),
                        s = r.onsiteState.client.klaviyoCompanyId,
                        {
                            formVersionId: l,
                            currentViewId: a
                        } = this.openFormVersion,
                        d = (0, E.zy)();
                    if (this.profile = {
                            email: null != (n = this.identifiers.$email) ? n : d.$email,
                            phoneNumber: null != (i = this.identifiers.$phone_number) ? i : d.$phone_number,
                            _kx: d.$exchange_id
                        }, !s || !l || !a) return null;
                    try {
                        var m, u;
                        const e = await le({
                                companyId: s,
                                formVersionId: l,
                                formViewId: a,
                                profile: this.profile
                            }),
                            n = null == e || null == (m = e.data) || null == (m = m.attributes) ? void 0 : m.outcome_view_id,
                            i = null == e || null == (u = e.data) || null == (u = u.attributes) ? void 0 : u.coupon_code;
                        if (t.forEach((e => {
                                o.Z.setState((t => ((e, {
                                    parentViewId: t,
                                    childViewId: n
                                }) => t && n ? Object.assign({}, e, {
                                    onsiteState: Object.assign({}, e.onsiteState, {
                                        dynamicViewOverrides: Object.assign({}, e.onsiteState.dynamicViewOverrides, {
                                            [t]: n
                                        })
                                    })
                                }) : e)(t, {
                                    parentViewId: e,
                                    childViewId: n
                                })))
                            })), n) {
                            const e = (0, g.bc)(r, n);
                            i && e && o.Z.setState((t => (0, ae.W)({
                                componentId: e,
                                couponCode: i
                            }, t))), this.trackOutcomeViewCalculation({
                                outcomeViewId: n,
                                couponCode: i
                            })
                        }
                        return new Promise((e => {
                            setTimeout((() => e()), ee.Rd)
                        }))
                    } catch (e) {
                        return e instanceof Error && (0, H.T)(e, {
                            extra: {
                                companyId: s,
                                formVersionId: l,
                                formViewId: a,
                                profileIdentifiers: JSON.stringify(this.profile)
                            }
                        }), (0, c.Cm)({
                            id: this.openFormVersion.formVersionCId,
                            changes: {
                                errorViewMessage: F.xl
                            }
                        }), null
                    }
                }
                trackOutcomeViewCalculation({
                    outcomeViewId: e,
                    couponCode: t
                }) {
                    var n;
                    const i = o.Z.getState();
                    (0, y.M)(Object.assign({
                        metric: t ? _.JO : _.Q$,
                        formVersionCId: this.openFormVersion.formVersionCId,
                        formId: this.openFormVersion.formId,
                        companyId: null != (n = i.onsiteState.client.klaviyoCompanyId) ? n : "",
                        currentViewId: this.openFormVersion.currentViewId,
                        outcomeViewId: e
                    }, t && {
                        couponCode: t
                    }))
                }
            }
            var ce = n(22805);
            const me = ({
                onsiteState: e
            }, t) => {
                var n;
                return !(null == (n = e.companySenderSettings) || null == (n = n.emailSettings) || !n[t])
            };
            class ue extends J {
                async __preHandler() {
                    await super.__preHandler();
                    const e = o.Z.getState(),
                        t = e.onsiteState.openFormVersions[this.formVersionCId];
                    if (null == t || !t.currentViewId) return !0;
                    const n = new de(t, this.composedFields).checkAndRunViewSideEffects({
                        state: e
                    });
                    return await Promise.allSettled(n), !0
                }
                async __postHandler(e) {
                    var t;
                    super.__postHandler(e);
                    const n = o.Z.getState(),
                        i = n.onsiteState.openFormVersions[this.formVersionCId];
                    if (!i || !this.formAction.viewId) return null;
                    e && this.__submitHandlerCheck(e.status);
                    let r = this.formAction.viewId;
                    if (null != (t = n.onsiteState.dynamicViewOverrides) && t[r] && (r = (0, x.L)(n, r) || this.formAction.viewId), (0, p.wf)(n, this.formVersionCId) && "string" == typeof this.composedFields[h.HD]) {
                        if (!await C(n, this.composedFields[h.HD], r, this.formId, this.companyId, this.formVersionCId, i.formVersionId)) return
                    }
                    return this._checkAndRemoveRedirectToInboxBtns(i.formVersionId, r), (0, c.Cm)({
                        id: this.formVersionCId,
                        changes: {
                            currentViewId: r
                        }
                    })
                }
                __submitToList() {
                    return this.__baseSubmitToList(L.s)
                }
                __handlePassedCaptchaChallenge() {
                    new ue({
                        formVersionCId: this.formVersionCId,
                        actionId: this.actionId
                    }).runAction()
                }
                _checkAndRemoveRedirectToInboxBtns(e, t) {
                    const n = o.Z.getState(),
                        i = (0, I.Tf)(n, e);
                    i && i === t && ((e, t, n, i) => {
                        var r;
                        const l = o.Z.getState(),
                            a = (l.formsState.actions ? Object.values(l.formsState.actions) : []).filter((e => (null == e ? void 0 : e.actionType) === s.Cd)).map((e => null == e ? void 0 : e.actionId));
                        if (0 === a.length) return;
                        const d = (0, I.nC)(l, i).filter((e => e && "BUTTON" === e.componentType && e.actionId && a.includes(e.actionId))).map((e => null == e ? void 0 : e.componentId));
                        if (0 === d.length) return;
                        const {
                            previousFormSubmitBody: c
                        } = l.onsiteState.client, m = null == c || null == (r = c.data.relationships) ? void 0 : r.list.data.id, u = null == c ? void 0 : c.data.attributes.profile.data.attributes[h.Td], f = (0, ce.Wt)(u || ""), p = Object.entries(l.formsState.components).filter((([, e]) => !d.includes(null == e ? void 0 : e.componentId)));
                        u && m && me(l, m) && f || ((0, y.M)({
                            metric: _.kM,
                            formVersionCId: n,
                            formId: t,
                            companyId: e,
                            userEmail: u,
                            listId: m,
                            emailProvider: f
                        }), o.Z.setState((e => Object.assign({}, e, {
                            formsState: Object.assign({}, e.formsState, {
                                components: Object.fromEntries(p)
                            })
                        }))))
                    })(this.companyId, this.formId, this.formVersionCId, i)
                }
            }
            ue.formActionType = s.p;
            var fe = ue;
            n(26650);
            var pe = e => {
                window.location.assign(e)
            };
            const he = ["isSubmit"];
            class ve extends d {
                constructor(e) {
                    var t, n;
                    let {
                        isSubmit: o
                    } = e;
                    super(r()(e, he)), this.redirectUrl = void 0, this.newWindow = void 0, this.isSubmit = void 0, this.redirectUrl = (null == (t = this.formAction.data) ? void 0 : t.redirectUrl) || "about:blank", this.newWindow = !(null == (n = this.formAction.data) || !n.newWindow) && this.formAction.actionType === s.$b, this.isSubmit = !!o, this.formActionType = s.$b
                }
                __redirectUrl() {
                    const e = this.redirectUrl.replace(/^javascript:/, "");
                    if (this.newWindow && this.formAction.actionType === s.$b) {
                        const t = window.open(e, "_blank");
                        null == t || t.focus()
                    } else pe(e)
                }
                __handler() {
                    const {
                        formId: e,
                        newWindow: t,
                        formVersionCId: n
                    } = this;
                    this.formAction.actionType === s.$b && (0, Z.$k)({
                        formId: e,
                        successActionType: s.$b
                    });
                    const i = o.Z.getState(),
                        r = i.onsiteState.openFormVersions[n];
                    if (!r) throw new Error("Open Form Version does not exist");
                    const l = r.sentSubmitMetric,
                        a = i.formsState.views[r.currentViewId],
                        d = a ? (0, I.O)(i, a) : void 0,
                        c = Promise.allSettled([(0, y.M)({
                            metric: _.nR,
                            logTelemetric: !this.isSubmit && !l,
                            logCustomEvent: !0,
                            formVersionCId: this.formVersionCId,
                            formId: this.formId,
                            companyId: this.companyId,
                            action_type: "Go to URL",
                            destination_url: this.redirectUrl
                        }), (0, y.M)({
                            metric: _._5,
                            logTelemetric: !this.isSubmit,
                            logCustomEvent: !0,
                            formVersionCId: this.formVersionCId,
                            formId: this.formId,
                            companyId: this.companyId,
                            action_type: "Go to URL",
                            destination_url: this.redirectUrl,
                            step_number: d ? d + 1 : void 0,
                            step_name: a ? (0, I.E5)(i, a.viewId) : void 0
                        })]);
                    return t ? (this.__redirectUrl(), c) : (0, j.n)(200, c).then((() => this.__redirectUrl())).catch((() => this.__redirectUrl()))
                }
            }
            ve.formActionType = s.$b;
            var ye = ve,
                ge = n(31074),
                Ie = n.n(ge),
                be = n(9247);
            class Se extends d {
                constructor(e) {
                    super(Object.assign({}, (Ie()(e), e))), this.formActionType = s.Cd
                }
                __handler() {
                    var e;
                    const t = o.Z.getState(),
                        {
                            previousFormSubmitBody: n
                        } = t.onsiteState.client,
                        i = null == n ? void 0 : n.data.attributes.profile.data.attributes[h.Td],
                        r = null == n || null == (e = n.data.relationships) ? void 0 : e.list.data.id;
                    if (!i || !r || !me(t, r)) throw (0, y.M)({
                        metric: _.Yu,
                        logCustomEvent: !0,
                        formVersionCId: this.formVersionCId,
                        formId: this.formId,
                        companyId: this.companyId,
                        userEmail: i,
                        listId: r
                    }), new Error("Cannot redirect to inbox. Email address and list ID must both be present.");
                    const {
                        senderEmail: s,
                        subject: a
                    } = (({
                        onsiteState: e
                    }, t) => {
                        var n, o;
                        return {
                            senderEmail: null == (n = e.companySenderSettings) ? void 0 : n.emailAddress,
                            subject: null == (o = e.companySenderSettings) || null == (o = o.emailSettings) || null == (o = o[t]) ? void 0 : o.subject
                        }
                    })(t, r), d = (0, B.Z)() === be.Jq, c = (0, ce.qV)({
                        userEmail: i,
                        isMobileDevice: d,
                        subject: a,
                        senderEmail: s
                    }), {
                        link: m,
                        provider: u
                    } = c || {};
                    if ((0, y.M)({
                            metric: _.t2,
                            logCustomEvent: !0,
                            formVersionCId: this.formVersionCId,
                            formId: this.formId,
                            companyId: this.companyId,
                            userEmail: i,
                            listId: r,
                            sniper_link: m,
                            emailProvider: u
                        }), m) {
                        const e = window.open(m, "_blank");
                        null == e || e.focus()
                    } else(0, l.qB)(`Could not generate sniper link. User email: ${i}. List ID: ${r}. isMobileDevice: ${d}. subject: ${a}. senderEmail: ${s}`)
                }
            }
            Se.formActionType = s.Cd;
            var we = Se;
            class xe extends J {
                __postHandler(e) {
                    return super.__postHandler(e), e && this.__submitHandlerCheck(e.status), new Promise((e => {
                        if (this.composedFields.$email || this.composedFields.$phone_number) {
                            let t = 5;
                            const n = setInterval((() => {
                                ((0, E.pN)() || 0 === t) && (clearInterval(n), e(!0)), t -= 1
                            }), 600)
                        }
                        e(!0)
                    })).then((() => {
                        const {
                            formVersionCId: e,
                            actionId: t
                        } = this;
                        return new ye({
                            formVersionCId: e,
                            actionId: t,
                            isSubmit: !0
                        }).runAction()
                    }))
                }
                __submitToList() {
                    return this.__baseSubmitToList(L.s)
                }
                __handlePassedCaptchaChallenge() {
                    new xe({
                        formVersionCId: this.formVersionCId,
                        actionId: this.actionId
                    }).runAction()
                }
            }
            xe.formActionType = s.uo;
            var Ce = xe;
            class Ee extends J {
                __postHandler(e) {
                    super.__postHandler(e), e && this.__submitHandlerCheck(e.status);
                    const {
                        formVersionCId: t,
                        actionId: n
                    } = this;
                    return new f({
                        formVersionCId: t,
                        actionId: n,
                        isSubmit: !0
                    }).runAction()
                }
                __submitToList() {
                    return this.__baseSubmitToList(L.s)
                }
                __handlePassedCaptchaChallenge() {
                    new Ee({
                        formVersionCId: this.formVersionCId,
                        actionId: this.actionId
                    }).runAction()
                }
            }
            Ee.formActionType = s.Ry;
            var ke = Ee;
            const $e = (e, t) => {
                    const n = e.onsiteState.openFormVersions[t];
                    if (!n) throw new Error("Open Form Version does not exist");
                    const {
                        formVersionId: o
                    } = n;
                    return (0, g.l1)(e, o, be.Jq).find((e => e.componentType === h.Ys))
                },
                Te = new Date("1/1/1900");

            function Ve(e) {
                return e && 6 === e.length
            }
            class Ze extends d {
                constructor(e) {
                    var t, n, i;
                    super(e), this.toPhoneNumber = void 0, this.hiddenFieldsComponentId = void 0, this.optInMessage = void 0, this.optInKeyword = void 0;
                    const r = o.Z.getState();
                    this.hiddenFieldsComponentId = (0, g.cA)(r, e.actionId), this.toPhoneNumber = null == (t = this.formAction.data) ? void 0 : t.toPhoneNumber, this.optInMessage = (null == (n = this.formAction.data) ? void 0 : n.optInMessage) || "Send this text to subscribe to SMS updates!", this.optInKeyword = (null == (i = this.formAction.data) ? void 0 : i.optInKeyword) || "JOIN", this.formActionType = s.T5
                }
                async __preHandler() {
                    const e = o.Z.getState(),
                        t = $e(e, this.formVersionCId);
                    if (void 0 !== t) {
                        var n;
                        const e = null == (n = await (0, c.eN)({
                            formVersionCId: this.formVersionCId
                        })) ? void 0 : n.filter((e => e.componentId === t.componentId));
                        if (e && e.some((({
                                valid: e
                            }) => !e))) throw new R.mN({
                            type: "form"
                        })
                    }
                    return !0
                }
                __handler() {
                    const e = o.Z.getState(),
                        t = ((e, t, n) => {
                            const o = $e(e, t);
                            if (o && void 0 !== (r = o).data.format && void 0 !== r.data.delimiter) {
                                var i;
                                const o = (0, p.$f)(e, t, n),
                                    r = (null == (i = e.onsiteState.openFormVersions[t]) || null == (i = i.sentIdentifiers) ? void 0 : i[h.vC]) || o[h.vC];
                                if (!r || "string" != typeof r) return;
                                const s = new Date(r).getTime() - Te.getTime();
                                return Math.round(s / 864e5).toString(36)
                            }
                            var r
                        })(e, this.formVersionCId, this.hiddenFieldsComponentId),
                        n = e.onsiteState.client.smsSubscriptionUniqueId,
                        i = ((e, t, n) => Ve(t) && n ? `${e}:${t}:${n}` : n ? `${e}:$kbday:${n}` : Ve(t) ? `${e}:${t}` : `${e}`)(this.optInKeyword, n, t),
                        r = `sms:${this.toPhoneNumber}?&body=${encodeURIComponent(`${this.optInMessage} (ref:${i})`)}`;
                    (0, Z.$k)({
                        formId: this.formId,
                        successActionType: s.T5
                    }), (0, c.et)({
                        formVersionCId: this.formVersionCId,
                        isSubmit: !0
                    });
                    const l = (0, Y.f8)(e, this.formVersionCId, !0),
                        a = e.onsiteState.openFormVersions[this.formVersionCId],
                        d = a ? e.formsState.views[a.currentViewId] : void 0,
                        m = [];
                    if ((0, p.Gt)(e, this.formVersionCId, l) && m.push((0, y.M)({
                            metric: _.FB,
                            logCustomEvent: !0,
                            formVersionCId: this.formVersionCId,
                            formId: this.formId,
                            companyId: this.companyId,
                            action_type: "Subscribe Via SMS",
                            sms_keyword: this.optInKeyword,
                            destination_url: r
                        })), d) {
                        var u;
                        const t = null != (u = (0, I.O)(e, d)) ? u : d.position;
                        m.push((0, y.M)({
                            metric: _.AH,
                            formVersionCId: this.formVersionCId,
                            logCustomEvent: !0,
                            formId: this.formId,
                            companyId: this.companyId,
                            step_number: t + 1,
                            step_name: (0, I.E5)(e, d.viewId),
                            action_type: "Subscribe Via SMS"
                        }))
                    }
                    const f = Promise.allSettled(m);
                    return (0, j.n)(200, f).then((() => pe(r))).catch((() => pe(r)))
                }
            }
            Ze.formActionType = s.T5;
            var _e = Ze;
            class Oe extends fe {}
            Oe.formActionType = s.hL;
            var Fe = Oe,
                Me = n(46456);
            let Ae, De = !1;
            class Ne extends G {
                constructor(e) {
                    super(Object.assign({}, (Ie()(e), e))), this.isSubmit = void 0, this.isSubmit = !1, this.formActionType = s.WP, Ae = null, De || (De = !0, this.startTimer())
                }
                startTimer() {
                    Ae = setTimeout((() => {
                        Ae = null
                    }), 5e3)
                }
                __handler() {
                    var e, t;
                    if (null !== Ae) return (0, l.qB)("ResendOptInCodeAction - Resend opt in code action is currently debouncing."), Promise.resolve();
                    this.startTimer();
                    const n = o.Z.getState(),
                        {
                            previousFormSubmitBody: i
                        } = n.onsiteState.client,
                        r = null != (e = null == i ? void 0 : i.data.attributes.profile.data.attributes[h.lL]) ? e : null == i ? void 0 : i.data.attributes.profile.data.attributes[h.HO];
                    if (!r || null == i || null == (t = i.data.relationships) || !t.list.data.id) throw new Error("Cannot resend opt in code. No previous form submit with phone number and or list id found.");
                    const s = i.data.relationships.list.data.id,
                        a = i.data.attributes.profile.data.attributes[h.Td],
                        d = (0, Me.Z)(i.data.attributes.profile.data.attributes.properties) ? i.data.attributes.profile.data.attributes.properties : {},
                        c = "$email" in d ? d.$email : void 0,
                        m = a || c,
                        u = {
                            [h.HO]: r,
                            properties: d
                        };
                    return m && (u.properties = Object.assign({}, u.properties, {
                        [h.HD]: m
                    })), (0, y.M)({
                        metric: _.Eo,
                        formVersionCId: this.formVersionCId,
                        formId: this.formId,
                        companyId: this.companyId,
                        submittedFields: u
                    }), (0, L.Y)(this.companyId, {
                        data: {
                            type: O.NR,
                            attributes: {
                                profile: {
                                    data: {
                                        type: O.cC,
                                        attributes: u
                                    }
                                }
                            },
                            relationships: {
                                list: {
                                    data: {
                                        type: O._,
                                        id: s
                                    }
                                }
                            }
                        },
                        meta: {
                            send_otp_code: !0
                        }
                    })
                }
            }
            Ne.formActionType = s.WP;
            var Be = Ne;
            var Re = n(64378);
            const je = ["isSubmit"],
                ze = "invalidCode";
            class We extends J {
                constructor(e) {
                    super(r()(e, je)), this.isSubmit = void 0, this.isSubmit = !0, this.formActionType = s.Kc
                }
                __handler() {
                    const e = o.Z.getState();
                    if (!e.onsiteState.openFormVersions[this.formVersionCId]) throw new Error("Open Form Version does not exist");
                    const {
                        previousFormSubmitBody: t
                    } = e.onsiteState.client, n = (null == t ? void 0 : t.data.attributes.profile.data.attributes[h.lL]) || (null == t ? void 0 : t.data.attributes.profile.data.attributes[h.HO]), i = this.composedFields[h.My];
                    if (!t || !n || !i || "string" != typeof n || "string" != typeof i) throw new Error(`Cannot submit opt in code. Previously submitted phone number and token must both be present: ${JSON.stringify({phoneNumber:n,token:i})}`);
                    return (0, k.W)((() => (async ({
                        companyId: e,
                        phoneNumber: t,
                        token: n
                    }) => (await (0, ne.l)(), (0, U.Z)(`https://a.klaviyo.com/client/otp-verify?company_id=${e}`, {
                        method: "POST",
                        headers: Object.assign({
                            "Access-Control-Allow-Headers": "*",
                            "Content-Type": "application/json"
                        }, (0, te.h)()),
                        body: JSON.stringify({
                            token: n,
                            channel: "sms",
                            destination: t,
                            company_id: e
                        })
                    })))({
                        companyId: this.companyId,
                        phoneNumber: n,
                        token: i
                    })), 5, 1e3 + 1e3 * Math.random(), [429]).then((e => {
                        if (429 === e.status) throw new R.TT;
                        return e
                    })).then((t => {
                        var n;
                        const {
                            formVersionCId: o
                        } = this, i = null == (n = e.onsiteState.openFormVersions[o]) ? void 0 : n.formVersionId;
                        if (t.status === O.ke && i) {
                            const t = (0, Re.G)(e, i)[0],
                                n = (0, I.nC)(e, t).find((e => (null == e ? void 0 : e.componentType) === h.eC));
                            if (n) throw (0, c.hX)({
                                componentId: null == n ? void 0 : n.componentId,
                                formVersionCId: o,
                                violation: {
                                    componentId: null == n ? void 0 : n.componentId,
                                    valid: !1,
                                    validationErrorType: ze
                                }
                            }), new R.mN({
                                type: ze
                            })
                        }
                        return t
                    })).then((e => e.status === O.dl && this.formAction.actionType ? ((0, Z.$k)({
                        formId: this.formId,
                        successActionType: this.formAction.actionType
                    }), (0, j.n)(200, this.__submitSuccessMetrics()).then((() => e)).catch((() => e))) : e))
                }
                async __postHandler(e) {
                    super.__postHandler(e);
                    if (!o.Z.getState().onsiteState.openFormVersions[this.formVersionCId] || !this.formAction.viewId) return null;
                    if ((null == e ? void 0 : e.status) === O.ke) return null;
                    e && this.__submitHandlerCheck(e.status);
                    const t = this.formAction.viewId;
                    return (0, c.Cm)({
                        id: this.formVersionCId,
                        changes: {
                            currentViewId: t
                        }
                    })
                }
                async __submitSuccessMetrics() {
                    const e = o.Z.getState();
                    this.submitMetric({
                        state: e,
                        isSubscribe: !0
                    });
                    return (0, y.M)({
                        metric: _.Jv,
                        logCustomEvent: !0,
                        formVersionCId: this.formVersionCId,
                        formId: this.formId,
                        companyId: this.companyId,
                        submittedFields: this.composedFields,
                        action_type: "Submit Form"
                    })
                }
            }
            We.formActionType = s.Kc;
            var Pe = We;
            const Le = ["isSubmit"];
            class He extends d {
                constructor(e) {
                    var t, n, o;
                    super(r()(e, Le)), this.formIdToOpen = void 0, this.closeSourceForm = void 0, this.isSubmit = void 0, this.formIdToOpen = null == (t = this.formAction.data) ? void 0 : t.formIdToOpen, this.closeSourceForm = null != (n = null == (o = this.formAction.data) ? void 0 : o.closeSourceForm) && n
                }
                __openFormVersion() {
                    const e = o.Z.getState();
                    if (this.closeSourceForm && (0, c.et)({
                            formVersionCId: this.formVersionCId
                        }), !this.formIdToOpen) return void console.error("No form to open specified.");
                    const t = e.formsState.forms[this.formIdToOpen];
                    null != t && t.liveFormVersion ? (0, c.f7)({
                        formVersionId: null == t ? void 0 : t.liveFormVersion
                    }) : console.error(`Form with formId: ${this.formIdToOpen} does not have a live form version. Please check the form configuration.`)
                }
                __handler() {
                    const {
                        formId: e,
                        formVersionCId: t
                    } = this;
                    this.formAction.actionType === s.y6 && (0, Z.$k)({
                        formId: e,
                        successActionType: s.y6
                    });
                    const n = o.Z.getState().onsiteState.openFormVersions[t];
                    if (!n) throw new Error("Open Form Version does not exist");
                    const i = n.sentSubmitMetric,
                        r = Promise.allSettled([(0, y.M)({
                            metric: _.qo,
                            logTelemetric: !this.isSubmit && !i,
                            logCustomEvent: !0,
                            formVersionCId: this.formVersionCId,
                            formId: this.formId,
                            companyId: this.companyId,
                            action_type: "Open Form",
                            form_to_open: this.formIdToOpen
                        })]);
                    return (0, j.n)(200, r).then((() => this.__openFormVersion())).catch((() => this.__openFormVersion()))
                }
            }
            He.formActionType = s.y6;
            var qe = He;
            const Ue = ["$phone_number"];
            class Ke extends J {
                constructor(e) {
                    super(Object.assign({}, (Ie()(e), e))), this.__submitHandler = (e, t) => {
                        var n, i;
                        const s = o.Z.getState(),
                            l = s.onsiteState.openFormVersions[this.formVersionCId];
                        let a = t;
                        if (void 0 === l) throw new Error("Expected open form version");
                        const d = (0, g.hB)(s, l.formVersionId);
                        if (void 0 === d) throw new Error("Expected list ID");
                        const c = null == (n = t.data.attributes.profile.data.attributes.properties) ? void 0 : n.$phone_number;
                        if (void 0 === c) throw new Error("Expected phone number for SMS promotional opt in action");
                        const m = null != (i = t.data.attributes.profile.data.attributes.properties) ? i : {},
                            u = r()(m, Ue),
                            f = (0, g.CW)(s, this.formVersionCId);
                        if ((null == f ? void 0 : f.sms) !== A.E3.MULTI_STEP_TRANSACTIONAL_PROMOTIONAL) throw new Error(`Expected SMS consent type to be ${A.E3.MULTI_STEP_TRANSACTIONAL_PROMOTIONAL} but got ${null==f?void 0:f.sms}`);
                        return a = Object.assign({}, t, {
                            data: Object.assign({}, t.data, {
                                attributes: {
                                    profile: Object.assign({}, t.data.attributes.profile, {
                                        data: Object.assign({}, t.data.attributes.profile.data, {
                                            attributes: Object.assign({}, t.data.attributes.profile.data.attributes, {
                                                properties: u,
                                                phone_number: c,
                                                subscriptions: Object.assign({}, t.data.attributes.profile.data.attributes.email ? {
                                                    email: {
                                                        marketing: {
                                                            consent: "SUBSCRIBED"
                                                        }
                                                    }
                                                } : {}, {
                                                    sms: {
                                                        marketing: {
                                                            consent: "SUBSCRIBED"
                                                        }
                                                    }
                                                })
                                            })
                                        })
                                    })
                                },
                                relationships: {
                                    list: {
                                        data: {
                                            type: O._,
                                            id: d
                                        }
                                    }
                                }
                            })
                        }), (0, L.Y)(e, a)
                    }, this.formActionType = s.h7
                }
                __submitToList() {
                    return this.__baseSubmitToList(this.__submitHandler)
                }
                async __postHandler(e) {
                    super.__postHandler(e);
                    if (!o.Z.getState().onsiteState.openFormVersions[this.formVersionCId] || !this.formAction.viewId) return null;
                    e && this.__submitHandlerCheck(e.status);
                    const t = this.formAction.viewId;
                    return (0, c.Cm)({
                        id: this.formVersionCId,
                        changes: {
                            currentViewId: t
                        }
                    })
                }
            }
            Ke.formActionType = s.h7;
            var Ge = Ke;
            class Ye extends d {
                constructor(e) {
                    var t, n;
                    super(e), this.deepLinkUrl = void 0, this.deepLinkUrl = null != (t = null == (n = this.formAction.data) ? void 0 : n.deepLinkUrl) ? t : "", this.formActionType = Ye.formActionType
                }
                async __handler() {
                    var e;
                    return await (0, j.n)(200, Promise.allSettled([(0, y.M)({
                        metric: _.VJ,
                        logTelemetric: !0,
                        logCustomEvent: !0,
                        formVersionCId: this.formVersionCId,
                        formId: this.formId,
                        companyId: this.companyId,
                        action_type: "Go to Deep Link URL",
                        destination_url: this.deepLinkUrl
                    })])).catch((() => {})), (0, Z.$k)({
                        formId: this.formId,
                        successActionType: s.eZ
                    }), (0, c.fK)({
                        id: this.formVersionCId,
                        changes: {
                            logCloseMetric: !1
                        }
                    }), null == (e = this.messageBus) || e.emit("openDeepLink", {
                        ios: this.deepLinkUrl,
                        android: this.deepLinkUrl
                    }), (0, c.et)({
                        formVersionCId: this.formVersionCId,
                        isSubmit: !0
                    })
                }
            }
            Ye.formActionType = s.eZ;
            var Xe = Ye;
            const Je = {
                    [Xe.formActionType]: Xe
                },
                Qe = Object.assign({
                    [f.formActionType]: f,
                    [fe.formActionType]: fe,
                    [Fe.formActionType]: Fe,
                    [ye.formActionType]: ye,
                    [we.formActionType]: we,
                    [ke.formActionType]: ke,
                    [Ce.formActionType]: Ce,
                    [_e.formActionType]: _e,
                    [Be.formActionType]: Be,
                    [Pe.formActionType]: Pe,
                    [qe.formActionType]: qe,
                    [Ge.formActionType]: Ge
                }, Je),
                et = ({
                    actionId: e
                }) => {
                    var t;
                    const n = o.Z.getState(),
                        i = n.formsState.actions ? null == (t = n.formsState.actions[e]) ? void 0 : t.actionType : void 0;
                    return Qe[i]
                }
        },
        99946: function(e, t, n) {
            n.d(t, {
                s: function() {
                    return o
                }
            });
            const o = {
                animationTimingFunction: "ease",
                animationPlayState: "running",
                animationDelay: "0s",
                animationIterationCount: 1,
                animationFillMode: "forwards"
            }
        },
        20077: function(e, t, n) {
            n.d(t, {
                B: function() {
                    return o
                }
            });
            const o = 9e4
        },
        50947: function(e, t, n) {
            n.d(t, {
                A: function() {
                    return i
                },
                p: function() {
                    return o
                }
            });
            const o = "teaser",
                i = "component"
        },
        64954: function(e, t) {
            t.Z = (e, t) => e / (e + 1) * t
        }
    }
]);